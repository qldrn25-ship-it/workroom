using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

internal static class ForegroundHelper
{
    [StructLayout(LayoutKind.Sequential)]
    private struct LASTINPUTINFO { public uint cbSize; public uint dwTime; }

    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

    [DllImport("user32.dll")]
    private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

    private static string Json(string s) => "\"" + (s ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "\\r").Replace("\n", "\\n") + "\"";

    public static int Main()
    {
        try
        {
            IntPtr hwnd = GetForegroundWindow();
            uint pid;
            GetWindowThreadProcessId(hwnd, out pid);
            string exe = "", path = "", title = "";
            try
            {
                var p = Process.GetProcessById((int)pid);
                exe = p.ProcessName + ".exe";
                try { path = p.MainModule?.FileName ?? ""; } catch { }
            }
            catch { }

            var sb = new StringBuilder(2048);
            if (hwnd != IntPtr.Zero) GetWindowText(hwnd, sb, sb.Capacity);
            title = sb.ToString();

            var lii = new LASTINPUTINFO();
            lii.cbSize = (uint)Marshal.SizeOf(lii);
            double idleSeconds = 0;
            if (GetLastInputInfo(ref lii))
            {
                uint now = unchecked((uint)Environment.TickCount);
                idleSeconds = unchecked(now - lii.dwTime) / 1000.0;
            }

            Console.Write("{\"ok\":true,\"pid\":" + pid + ",\"exe\":" + Json(exe) + ",\"path\":" + Json(path) + ",\"title\":" + Json(title) + ",\"idleSeconds\":" + idleSeconds.ToString(System.Globalization.CultureInfo.InvariantCulture) + "}");
            return 0;
        }
        catch (Exception ex)
        {
            Console.Write("{\"ok\":false,\"error\":" + Json(ex.Message) + "}");
            return 1;
        }
    }
}
