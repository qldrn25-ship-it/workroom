const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const { execFile } = require('child_process');

app.setName('WORKROOM');
if(process.platform==='win32'){
  app.setAppUserModelId('com.workroom.desktop');
}
app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion');

function createWindow(){
  const icon = path.join(__dirname, '..', 'app', 'assets', 'WORKROOM.ico');
  const win = new BrowserWindow({
    width: 1440,
    height: 930,
    minWidth: 980,
    minHeight: 700,
    show: false,
    autoHideMenuBar: true,
    backgroundColor: '#f4eee9',
    icon,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });
  win.setMenuBarVisibility(false);
  if(process.platform==='win32'){
    const launcher = process.execPath;
    try{
      win.setAppDetails({
        appId: 'com.workroom.desktop',
        relaunchCommand: launcher,
        relaunchDisplayName: 'WORKROOM',
        iconPath: icon,
        iconIndex: 0
      });
    }catch(e){
      console.warn('WORKROOM taskbar identity setup failed', e);
    }
  }
  win.loadFile(path.join(__dirname, '..', 'app', 'index.html'));
  win.once('ready-to-show', ()=>{
    win.maximize();
    win.show();
  });
  win.webContents.setWindowOpenHandler(({url})=>{
    if(/^https?:\/\//i.test(url) || /^mailto:/i.test(url)) shell.openExternal(url);
    return {action:'deny'};
  });
  win.webContents.on('will-navigate', (event,url)=>{
    if(url !== win.webContents.getURL() && (/^https?:\/\//i.test(url) || /^mailto:/i.test(url))){
      event.preventDefault();
      shell.openExternal(url);
    }
  });
}

ipcMain.handle('workroom:get-foreground-status', ()=> new Promise((resolve)=>{
  const helper = path.join(__dirname, 'native', 'foreground-helper.exe');
  execFile(helper, {windowsHide:true, timeout:1500, encoding:'utf8'}, (err,stdout)=>{
    if(err){
      resolve({ok:false,error:String(err.message||err)});
      return;
    }
    try{ resolve(JSON.parse(String(stdout||'').trim())); }
    catch(e){ resolve({ok:false,error:'invalid helper output',raw:String(stdout||'')}); }
  });
}));

app.whenReady().then(()=>{
  createWindow();
  app.on('activate', ()=>{ if(BrowserWindow.getAllWindows().length===0) createWindow(); });
});
app.on('window-all-closed', ()=>{ if(process.platform!=='darwin') app.quit(); });
