const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('workroomDesktop', {
  getForegroundStatus: ()=>ipcRenderer.invoke('workroom:get-foreground-status'),
  isStandalone: true,
  platform: process.platform
});
