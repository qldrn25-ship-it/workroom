
/* ===== batch_cut_add.js ===== */
(() => {
"use strict";

const q=s=>document.querySelector(s);
const uid=()=>globalThis.crypto?.randomUUID?.()||("cut-"+Date.now()+"-"+Math.random().toString(16).slice(2));

let batchMode=false;
let batchIds=[];
let batchIndex=0;

function currentEpisode(){
  try{
    if(typeof activeEpisode==="function"){
      const ep=activeEpisode();
      if(ep)return ep;
    }
  }catch(_){}
  if(typeof data!=="undefined"){
    const id=q("#episodeSelect")?.value||data.activeEpisodeId;
    return (data.episodes||[]).find(e=>String(e.id)===String(id))||null;
  }
  return null;
}

function saveAll(){
  try{
    if(typeof saveData==="function")saveData();
    else if(typeof STORAGE_KEY!=="undefined")localStorage.setItem(STORAGE_KEY,JSON.stringify(data));
  }catch(err){console.error(err)}
}

function makeCut(){
  return {
    id:uid(),
    description:"",
    dialogue:"",
    status:"todo",
    tag:"",
    note:"",
    characterList:[],
    characters:"",
    background:"",
    difficulty:"normal",
    estimatedMinutes:30,
    colorLabel:"",
    feedbackStatus:"",
    feedback:"",
    checklist:{},
    stageImages:{storyboard:"",rough:"",line:"",final:""},
    image:"",
    important:false
  };
}

function updateWizard(){
  const bar=q("#batchCutWizardBar");
  const progress=q("#batchCutWizardProgress");
  if(!bar||!progress)return;

  bar.classList.toggle("active",batchMode);

  if(batchMode){
    progress.textContent=`새 컷 ${batchIndex+1} / ${batchIds.length}`;
    q("#batchCutPrevBtn").disabled=batchIndex===0;
    q("#batchCutNextBtn").style.display=batchIndex===batchIds.length-1?"none":"inline-flex";
    q("#batchCutFinishBtn").style.display=batchIndex===batchIds.length-1?"inline-flex":"none";
  }
}

function flushCurrentCut(){
  // The existing cut modal already autosaves fields.
  // Trigger change/input blur where practical, then persist.
  const active=document.activeElement;
  if(active && ["INPUT","TEXTAREA","SELECT"].includes(active.tagName)){
    try{active.dispatchEvent(new Event("change",{bubbles:true}))}catch(_){}
    try{active.blur()}catch(_){}
  }
  saveAll();
}

function openBatchCutAt(index){
  const ep=currentEpisode();
  if(!ep)return;

  batchIndex=Math.max(0,Math.min(index,batchIds.length-1));
  const id=batchIds[batchIndex];
  const cut=(ep.cuts||[]).find(c=>String(c.id)===String(id));
  if(!cut)return;

  if(typeof openCutModal==="function"){
    openCutModal(id);
  }

  updateWizard();
}

function startBatch(count){
  const ep=currentEpisode();
  if(!ep){
    alert("먼저 회차를 선택해 주세요.");
    return;
  }

  count=Math.max(1,Math.min(300,Number(count||1)));
  batchIds=[];

  for(let i=0;i<count;i++){
    const cut=makeCut();
    ep.cuts.push(cut);
    batchIds.push(cut.id);
  }

  batchMode=true;
  batchIndex=0;
  saveAll();

  try{if(typeof renderCuts==="function")renderCuts()}catch(_){}

  q("#batchCutCountModal")?.classList.remove("open");
  openBatchCutAt(0);
}

function endBatch(){
  flushCurrentCut();
  batchMode=false;
  batchIds=[];
  batchIndex=0;
  updateWizard();

  // Close cut modal using its normal closer if possible.
  try{
    if(typeof closeCutModal==="function"){
      closeCutModal();
    }else{
      q("#cutModal")?.classList.remove("open");
    }
  }catch(_){
    q("#cutModal")?.classList.remove("open");
  }

  try{if(typeof renderCuts==="function")renderCuts()}catch(_){}
}

function cancelCount(){
  q("#batchCutCountModal")?.classList.remove("open");
}

/* Own the add-cut button in capture phase so old immediate-add handler does not fire. */
document.addEventListener("click",e=>{
  const btn=e.target.closest?.("#addCutBtn");
  if(!btn)return;

  e.preventDefault();
  e.stopPropagation();
  e.stopImmediatePropagation();

  const ep=currentEpisode();
  if(!ep){
    alert("먼저 회차를 선택해 주세요.");
    return;
  }

  q("#batchCutCountInput").value="1";
  q("#batchCutCountModal")?.classList.add("open");
  requestAnimationFrame(()=>q("#batchCutCountInput")?.select());
},true);

q("#closeBatchCutCountX")?.addEventListener("click",cancelCount);

q("#batchCutCountForm")?.addEventListener("submit",e=>{
  e.preventDefault();
  e.stopPropagation();
  startBatch(q("#batchCutCountInput")?.value||1);
});

q("#batchCutPrevBtn")?.addEventListener("click",()=>{
  if(!batchMode||batchIndex<=0)return;
  flushCurrentCut();
  openBatchCutAt(batchIndex-1);
});

q("#batchCutNextBtn")?.addEventListener("click",()=>{
  if(!batchMode)return;
  flushCurrentCut();
  if(batchIndex<batchIds.length-1){
    openBatchCutAt(batchIndex+1);
  }
});

q("#batchCutFinishBtn")?.addEventListener("click",()=>{
  if(!batchMode)return;
  endBatch();
});

/* Existing Save button in batch mode should mean "save and next / finish". */
q("#cutForm")?.addEventListener("submit",e=>{
  if(!batchMode)return;

  // Let the existing submit autosave first, but stop its automatic close behavior
  // by reopening/advancing immediately afterwards.
  setTimeout(()=>{
    if(!batchMode)return;
    if(batchIndex<batchIds.length-1){
      openBatchCutAt(batchIndex+1);
    }else{
      endBatch();
    }
  },20);
},true);

/* If X is pressed during batch editing, keep created cuts and end the wizard. */
q("#closeCutX")?.addEventListener("click",()=>{
  if(batchMode){
    flushCurrentCut();
    batchMode=false;
    batchIds=[];
    updateWizard();
    try{if(typeof renderCuts==="function")renderCuts()}catch(_){}
  }
},true);

/* ESC only closes count prompt. Cut modal keeps existing close rules. */
window.addEventListener("keydown",e=>{
  if(e.key==="Escape"&&q("#batchCutCountModal")?.classList.contains("open")){
    e.preventDefault();
    cancelCount();
  }
},true);

console.info("WORKROOM Local v50 batch cut add loaded");
})();

/* ===== review_flag_badge.js ===== */
(() => {
"use strict";

const q=s=>document.querySelector(s);
const qa=s=>[...document.querySelectorAll(s)];

function currentEpisodeSafe(){
  try{
    if(typeof activeEpisode==="function"){
      const ep=activeEpisode();
      if(ep)return ep;
    }
  }catch(_){}

  if(typeof data!=="undefined"){
    const id=q("#episodeSelect")?.value || data.activeEpisodeId;
    return (data.episodes||[]).find(e=>String(e.id)===String(id)) || null;
  }
  return null;
}

function decorateReviewFlags(){
  const ep=currentEpisodeSafe();
  if(!ep)return;

  qa("#cutsGrid .cut-card").forEach(card=>{
    card.querySelector(".review-needed-badge")?.remove();

    const id=card.dataset.id;
    const cut=(ep.cuts||[]).find(c=>String(c.id)===String(id));
    if(!cut || cut.feedbackStatus!=="needs")return;

    const badge=document.createElement("span");
    badge.className="review-needed-badge";
    badge.textContent="수정 필요";

    const head=card.querySelector(".cut-head");
    const status=head?.querySelector(".status-pill");

    if(head && status){
      head.insertBefore(badge,status);
    }else if(head){
      head.appendChild(badge);
    }else{
      card.appendChild(badge);
    }
  });
}

function refreshCards(){
  try{
    if(typeof renderCuts==="function")renderCuts();
  }catch(_){}
  requestAnimationFrame(decorateReviewFlags);
}

/* renderCuts 이후 항상 배지 재표시 */
if(typeof renderCuts==="function"){
  const baseRenderCuts=renderCuts;
  renderCuts=function(){
    const result=baseRenderCuts.apply(this,arguments);
    requestAnimationFrame(decorateReviewFlags);
    return result;
  };
}

/* 검수 모드 버튼을 누른 뒤 상태가 변경되면 즉시 카드에도 반영 */
q("#reviewFlagBtn")?.addEventListener("click",()=>{
  setTimeout(refreshCards,30);
},false);

q("#reviewResolveBtn")?.addEventListener("click",()=>{
  setTimeout(refreshCards,30);
},false);

q("#episodeSelect")?.addEventListener("change",()=>setTimeout(decorateReviewFlags,30));
q("#projectSelect")?.addEventListener("change",()=>setTimeout(decorateReviewFlags,30));

/* 카드 목록이 다시 그려질 때도 표시 유지 */
const grid=q("#cutsGrid");
if(grid){
  const observer=new MutationObserver(()=>requestAnimationFrame(decorateReviewFlags));
  observer.observe(grid,{childList:true,subtree:false});
}

setTimeout(decorateReviewFlags,100);

console.info("WORKROOM Local v52 review flag badge loaded");
})();

/* ===== theme_colors.js ===== */
(() => {
"use strict";
const KEY="webtoonWorkroom.colorTheme.v56";
const THEMES=["beige","sage","rose","blue","lavender","pink-princess","blue-princess"];
const COLORS={beige:"#9a735e",sage:"#73836a",rose:"#a67373",blue:"#687d91",lavender:"#807087","pink-princess":"#e58fb7","blue-princess":"#82aee8"};
const q=s=>document.querySelector(s);

function applyThemeColor(name){
  if(!THEMES.includes(name))name="beige";
  document.documentElement.dataset.themeColor=name;
  localStorage.setItem(KEY,name);
  const dot=q("#themeColorDot");
  if(dot)dot.style.background=COLORS[name];
  document.querySelectorAll(".theme-swatch").forEach(btn=>{
    btn.classList.toggle("active",btn.dataset.themeColor===name);
  });
}
function closeMenu(){q("#themeColorMenu")?.classList.remove("open")}

q("#themeColorBtn")?.addEventListener("click",e=>{
  e.preventDefault();e.stopPropagation();
  q("#themeColorMenu")?.classList.toggle("open");
});
document.querySelectorAll(".theme-swatch").forEach(btn=>{
  btn.addEventListener("click",e=>{
    e.preventDefault();e.stopPropagation();
    applyThemeColor(btn.dataset.themeColor);
    closeMenu();
  });
});
document.addEventListener("click",e=>{if(!e.target.closest?.(".theme-color-picker"))closeMenu()});
window.addEventListener("keydown",e=>{if(e.key==="Escape")closeMenu()});

applyThemeColor(localStorage.getItem(KEY)||"beige");
console.info("WORKROOM Local v56 color themes loaded");
})();

/* ===== pomodoro.js ===== */
(() => {
"use strict";

const q=s=>document.querySelector(s);
const SETTINGS_KEY="webtoonWorkroom.pomodoro.settings.v57";
const STATE_KEY="webtoonWorkroom.pomodoro.state.v57";
const HISTORY_KEY="webtoonWorkroom.pomodoro.history.v57";

const defaultSettings={
  focus:25,
  short:5,
  long:15,
  cycles:4,
  autoStartBreak:false,
  autoStartFocus:false,
  soundEnabled:true,
  soundType:"bell",
  soundVolume:65
};

let settings={...defaultSettings};
let mode="focus";
let running=false;
let remaining=25*60;
let total=25*60;
let focusCycle=1;
let endAt=0;
let tickTimer=null;

function today(){
  const d=new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}
function loadSettings(){
  try{
    settings={...defaultSettings,...JSON.parse(localStorage.getItem(SETTINGS_KEY)||"{}")};
  }catch(_){}
}
function saveSettings(){
  localStorage.setItem(SETTINGS_KEY,JSON.stringify(settings));
}
function getHistory(){
  try{
    const h=JSON.parse(localStorage.getItem(HISTORY_KEY)||"[]");
    return Array.isArray(h)?h:[];
  }catch(_){return []}
}
function saveHistory(h){
  localStorage.setItem(HISTORY_KEY,JSON.stringify(h.slice(-500)));
}
function secondsFor(m){
  return Math.max(1,Number(settings[m]||1))*60;
}
function modeLabel(m){
  return {focus:"집중 시간",short:"짧은 휴식",long:"긴 휴식"}[m]||"집중 시간";
}
function formatTime(sec){
  sec=Math.max(0,Math.ceil(sec));
  const m=Math.floor(sec/60),s=sec%60;
  return `${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;
}
function persistState(){
  localStorage.setItem(STATE_KEY,JSON.stringify({
    mode,running,remaining,total,focusCycle,endAt
  }));
}
function restoreState(){
  try{
    const s=JSON.parse(localStorage.getItem(STATE_KEY)||"null");
    if(!s)return;
    mode=["focus","short","long"].includes(s.mode)?s.mode:"focus";
    focusCycle=Math.max(1,Number(s.focusCycle||1));
    running=!!s.running;
    total=Math.max(1,Number(s.total||secondsFor(mode)));
    remaining=Math.max(0,Number(s.remaining||total));
    endAt=Number(s.endAt||0);

    if(running&&endAt){
      remaining=Math.max(0,Math.ceil((endAt-Date.now())/1000));
      if(remaining<=0){
        running=false;
        remaining=0;
      }
    }
  }catch(_){}
}
function updateSettingsUI(){
  q("#pomodoroFocusMinutes").value=settings.focus;
  q("#pomodoroShortMinutes").value=settings.short;
  q("#pomodoroLongMinutes").value=settings.long;
  q("#pomodoroCycles").value=settings.cycles;
  q("#pomodoroAutoStartBreak").checked=!!settings.autoStartBreak;
  q("#pomodoroAutoStartFocus").checked=!!settings.autoStartFocus;
  q("#pomodoroSoundEnabled").checked=settings.soundEnabled!==false;
  q("#pomodoroSoundType").value=settings.soundType||"bell";
  q("#pomodoroSoundVolume").value=Number(settings.soundVolume??65);
}
function render(){
  const elapsed=total-remaining;
  const pct=total?Math.max(0,Math.min(1,elapsed/total)):0;
  q("#pomodoroTime").textContent=formatTime(remaining);
  q("#pomodoroStatusText").textContent=modeLabel(mode);
  q("#pomodoroProgressRing").style.setProperty("--progress",`${pct*360}deg`);
  q("#pomodoroStartBtn").textContent=running?"Ⅱ 일시정지":"▶ 시작";
  q("#pomodoroSubstatus").textContent=running
    ? (mode==="focus"?"집중하고 있어요":"잠깐 쉬어가세요")
    : "준비되면 시작하세요";
  q("#pomodoroCycleBadge").textContent=`${Math.min(focusCycle,settings.cycles)} / ${settings.cycles}`;

  document.querySelectorAll(".pomodoro-mode").forEach(btn=>{
    btn.classList.toggle("active",btn.dataset.pomodoroMode===mode);
  });

  renderStats();
}
function renderStats(){
  const h=getHistory().filter(x=>x.date===today()&&x.type==="focus");
  const mins=h.reduce((s,x)=>s+Number(x.minutes||0),0);
  q("#pomodoroTodaySessions").textContent=`${h.length}회`;
  q("#pomodoroTodayMinutes").textContent=`${mins}분`;
  q("#pomodoroTodayStreak").textContent=`${focusCycle-1}회`;

  const box=q("#pomodoroHistory");
  box.innerHTML="";
  [...h].reverse().forEach(x=>{
    const row=document.createElement("div");
    row.className="pomodoro-history-row";
    row.innerHTML=`<strong>집중 ${x.minutes}분</strong><span>${new Date(x.at).toLocaleTimeString("ko-KR",{hour:"2-digit",minute:"2-digit"})}</span>`;
    box.appendChild(row);
  });
}
function setMode(next,keepCycle=true){
  mode=next;
  running=false;
  clearInterval(tickTimer);
  tickTimer=null;
  total=secondsFor(mode);
  remaining=total;
  endAt=0;
  if(!keepCycle&&mode==="focus")focusCycle=1;
  persistState();
  render();
}
function recordFocus(){
  const h=getHistory();
  h.push({
    id:crypto.randomUUID?.()||String(Date.now()),
    date:today(),
    at:Date.now(),
    type:"focus",
    minutes:Number(settings.focus)
  });
  saveHistory(h);
}

const pomodoroSoundFiles={
  bell:"pomodoro_bell.wav",
  chime:"pomodoro_chime.wav",
  soft:"pomodoro_soft.wav"
};
let pomodoroAudio=null;
function playPomodoroSound(force=false){
  if(!force&&!settings.soundEnabled)return Promise.resolve(false);
  try{
    if(pomodoroAudio){pomodoroAudio.pause();pomodoroAudio.currentTime=0;}
    const source=pomodoroSoundFiles[settings.soundType]||pomodoroSoundFiles.bell;
    pomodoroAudio=new Audio(source);
    pomodoroAudio.volume=Math.max(0,Math.min(1,Number(settings.soundVolume||65)/100));
    pomodoroAudio.preload="auto";
    const result=pomodoroAudio.play();
    if(result&&typeof result.catch==="function")return result.then(()=>true).catch(err=>{console.warn("Pomodoro audio playback blocked:",err);return false;});
    return Promise.resolve(true);
  }catch(err){console.warn("Pomodoro audio playback failed:",err);return Promise.resolve(false);}
}

function finishCurrent(){
  playPomodoroSound();
  running=false;
  clearInterval(tickTimer);
  tickTimer=null;
  remaining=0;

  if(mode==="focus"){
    recordFocus();
    const longDue=focusCycle>=settings.cycles;
    if(longDue){
      focusCycle=1;
      setMode("long");
    }else{
      focusCycle+=1;
      setMode("short");
    }
    if(settings.autoStartBreak)start();
  }else{
    setMode("focus");
    if(settings.autoStartFocus)start();
  }
  renderStats();
}
function tick(){
  if(!running)return;
  remaining=Math.max(0,Math.ceil((endAt-Date.now())/1000));
  if(remaining<=0){
    finishCurrent();
    return;
  }
  persistState();
  render();
}
function start(){
  if(running){
    remaining=Math.max(0,Math.ceil((endAt-Date.now())/1000));
    running=false;
    clearInterval(tickTimer);
    tickTimer=null;
    endAt=0;
    persistState();
    render();
    return;
  }
  running=true;
  endAt=Date.now()+remaining*1000;
  tickTimer=setInterval(tick,500);
  persistState();
  render();
}
function reset(){
  running=false;
  clearInterval(tickTimer);
  tickTimer=null;
  total=secondsFor(mode);
  remaining=total;
  endAt=0;
  persistState();
  render();
}
function skip(){
  running=false;
  clearInterval(tickTimer);
  tickTimer=null;

  if(mode==="focus"){
    const longDue=focusCycle>=settings.cycles;
    if(longDue){
      focusCycle=1;
      setMode("long");
    }else{
      focusCycle+=1;
      setMode("short");
    }
  }else{
    setMode("focus");
  }
}
function applySettings(){
  settings.focus=Math.max(1,Math.min(180,Number(q("#pomodoroFocusMinutes").value||25)));
  settings.short=Math.max(1,Math.min(60,Number(q("#pomodoroShortMinutes").value||5)));
  settings.long=Math.max(1,Math.min(120,Number(q("#pomodoroLongMinutes").value||15)));
  settings.cycles=Math.max(1,Math.min(12,Number(q("#pomodoroCycles").value||4)));
  settings.autoStartBreak=q("#pomodoroAutoStartBreak").checked;
  settings.autoStartFocus=q("#pomodoroAutoStartFocus").checked;
  settings.soundEnabled=q("#pomodoroSoundEnabled").checked;
  settings.soundType=q("#pomodoroSoundType").value||"bell";
  settings.soundVolume=Math.max(0,Math.min(100,Number(q("#pomodoroSoundVolume").value||65)));
  saveSettings();
  if(!running){
    total=secondsFor(mode);
    remaining=total;
  }
  render();
}

/* integrate view */
const baseSwitch=typeof switchView==="function"?switchView:null;
if(baseSwitch){
  switchView=function(view){
    baseSwitch(view);
    if(view==="pomodoro"){
      q("#pageTitle").textContent="뽀모도로 타이머";
      render();
    }
  };
}

/* direct nav fallback */
document.querySelectorAll('.nav-btn[data-view="pomodoro"]').forEach(btn=>{
  btn.addEventListener("click",()=>{
    document.querySelectorAll(".view").forEach(v=>v.classList.remove("active"));
    q("#pomodoroView")?.classList.add("active");
    document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b===btn));
    if(q("#pageTitle"))q("#pageTitle").textContent="뽀모도로 타이머";
    render();
  });
});

q("#pomodoroStartBtn")?.addEventListener("click",start);
q("#pomodoroResetBtn")?.addEventListener("click",reset);
q("#pomodoroSkipBtn")?.addEventListener("click",skip);

document.querySelectorAll(".pomodoro-mode").forEach(btn=>{
  btn.addEventListener("click",()=>setMode(btn.dataset.pomodoroMode));
});

["pomodoroFocusMinutes","pomodoroShortMinutes","pomodoroLongMinutes","pomodoroCycles"].forEach(id=>{
  q("#"+id)?.addEventListener("change",applySettings);
});
q("#pomodoroAutoStartBreak")?.addEventListener("change",applySettings);
q("#pomodoroAutoStartFocus")?.addEventListener("change",applySettings);
q("#pomodoroSoundEnabled")?.addEventListener("change",applySettings);
q("#pomodoroSoundType")?.addEventListener("change",applySettings);
q("#pomodoroSoundVolume")?.addEventListener("input",applySettings);
q("#pomodoroSoundTestBtn")?.addEventListener("click",async()=>{
  applySettings();
  const btn=q("#pomodoroSoundTestBtn");
  const original=btn?.textContent||"♪ 소리 테스트";
  if(btn)btn.textContent="♪ 재생 중…";
  const ok=await playPomodoroSound(true);
  if(btn){btn.textContent=ok?"♪ 재생 완료":"소리 재생 실패";setTimeout(()=>{btn.textContent=original},1200);}
});

q("#pomodoroClearTodayBtn")?.addEventListener("click",()=>{
  if(!confirm("오늘 뽀모도로 기록을 지울까요?"))return;
  const d=today();
  saveHistory(getHistory().filter(x=>x.date!==d));
  focusCycle=1;
  persistState();
  renderStats();
  render();
});

loadSettings();
restoreState();
updateSettingsUI();

if(running&&remaining>0){
  endAt=Date.now()+remaining*1000;
  tickTimer=setInterval(tick,500);
}
render();

console.info("WORKROOM Local v57 pomodoro loaded");
})();

/* ===== work_timer.js — standalone active-window tracker v14 ===== */
(() => {
"use strict";

const q=s=>document.querySelector(s);
const SETTINGS_KEY="webtoonWorkroom.worktimer.settings.v14";
const STATE_KEY="webtoonWorkroom.worktimer.state.v14";
const HISTORY_KEY="webtoonWorkroom.worktimer.history.v58";

const defaults={
  program1:"Photoshop.exe",
  program2:"CLIPStudioPaint.exe",
  program3:"Blender.exe",
  timeout:10,
  onColor:"#b0ffff",
  offColor:"#f07070",
  idlePause:true,
  autoEnabled:true
};

let settings={...defaults};
let running=false;
let elapsedMs=0;
let startedAt=0;
let lastSavedElapsed=0;
let activeStatus=null;
let matchedProgram="";
let tickBusy=false;

function today(){
  const d=new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}
function formatMs(ms){
  const sec=Math.max(0,Math.floor(ms/1000));
  const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),ss=sec%60;
  return [h,m,ss].map(v=>String(v).padStart(2,"0")).join(":");
}
function currentElapsed(){ return elapsedMs+(running?(Date.now()-startedAt):0); }
function getHistory(){
  try{const h=JSON.parse(localStorage.getItem(HISTORY_KEY)||"[]");return Array.isArray(h)?h:[]}catch(_){return []}
}
function saveHistory(h){localStorage.setItem(HISTORY_KEY,JSON.stringify(h.slice(-1000)))}
function loadSettings(){
  try{settings={...defaults,...JSON.parse(localStorage.getItem(SETTINGS_KEY)||"{}")} }catch(_){}
}
function saveSettings(){localStorage.setItem(SETTINGS_KEY,JSON.stringify(settings))}
function saveState(){
  localStorage.setItem(STATE_KEY,JSON.stringify({elapsedMs:currentElapsed(),lastSavedElapsed,savedAt:Date.now()}));
}
function restoreState(){
  try{
    const st=JSON.parse(localStorage.getItem(STATE_KEY)||"null");
    if(!st)return;
    running=false; elapsedMs=Math.max(0,Number(st.elapsedMs||0)); lastSavedElapsed=Math.max(0,Number(st.lastSavedElapsed||0));
  }catch(_){}
}
function normalize(v){return String(v||"").toLowerCase().replace(/[\s._-]+/g,"")}
function displayProgram(status){
  if(!status)return "확인 중…";
  const exe=status.exeName||"";
  const title=status.title||"";
  if(normalize(exe).includes("clipstudiopaint"))return "CLIP STUDIO PAINT";
  if(normalize(exe).includes("photoshop"))return "Adobe Photoshop";
  if(normalize(exe).includes("blender"))return "Blender";
  return exe||title||"알 수 없는 창";
}
function matchesOne(raw,status){
  if(!raw||!status?.ok)return false;
  const target=normalize(raw);
  const exe=normalize(status.exeName), path=normalize(status.exePath), title=normalize(status.title), cls=normalize(status.className);
  if(target.includes("clipstudio")||target.includes("클립스튜디오")||target==="csp"){
    return exe.includes("clipstudiopaint")||path.includes("clipstudiopaint")||title.includes("clipstudiopaint");
  }
  if(target.includes("photoshop"))return exe.includes("photoshop")||path.includes("photoshop");
  if(target.includes("blender"))return exe.includes("blender")||path.includes("blender");
  return [exe,path,title,cls].some(v=>v&&v.includes(target));
}
function findMatch(status){
  for(const raw of [settings.program1,settings.program2,settings.program3]) if(matchesOne(raw,status)) return raw;
  return "";
}
function renderSettings(){
  q("#worktimerProgram1").value=settings.program1;
  q("#worktimerProgram2").value=settings.program2;
  q("#worktimerProgram3").value=settings.program3;
  q("#worktimerTimeout").value=settings.timeout;
  q("#worktimerOnColor").value=settings.onColor;
  q("#worktimerOffColor").value=settings.offColor;
  q("#worktimerIdlePause").checked=!!settings.idlePause;
}
function renderHistory(){
  const h=getHistory().filter(x=>x.date===today());
  const total=h.reduce((sum,x)=>sum+Number(x.duration||0),0);
  q("#worktimerTodayTotal").textContent=`${Math.floor(total/60000)}분`;
  q("#worktimerTodaySessions").textContent=`${h.length}회`;
  const box=q("#worktimerHistory"); if(!box)return; box.innerHTML="";
  [...h].reverse().forEach(x=>{
    const row=document.createElement("div"); row.className="worktimer-history-row";
    row.innerHTML=`<strong>${formatMs(x.duration)}</strong><span>${new Date(x.at).toLocaleTimeString("ko-KR",{hour:"2-digit",minute:"2-digit"})}</span>`;
    box.appendChild(row);
  });
}
function render(){
  const cur=currentElapsed();
  q("#worktimerElapsed").textContent=formatMs(cur);
  q("#worktimerCurrentMinutes").textContent=`${Math.floor(cur/60000)}분`;
  q("#worktimerLastTime").textContent=formatMs(lastSavedElapsed);
  const badge=q("#worktimerStateBadge");
  if(!settings.autoEnabled){badge.textContent="자동감지 꺼짐";badge.style.background=settings.offColor}
  else if(running){badge.textContent="작동 중";badge.style.background=settings.onColor}
  else{badge.textContent="감지 대기";badge.style.background=settings.offColor}
  q("#worktimerStartBtn").textContent=settings.autoEnabled?"자동감지 끄기":"자동감지 켜기";
  const det=q("#worktimerDetectedApp");
  if(det){
    const idle=activeStatus?.ok?Math.floor(Number(activeStatus.idleMs||0)/1000):0;
    det.textContent=activeStatus?.ok?`현재 활성 창: ${displayProgram(activeStatus)} · 입력 대기 ${idle}초`:`현재 활성 창: 감지기 연결 대기`;
  }
  renderHistory();
}
function startCounting(){if(running)return;running=true;startedAt=Date.now();}
function stopCounting(){if(!running)return;elapsedMs=currentElapsed();running=false;startedAt=0;saveState();}
function reset(){running=false;elapsedMs=0;startedAt=0;saveState();render()}
function saveSession(){
  stopCounting();
  const duration=elapsedMs;
  if(duration<1000){alert("저장할 작업 시간이 없습니다.");return}
  const h=getHistory();
  h.push({id:crypto.randomUUID?.()||String(Date.now()),date:today(),at:Date.now(),duration,programs:[settings.program1,settings.program2,settings.program3].filter(Boolean)});
  saveHistory(h); lastSavedElapsed=duration; elapsedMs=0; saveState(); render();
}
function saveSettingsFromUI(){
  settings.program1=q("#worktimerProgram1").value.trim();
  settings.program2=q("#worktimerProgram2").value.trim();
  settings.program3=q("#worktimerProgram3").value.trim();
  settings.timeout=Math.max(0,Math.min(3600,Number(q("#worktimerTimeout").value||0)));
  settings.onColor=q("#worktimerOnColor").value; settings.offColor=q("#worktimerOffColor").value; settings.idlePause=q("#worktimerIdlePause").checked;
  saveSettings(); render();
}
async function desktopTick(){
  if(tickBusy)return; tickBusy=true;
  try{
    if(!window.workroomDesktop?.getForegroundStatus){
      activeStatus={ok:false,error:"desktop bridge unavailable"};
      stopCounting();
      q("#worktimerHint").textContent="자동 창 감지는 독립 WORKROOM 프로그램에서만 사용할 수 있습니다.";
      render(); return;
    }
    activeStatus=await window.workroomDesktop.getForegroundStatus();
    matchedProgram=findMatch(activeStatus);
    const idleTooLong=!!(settings.idlePause&&settings.timeout>0&&Number(activeStatus?.idleMs||0)>=settings.timeout*1000);
    const shouldRun=!!(settings.autoEnabled&&matchedProgram&&!idleTooLong);
    if(shouldRun)startCounting(); else stopCounting();
    if(!settings.autoEnabled)q("#worktimerHint").textContent="자동 감지가 꺼져 있습니다.";
    else if(!activeStatus?.ok)q("#worktimerHint").textContent="Windows 활성 창 정보를 읽지 못했습니다.";
    else if(!matchedProgram)q("#worktimerHint").textContent="등록한 작업 프로그램이 활성 창이 될 때까지 기다리는 중입니다.";
    else if(idleTooLong)q("#worktimerHint").textContent=`${displayProgram(activeStatus)} 감지됨 · ${settings.timeout}초 이상 입력이 없어 자동 정지`;
    else q("#worktimerHint").textContent=`${displayProgram(activeStatus)} 사용 중 · 자동으로 작업 시간을 기록하고 있습니다.`;
    q("#worktimerElapsed").textContent=formatMs(currentElapsed());
    q("#worktimerCurrentMinutes").textContent=`${Math.floor(currentElapsed()/60000)}분`;
    render();
    if(Date.now()%5000<800)saveState();
  }catch(err){
    activeStatus={ok:false,error:String(err)}; stopCounting();
    q("#worktimerHint").textContent="활성 창 감지 중 오류가 발생했습니다."; render();
  }finally{tickBusy=false}
}

const baseSwitch=typeof switchView==="function"?switchView:null;
if(baseSwitch){switchView=function(view){baseSwitch(view);if(view==="worktimer"){q("#pageTitle").textContent="워크 타이머";render()}}}
document.querySelectorAll('.nav-btn[data-view="worktimer"]').forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".view").forEach(v=>v.classList.remove("active")); q("#worktimerView")?.classList.add("active");
  document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b===btn)); if(q("#pageTitle"))q("#pageTitle").textContent="워크 타이머"; render();
}));
q("#worktimerStartBtn")?.addEventListener("click",()=>{settings.autoEnabled=!settings.autoEnabled;if(!settings.autoEnabled)stopCounting();saveSettings();render();desktopTick()});
q("#worktimerResetBtn")?.addEventListener("click",()=>{if(currentElapsed()>0&&!confirm("현재 작업 시간을 초기화할까요?"))return;reset()});
q("#worktimerSaveBtn")?.addEventListener("click",saveSession);
q("#worktimerRestoreLastBtn")?.addEventListener("click",()=>{if(lastSavedElapsed<=0)return;stopCounting();elapsedMs=lastSavedElapsed;saveState();render()});
q("#worktimerClearTodayBtn")?.addEventListener("click",()=>{if(!confirm("오늘 워크 타이머 기록을 지울까요?"))return;const d=today();saveHistory(getHistory().filter(x=>x.date!==d));renderHistory()});
["worktimerProgram1","worktimerProgram2","worktimerProgram3","worktimerTimeout","worktimerOnColor","worktimerOffColor","worktimerIdlePause"].forEach(id=>q("#"+id)?.addEventListener("change",saveSettingsFromUI));

loadSettings();restoreState();renderSettings();render();
setInterval(desktopTick,700);desktopTick();
window.addEventListener("beforeunload",saveState);
console.info("WORKROOM standalone work timer v14 loaded");
})();

/* ===== runtime boot check v63 ===== */
window.WORKROOM_ADDONS_LOADED_V63=true;
console.info("WORKROOM addons v63 loaded successfully");
