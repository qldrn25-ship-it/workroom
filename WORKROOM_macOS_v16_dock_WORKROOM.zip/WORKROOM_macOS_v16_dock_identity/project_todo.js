
(()=>{
"use strict";

let workImageDraft="";
let todoFilter="all";

function esc(v){
  return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m]));
}
function ensureProjectTodoData(){
  if(!Array.isArray(data.projects)) data.projects=[];
  data.projects.forEach(p=>{
    if(p.coverImage===undefined)p.coverImage="";
    if(p.workLink===undefined)p.workLink="";
    if(p.plan===undefined)p.plan="";
  });
  if(!Array.isArray(data.todos))data.todos=[];
  data.todos.forEach(t=>{
    if(!t.id)t.id=crypto.randomUUID();
    if(t.title===undefined)t.title="";
    if(t.note===undefined)t.note="";
    if(t.projectId===undefined)t.projectId="";
    if(t.priority===undefined)t.priority="normal";
    if(t.dueDate===undefined)t.dueDate="";
    if(t.done===undefined)t.done=false;
    if(t.createdAt===undefined)t.createdAt=Date.now();
    if(t.updatedAt===undefined)t.updatedAt=t.createdAt;
  });
}
function projectById(id){return data.projects.find(p=>p.id===id)||null}

function setWorkImageUI(){
  const wrap=document.querySelector("#workImagePreviewWrap");
  const img=document.querySelector("#workImagePreview");
  if(!wrap||!img)return;
  wrap.classList.toggle("has-image",!!workImageDraft);
  if(workImageDraft) img.src=workImageDraft;
  else img.removeAttribute("src");
}
async function readWorkImage(file){
  try{
    if(typeof compressMemoImage==="function"){
      workImageDraft=await compressMemoImage(file);
    }else{
      workImageDraft=await new Promise((resolve,reject)=>{
        const r=new FileReader();
        r.onload=()=>resolve(r.result);
        r.onerror=reject;
        r.readAsDataURL(file);
      });
    }
    setWorkImageUI();
  }catch(err){
    console.error(err);
    alert("대표이미지를 불러오지 못했습니다.");
  }
}

function fillWorkForm(project){
  document.querySelector("#workManageId").value=project?.id||"";
  document.querySelector("#workManageName").value=project?.name||"";
  document.querySelector("#workManageLink").value=project?.workLink||"";
  document.querySelector("#workManagePlan").value=project?.plan||"";
  document.querySelector("#workManageModalTitle").textContent=project?"작품 정보 편집":"새 작품 추가";
  workImageDraft=project?.coverImage||"";
  setWorkImageUI();
}
function openWorkModal(id=""){
  ensureProjectTodoData();
  fillWorkForm(id?projectById(id):null);
  document.querySelector("#workManageModal")?.classList.add("open");
  setTimeout(()=>document.querySelector("#workManageName")?.focus(),0);
}
function closeWorkModal(){
  document.querySelector("#workManageModal")?.classList.remove("open");
}
function safeOpenUrl(raw){
  let url=String(raw||"").trim();
  if(!url)return;
  if(!/^https?:\/\//i.test(url)) url="https://"+url;
  try{window.open(url,"_blank","noopener,noreferrer")}
  catch(_){location.href=url}
}
window.renderWorkManager=function(){
  ensureProjectTodoData();
  const grid=document.querySelector("#workManagerGrid");
  const empty=document.querySelector("#workManagerEmpty");
  if(!grid)return;
  const projects=[...data.projects];
  grid.innerHTML="";
  projects.forEach(p=>{
    const card=document.createElement("article");
    card.className="work-manager-card glass";
    card.dataset.id=p.id;
    const cover=p.coverImage
      ?`<div class="work-cover"><img src="${p.coverImage}" alt=""></div>`
      :`<div class="work-cover"><div class="work-cover-empty">▣</div></div>`;
    card.innerHTML=`${cover}<div class="work-card-body">
      <div class="work-card-head">
        <h4>${esc(p.name||"제목 없는 작품")}</h4>
        ${p.workLink?`<button class="work-link-btn" type="button">↗ 작품 링크</button>`:""}
      </div>
      <p class="work-card-plan">${esc((p.plan||"").trim()||"기획서가 아직 없습니다.")}</p>
    </div>`;
    card.addEventListener("click",()=>openWorkModal(p.id));
    card.querySelector(".work-link-btn")?.addEventListener("click",e=>{
      e.preventDefault();e.stopPropagation();safeOpenUrl(p.workLink);
    });
    grid.appendChild(card);
  });
  if(empty)empty.hidden=projects.length>0;
};

function populateTodoProjectSelects(){
  ensureProjectTodoData();
  const modal=document.querySelector("#todoProject");
  const filter=document.querySelector("#todoProjectFilter");
  if(modal){
    const current=modal.value;
    modal.innerHTML=`<option value="">연결 안 함</option>`+data.projects.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join("");
    if([...modal.options].some(o=>o.value===current))modal.value=current;
  }
  if(filter){
    const current=filter.value||"all";
    filter.innerHTML=`<option value="all">모든 작품</option>`+data.projects.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join("");
    filter.value=[...filter.options].some(o=>o.value===current)?current:"all";
  }
}
function priorityLabel(p){return p==="high"?"높음":p==="low"?"낮음":"보통"}
function dueLabel(date){
  if(!date)return "";
  const today=new Date(); today.setHours(0,0,0,0);
  const d=new Date(date+"T00:00:00");
  const diff=Math.round((d-today)/86400000);
  if(diff===0)return "오늘";
  if(diff===1)return "내일";
  if(diff===-1)return "어제";
  if(diff<0)return `${Math.abs(diff)}일 지남`;
  return `${diff}일 남음`;
}
function todoSort(a,b){
  if(a.done!==b.done)return a.done?1:-1;
  const ad=a.dueDate||"9999-12-31", bd=b.dueDate||"9999-12-31";
  if(ad!==bd)return ad.localeCompare(bd);
  const rank={high:0,normal:1,low:2};
  if((rank[a.priority]??1)!==(rank[b.priority]??1))return (rank[a.priority]??1)-(rank[b.priority]??1);
  return (b.updatedAt||0)-(a.updatedAt||0);
}
window.renderTodoList=function(){
  ensureProjectTodoData();
  populateTodoProjectSelects();
  const list=document.querySelector("#todoList");
  const empty=document.querySelector("#todoEmpty");
  if(!list)return;
  const projectFilter=document.querySelector("#todoProjectFilter")?.value||"all";
  let items=[...data.todos];
  if(todoFilter==="open")items=items.filter(t=>!t.done);
  if(todoFilter==="done")items=items.filter(t=>t.done);
  if(projectFilter!=="all")items=items.filter(t=>t.projectId===projectFilter);
  items.sort(todoSort);
  list.innerHTML="";
  items.forEach(t=>{
    const project=projectById(t.projectId);
    const row=document.createElement("article");
    row.className="todo-item glass"+(t.done?" done":"");
    row.dataset.id=t.id;
    const overdue=!!t.dueDate && !t.done && new Date(t.dueDate+"T00:00:00") < new Date(new Date().setHours(0,0,0,0));
    row.innerHTML=`
      <input class="todo-check" type="checkbox" ${t.done?"checked":""} aria-label="완료 체크">
      <div class="todo-main">
        <div class="todo-title-row">
          <span class="todo-title">${esc(t.title)}</span>
          <span class="todo-priority ${esc(t.priority)}">${priorityLabel(t.priority)}</span>
        </div>
        <div class="todo-meta">
          ${project?`<span>▣ ${esc(project.name)}</span>`:""}
          ${t.dueDate?`<span class="${overdue?"todo-overdue":""}">◷ ${esc(t.dueDate)} · ${esc(dueLabel(t.dueDate))}</span>`:""}
        </div>
        ${t.note?`<div class="todo-note">${esc(t.note)}</div>`:""}
      </div>
      <button type="button" class="todo-edit-btn" title="할 일 편집">⋯</button>`;
    row.querySelector(".todo-check").addEventListener("change",e=>{
      t.done=e.target.checked;
      t.updatedAt=Date.now();
      saveData();
      window.renderTodoList();
    });
    row.querySelector(".todo-main").addEventListener("click",()=>openTodoModal(t.id));
    row.querySelector(".todo-edit-btn").addEventListener("click",()=>openTodoModal(t.id));
    list.appendChild(row);
  });
  if(empty)empty.hidden=items.length>0;
  const total=data.todos.length, done=data.todos.filter(t=>t.done).length;
  document.querySelector("#todoTotalCount").textContent=String(total);
  document.querySelector("#todoOpenCount").textContent=String(total-done);
  document.querySelector("#todoDoneCount").textContent=String(done);
};
function openTodoModal(id=""){
  ensureProjectTodoData();
  populateTodoProjectSelects();
  const t=id?data.todos.find(x=>x.id===id):null;
  document.querySelector("#todoId").value=t?.id||"";
  document.querySelector("#todoTitle").value=t?.title||"";
  document.querySelector("#todoProject").value=t?.projectId||"";
  document.querySelector("#todoPriority").value=t?.priority||"normal";
  document.querySelector("#todoDueDate").value=t?.dueDate||"";
  document.querySelector("#todoNote").value=t?.note||"";
  document.querySelector("#todoModalTitle").textContent=t?"할 일 편집":"할 일 추가";
  const del=document.querySelector("#deleteTodoBtn");
  if(del)del.style.visibility=t?"visible":"hidden";
  document.querySelector("#todoModal")?.classList.add("open");
  setTimeout(()=>document.querySelector("#todoTitle")?.focus(),0);
}
function closeTodoModal(){document.querySelector("#todoModal")?.classList.remove("open")}

document.querySelector("#newWorkBtn")?.addEventListener("click",()=>openWorkModal());
document.querySelector("#closeWorkManageX")?.addEventListener("click",closeWorkModal);
document.querySelector("#cancelWorkManageBtn")?.addEventListener("click",closeWorkModal);
document.querySelector("#workManageModal")?.addEventListener("click",e=>{if(e.target.id==="workManageModal")closeWorkModal()});
document.querySelector("#pickWorkImageBtn")?.addEventListener("click",()=>document.querySelector("#workImageInput")?.click());
document.querySelector("#removeWorkImageBtn")?.addEventListener("click",()=>{workImageDraft="";setWorkImageUI()});
document.querySelector("#workImageInput")?.addEventListener("change",e=>{
  const f=e.target.files?.[0]; if(f)readWorkImage(f); e.target.value="";
});
document.querySelector("#workManageForm")?.addEventListener("submit",e=>{
  e.preventDefault();
  ensureProjectTodoData();
  const id=document.querySelector("#workManageId").value;
  const name=document.querySelector("#workManageName").value.trim();
  if(!name)return;
  let p=id?projectById(id):null;
  if(!p){
    p={id:crypto.randomUUID(),name};
    data.projects.push(p);
  }
  p.name=name;
  p.coverImage=workImageDraft;
  p.workLink=document.querySelector("#workManageLink").value.trim();
  p.plan=document.querySelector("#workManagePlan").value.trim();
  if(!data.activeProjectId)data.activeProjectId=p.id;
  saveData();
  closeWorkModal();
  window.renderWorkManager();
  window.renderTodoList();
  if(typeof renderEpisodes==="function")renderEpisodes();
});

document.querySelector("#newTodoBtn")?.addEventListener("click",()=>openTodoModal());
document.querySelector("#closeTodoX")?.addEventListener("click",closeTodoModal);
document.querySelector("#cancelTodoBtn")?.addEventListener("click",closeTodoModal);
document.querySelector("#todoModal")?.addEventListener("click",e=>{if(e.target.id==="todoModal")closeTodoModal()});
document.querySelector("#todoForm")?.addEventListener("submit",e=>{
  e.preventDefault();
  ensureProjectTodoData();
  const id=document.querySelector("#todoId").value;
  const title=document.querySelector("#todoTitle").value.trim();
  if(!title)return;
  let t=id?data.todos.find(x=>x.id===id):null;
  if(!t){
    t={id:crypto.randomUUID(),createdAt:Date.now(),done:false};
    data.todos.push(t);
  }
  t.title=title;
  t.projectId=document.querySelector("#todoProject").value;
  t.priority=document.querySelector("#todoPriority").value;
  t.dueDate=document.querySelector("#todoDueDate").value;
  t.note=document.querySelector("#todoNote").value.trim();
  t.updatedAt=Date.now();
  saveData();
  closeTodoModal();
  window.renderTodoList();
});
document.querySelector("#deleteTodoBtn")?.addEventListener("click",()=>{
  const id=document.querySelector("#todoId").value;
  if(!id)return;
  const t=data.todos.find(x=>x.id===id);
  if(!t)return;
  if(!confirm(`"${t.title}" 할 일을 삭제할까요?`))return;
  data.todos=data.todos.filter(x=>x.id!==id);
  saveData();
  closeTodoModal();
  window.renderTodoList();
});
document.querySelector("#todoProjectFilter")?.addEventListener("change",()=>window.renderTodoList());
document.querySelectorAll("[data-todo-filter]").forEach(btn=>{
  btn.addEventListener("click",()=>{
    todoFilter=btn.dataset.todoFilter;
    document.querySelectorAll("[data-todo-filter]").forEach(b=>b.classList.toggle("active",b===btn));
    window.renderTodoList();
  });
});

window.addEventListener("workroom:data-imported",()=>{
  ensureProjectTodoData();
  window.renderWorkManager();
  window.renderTodoList();
  saveData();
});

ensureProjectTodoData();
window.renderWorkManager();
window.renderTodoList();
saveData();
})();
