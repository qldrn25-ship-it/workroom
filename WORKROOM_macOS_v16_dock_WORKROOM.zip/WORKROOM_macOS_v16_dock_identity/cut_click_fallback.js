(() => {
"use strict";

/*
 Final safety net:
 - normal mode: a click on a cut card must open that cut
 - selection mode: existing selection behavior remains untouched
 This runs in bubbling phase and only acts if the modal did not open.
*/
document.addEventListener("click",e=>{
  const card=e.target.closest?.("#cutsGrid .cut-card");
  if(!card)return;

  let selecting=false;
  try{selecting=!!cutSelectMode}catch(_){}
  if(selecting)return;

  /* Image thumbnails keep their lightbox behavior. */
  if(e.target.closest?.(".cut-thumb"))return;

  const id=card.dataset.id;
  if(!id)return;

  setTimeout(()=>{
    const modal=document.querySelector("#cutModal");
    if(modal?.classList.contains("open"))return;

    try{
      if(typeof openCutModal==="function"){
        openCutModal(id);
      }
    }catch(err){
      console.error("cut click fallback:",err);

      /* Last-resort basic editor opening, without optional extensions. */
      try{
        const ep=typeof activeEpisode==="function"?activeEpisode():null;
        const c=ep?.cuts?.find(x=>String(x.id)===String(id));
        if(!c||!modal)return;

        const idx=ep.cuts.findIndex(x=>String(x.id)===String(id));
        const set=(sel,val)=>{
          const el=document.querySelector(sel);
          if(el)el.value=val??"";
        };

        const title=document.querySelector("#cutModalTitle");
        if(title)title.textContent=`${ep.name} · CUT ${idx+1}`;

        set("#cutId",c.id);
        set("#cutDescription",c.description||"");
        set("#cutDialogue",c.dialogue||"");
        set("#cutStatus",c.status||"todo");
        set("#cutTag",c.tag||"");
        set("#cutCharacters",c.characters||"");
        set("#cutNote",c.note||"");

        const important=document.querySelector("#cutImportant");
        if(important)important.checked=!!c.important;

        modal.classList.add("open");
      }catch(inner){
        console.error("basic cut editor fallback:",inner);
      }
    }
  },0);
},false);

console.info("WORKROOM v92 cut click fallback loaded");
})();