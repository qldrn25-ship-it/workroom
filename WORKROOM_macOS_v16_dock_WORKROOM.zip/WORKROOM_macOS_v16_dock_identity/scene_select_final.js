(() => {
"use strict";

const q=s=>document.querySelector(s);

function getActiveEpisode(){
  try{
    if(typeof activeEpisode==="function"){
      const ep=activeEpisode();
      if(ep)return ep;
    }
  }catch(_){}

  if(typeof data!=="undefined"){
    const id=data.activeEpisodeId||q("#episodeSelect")?.value;
    return (data.episodes||[]).find(e=>String(e.id)===String(id))||null;
  }
  return null;
}

function getCurrentCut(){
  const ep=getActiveEpisode();
  const id=q("#cutId")?.value;
  return ep?.cuts?.find(c=>String(c.id)===String(id))||null;
}

function currentScenes(){
  if(typeof data==="undefined")return [];
  if(!Array.isArray(data.scenes))data.scenes=[];
  const ep=getActiveEpisode();
  if(!ep)return [];
  return data.scenes.filter(s=>String(s.episodeId)===String(ep.id));
}

function fillSceneSelect(preferred){
  const sel=q("#cutScene");
  if(!sel)return;

  const scenes=currentScenes();
  const desired=preferred!==undefined
    ? String(preferred||"")
    : String(sel.value||getCurrentCut()?.sceneId||"");

  sel.disabled=false;
  sel.hidden=false;
  sel.removeAttribute("aria-hidden");
  sel.style.display="block";
  sel.style.visibility="visible";
  sel.style.opacity="1";
  sel.style.pointerEvents="auto";

  sel.innerHTML="";
  const none=document.createElement("option");
  none.value="";
  none.textContent="장면 없음";
  sel.appendChild(none);

  scenes.forEach(scene=>{
    const opt=document.createElement("option");
    opt.value=String(scene.id);
    opt.textContent=scene.name||"이름 없는 장면";
    sel.appendChild(opt);
  });

  if([...sel.options].some(o=>String(o.value)===desired)){
    sel.value=desired;
  }else{
    sel.value="";
  }

  const help=q("#cutSceneHelp");
  if(help){
    help.textContent=scenes.length
      ? `현재 회차 장면 ${scenes.length}개`
      : "현재 회차에 등록된 장면이 없습니다. 장면 관리에서 먼저 장면을 추가하세요.";
  }
}

function saveScene(){
  const cut=getCurrentCut();
  const sel=q("#cutScene");
  if(!cut||!sel)return;

  cut.sceneId=sel.value||"";

  try{
    if(typeof saveData==="function")saveData();
  }catch(err){
    console.error("scene save failed",err);
  }

  try{
    if(typeof applyAdvancedCardDecorations==="function")applyAdvancedCardDecorations();
  }catch(_){}
}

/* Scene selection is owned here, independently of previous advanced wrappers. */
q("#cutScene")?.addEventListener("change",saveScene);

/* Wrap the final openCutModal after every earlier module has loaded. */
if(typeof openCutModal==="function"){
  const previousOpenCutModal=openCutModal;
  openCutModal=function(id){
    const result=previousOpenCutModal(id);

    requestAnimationFrame(()=>{
      const cut=getCurrentCut();
      fillSceneSelect(cut?.sceneId||"");
    });

    setTimeout(()=>{
      const cut=getCurrentCut();
      fillSceneSelect(cut?.sceneId||"");
    },30);

    return result;
  };
}

/* Also repopulate whenever the modal becomes open, even if another script opens it directly. */
const modal=q("#cutModal");
if(modal){
  const observer=new MutationObserver(()=>{
    if(modal.classList.contains("open")){
      const cut=getCurrentCut();
      fillSceneSelect(cut?.sceneId||"");
    }
  });
  observer.observe(modal,{attributes:true,attributeFilter:["class"]});
}

/* Scene creation/editing can happen while the cut editor exists. */
q("#sceneForm")?.addEventListener("submit",()=>{
  setTimeout(()=>{
    const cut=getCurrentCut();
    fillSceneSelect(cut?.sceneId||"");
  },50);
});

console.info("WORKROOM v93 final scene select loaded");
})();