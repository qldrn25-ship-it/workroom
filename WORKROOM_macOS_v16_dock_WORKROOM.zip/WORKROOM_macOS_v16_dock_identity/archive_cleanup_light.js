(() => {
"use strict";

const q=s=>document.querySelector(s);
const qa=s=>[...document.querySelectorAll(s)];

function removeArchiveArtifacts(){
  qa(
    "#toggleArchiveBtn, #archiveProjectBtn, #archivedProjectsSection, " +
    ".archive-project-card, .archive-synth-card, .archive-project-badge, .project-archived-badge"
  ).forEach(el=>el.remove());
}

function restoreArchivedProjectsOnce(){
  if(typeof data==="undefined" || !Array.isArray(data.projects)) return;

  let changed=false;

  data.projects.forEach(project=>{
    if(project.archived){
      project.archived=false;
      changed=true;
    }
  });

  [
    "webtoonWorkroom.archiveView.v33",
    "webtoonWorkroom.archiveView.v35"
  ].forEach(key=>localStorage.removeItem(key));

  if(changed){
    try{
      if(typeof saveData==="function"){
        saveData();
      }else if(typeof STORAGE_KEY!=="undefined"){
        localStorage.setItem(STORAGE_KEY,JSON.stringify(data));
      }
    }catch(err){
      console.error("archive cleanup save failed",err);
    }
  }
}

function makeProjectOptionsVisible(){
  const sel=q("#projectSelect");
  if(!sel)return;

  [...sel.options].forEach(opt=>{
    opt.hidden=false;
    const project=(data.projects||[]).find(p=>p.id===opt.value);
    if(project)opt.textContent=project.name;
  });
}

function removeFavoriteDeleteButtons(){
  qa("#favoriteList .shortcut-item button, #favoriteList .mini-remove").forEach(el=>el.remove());
}

function cleanOnce(){
  restoreArchivedProjectsOnce();
  removeArchiveArtifacts();
  makeProjectOptionsVisible();
  removeFavoriteDeleteButtons();
}

/* One initial cleanup only. No DOM observer, no recursive rerender. */
setTimeout(cleanOnce, 80);

/* Re-run only on explicit data import or known screen changes. */
window.addEventListener("workroom:data-imported",()=>setTimeout(cleanOnce,80));

qa('.nav-btn[data-view="dashboard"], .nav-btn[data-view="cuts"]').forEach(btn=>{
  btn.addEventListener("click",()=>setTimeout(()=>{
    removeArchiveArtifacts();
    makeProjectOptionsVisible();
    removeFavoriteDeleteButtons();
  },50));
});

q("#projectSelect")?.addEventListener("change",()=>setTimeout(makeProjectOptionsVisible,30));

console.info("WORKROOM v37 lightweight archive cleanup loaded");
})();