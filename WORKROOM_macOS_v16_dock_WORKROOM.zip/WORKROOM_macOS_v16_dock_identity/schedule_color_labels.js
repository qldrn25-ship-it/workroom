(() => {
"use strict";

const q=s=>document.querySelector(s);
const qa=s=>[...document.querySelectorAll(s)];
const SAVED_KEY="webtoonWorkroom.scheduleSavedColors.v49";
const DEFAULT_COLOR="#9b765f";

let scheduleColorDraft=DEFAULT_COLOR;

function normalizeHex(value){
  let v=String(value||"").trim();
  if(!v)return "";
  if(!v.startsWith("#"))v="#"+v;
  if(/^#[0-9a-fA-F]{6}$/.test(v))return v.toLowerCase();
  if(/^#[0-9a-fA-F]{3}$/.test(v)){
    return ("#"+v.slice(1).split("").map(x=>x+x).join("")).toLowerCase();
  }
  return "";
}

function getSavedColors(){
  try{
    const parsed=JSON.parse(localStorage.getItem(SAVED_KEY)||"[]");
    if(Array.isArray(parsed))return [...new Set(parsed.map(normalizeHex).filter(Boolean))];
  }catch(_){}
  return [];
}

function setSavedColors(colors){
  localStorage.setItem(SAVED_KEY,JSON.stringify([...new Set(colors.map(normalizeHex).filter(Boolean))].slice(0,24)));
}

function setDraftColor(value){
  const normalized=normalizeHex(value);
  scheduleColorDraft=normalized;

  const picker=q("#scheduleColor");
  const hex=q("#scheduleColorHex");

  if(normalized){
    if(picker)picker.value=normalized;
    if(hex)hex.value=normalized.toUpperCase();
  }else{
    if(hex)hex.value="";
  }

  renderSavedColors();
}

function renderSavedColors(){
  const box=q("#savedScheduleColors");
  if(!box)return;
  box.innerHTML="";

  getSavedColors().forEach(color=>{
    const chip=document.createElement("button");
    chip.type="button";
    chip.className="saved-color-chip"+(scheduleColorDraft===color?" selected":"");
    chip.style.background=color;
    chip.title=color.toUpperCase();
    chip.innerHTML='<span class="remove-saved-color" title="저장 색상 삭제">×</span>';

    chip.addEventListener("click",e=>{
      if(e.target.closest(".remove-saved-color"))return;
      setDraftColor(color);
    });

    chip.querySelector(".remove-saved-color").addEventListener("click",e=>{
      e.preventDefault();
      e.stopPropagation();
      setSavedColors(getSavedColors().filter(x=>x!==color));
      renderSavedColors();
    });

    box.appendChild(chip);
  });
}

function currentScheduleFromModal(){
  if(typeof data==="undefined")return null;
  const id=q("#scheduleId")?.value||"";
  if(!id)return null;
  return (data.schedules||[]).find(s=>String(s.id)===String(id))||null;
}

function loadScheduleColor(){
  const s=currentScheduleFromModal();
  setDraftColor(normalizeHex(s?.colorLabel)||DEFAULT_COLOR);
}

function saveColorToCurrentSchedule(){
  const s=currentScheduleFromModal();
  if(!s)return;
  s.colorLabel=scheduleColorDraft||"";

  try{
    if(typeof saveData==="function")saveData();
  }catch(err){
    console.error("schedule color save failed",err);
  }
}

function saveColorIntoScheduleObjectOnSubmit(){
  // app.js creates/replaces schedule on submit. We update the saved object immediately after.
  setTimeout(()=>{
    const id=q("#scheduleId")?.value||"";
    let schedule=null;

    if(id){
      schedule=(data.schedules||[]).find(s=>String(s.id)===String(id));
    }

    // When the original form reset/close cleared the id, locate the newest matching event.
    if(!schedule){
      const date=q("#scheduleDate")?.value||"";
      const title=q("#scheduleTitle")?.value.trim()||"";
      const candidates=(data.schedules||[]).filter(s=>
        (!date||s.date===date) &&
        (!title||s.title===title)
      );
      schedule=candidates.sort((a,b)=>String(b.id).localeCompare(String(a.id)))[0]||null;
    }

    if(schedule){
      schedule.colorLabel=scheduleColorDraft||"";
      try{if(typeof saveData==="function")saveData()}catch(_){}
      try{if(typeof renderCalendar==="function")renderCalendar()}catch(_){}
      setTimeout(decorateCalendarColors,20);
    }
  },0);
}

function decorateCalendarColors(){
  if(typeof data==="undefined")return;

  // Use rendered event-chip text/title to map back to schedule objects.
  qa("#calendarGrid .event-chip:not(.deadline-chip)").forEach(chip=>{
    chip.classList.remove("has-custom-color");
    chip.style.removeProperty("--schedule-color");

    const text=(chip.textContent||"").trim();
    const title=chip.title||"";

    const schedule=(data.schedules||[]).find(s=>{
      const renderedText=`${s.stage} · ${s.title}`.trim();
      const renderedTitle=`${s.project||""} ${s.episode||""} / ${s.progress||0}%`.trim();
      return renderedText===text && renderedTitle===title.trim();
    });

    const color=normalizeHex(schedule?.colorLabel);
    if(color){
      chip.classList.add("has-custom-color");
      chip.style.setProperty("--schedule-color",color);
      chip.dataset.scheduleColor=color;
    }
  });
}

/* Picker + hex */
q("#scheduleColor")?.addEventListener("input",e=>setDraftColor(e.target.value));
q("#scheduleColorHex")?.addEventListener("input",e=>{
  const v=normalizeHex(e.target.value);
  if(v)setDraftColor(v);
});
q("#scheduleColorHex")?.addEventListener("blur",e=>{
  const v=normalizeHex(e.target.value);
  if(v)setDraftColor(v);
  else e.target.value=scheduleColorDraft?scheduleColorDraft.toUpperCase():"";
});

q("#saveScheduleColorBtn")?.addEventListener("click",()=>{
  const color=normalizeHex(scheduleColorDraft);
  if(!color)return;
  const colors=getSavedColors();
  if(!colors.includes(color)){
    colors.unshift(color);
    setSavedColors(colors);
  }
  renderSavedColors();
});

q("#clearScheduleColorBtn")?.addEventListener("click",()=>{
  scheduleColorDraft="";
  const hex=q("#scheduleColorHex");
  if(hex)hex.value="";
  renderSavedColors();
});

/* Modal opening: detect new/edit schedule by button clicks and modal class. */
document.addEventListener("click",e=>{
  const chip=e.target.closest?.(".event-chip:not(.deadline-chip)");
  const add=e.target.closest?.("#addScheduleBtn");
  if(chip||add){
    setTimeout(()=>{
      if(add)setDraftColor(DEFAULT_COLOR);
      else loadScheduleColor();
    },30);
  }
},true);

const modal=q("#scheduleModal");
if(modal){
  const observer=new MutationObserver(()=>{
    if(modal.classList.contains("open")){
      setTimeout(loadScheduleColor,10);
    }
  });
  observer.observe(modal,{attributes:true,attributeFilter:["class"]});
}

/* Save color on form submit. */
q("#scheduleForm")?.addEventListener("submit",()=>{
  saveColorToCurrentSchedule();
  saveColorIntoScheduleObjectOnSubmit();
},true);

/* Patch renderCalendar only for decoration, not for core rendering. */
if(typeof renderCalendar==="function"){
  const originalRenderCalendar=renderCalendar;
  renderCalendar=function(){
    const result=originalRenderCalendar.apply(this,arguments);
    requestAnimationFrame(decorateCalendarColors);
    return result;
  };
}

renderSavedColors();
setTimeout(decorateCalendarColors,100);

console.info("WORKROOM Local v49 schedule color labels loaded");
})();