(() => {
"use strict";

const q=s=>document.querySelector(s);
const qa=s=>[...document.querySelectorAll(s)];

let sweep=null;
let suppressNextClick=false;

function inCutSelectMode(){
  try{return !!cutSelectMode}catch(_){return false}
}

function hasCut(id){
  try{return selectedCutIds.has(id)}catch(_){return false}
}

function setCutSelected(id,selected){
  try{
    if(selected)selectedCutIds.add(id);
    else selectedCutIds.delete(id);
  }catch(_){}
}

function syncSelection(){
  try{if(typeof syncBulkSelectionUI==="function")syncBulkSelectionUI()}catch(_){}
  qa("#cutsGrid .cut-card").forEach(card=>{
    const id=card.dataset.id;
    card.classList.toggle("selected",hasCut(id));
  });
}

function cardAtPoint(x,y){
  const el=document.elementFromPoint(x,y);
  return el?.closest?.("#cutsGrid .cut-card")||null;
}

function touchCard(card){
  if(!sweep||!card)return;
  const id=card.dataset.id;
  if(!id||sweep.touched.has(id))return;

  sweep.touched.add(id);
  setCutSelected(id,sweep.selecting);
  card.classList.toggle("selected",sweep.selecting);
  card.classList.add("sweep-touched");
  syncSelection();
}

function finishSweep(){
  if(!sweep)return;
  document.body.classList.remove("cut-sweep-selecting");
  qa("#cutsGrid .cut-card.sweep-touched").forEach(c=>c.classList.remove("sweep-touched"));
  sweep=null;
}

document.addEventListener("pointerdown",e=>{
  if(!inCutSelectMode()||e.button!==0)return;

  const card=e.target.closest?.("#cutsGrid .cut-card");
  if(!card)return;

  const startX=e.clientX;
  const startY=e.clientY;
  const startId=card.dataset.id;
  let started=false;

  function move(ev){
    if(!started){
      const distance=Math.hypot(ev.clientX-startX,ev.clientY-startY);
      if(distance<6)return;

      started=true;
      sweep={
        selecting:!hasCut(startId),
        touched:new Set()
      };
      document.body.classList.add("cut-sweep-selecting");
      touchCard(card);
    }

    ev.preventDefault();
    touchCard(cardAtPoint(ev.clientX,ev.clientY));
  }

  function up(){
    window.removeEventListener("pointermove",move,true);
    window.removeEventListener("pointerup",up,true);
    window.removeEventListener("pointercancel",cancel,true);

    if(started){
      suppressNextClick=true;
      finishSweep();
    }
  }

  function cancel(){
    window.removeEventListener("pointermove",move,true);
    window.removeEventListener("pointerup",up,true);
    window.removeEventListener("pointercancel",cancel,true);
    finishSweep();
  }

  window.addEventListener("pointermove",move,true);
  window.addEventListener("pointerup",up,true);
  window.addEventListener("pointercancel",cancel,true);
},true);

/* Existing card onclick toggles selection after pointerup.
   Suppress it only after a sweep drag, not after a normal click. */
document.addEventListener("click",e=>{
  if(!suppressNextClick)return;
  const card=e.target.closest?.("#cutsGrid .cut-card");
  if(!card)return;

  suppressNextClick=false;
  e.preventDefault();
  e.stopPropagation();
  e.stopImmediatePropagation();
},true);

/* Colored bulk-status buttons keep old select-based logic intact. */
function syncStatusTags(){
  const select=q("#bulkStatusSelect");
  if(!select)return;
  qa("#bulkStatusTags .bulk-status-tag").forEach(btn=>{
    btn.classList.toggle("active",btn.dataset.status===select.value);
  });
}

qa("#bulkStatusTags .bulk-status-tag").forEach(btn=>{
  btn.addEventListener("click",e=>{
    e.preventDefault();
    e.stopPropagation();

    const select=q("#bulkStatusSelect");
    if(!select)return;

    select.value=btn.dataset.status;
    select.dispatchEvent(new Event("change",{bubbles:true}));
    syncStatusTags();
  });
});

q("#bulkStatusSelect")?.addEventListener("change",syncStatusTags);

syncStatusTags();

console.info("WORKROOM v81 cut sweep select + status tags loaded");
})();