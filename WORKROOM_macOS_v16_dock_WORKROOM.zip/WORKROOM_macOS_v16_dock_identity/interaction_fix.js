(() => {
"use strict";

const q=s=>document.querySelector(s);
const qa=s=>[...document.querySelectorAll(s)];
const esc=v=>String(v??"").replace(/[&<>"']/g,m=>({
  "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
}[m]));

function getEpisode(){
  try{
    if(typeof activeEpisode==="function") return activeEpisode();
  }catch(_){}
  if(typeof data!=="undefined"){
    return data.episodes?.find(e=>e.id===data.activeEpisodeId) || null;
  }
  return null;
}

function getProject(){
  try{
    if(typeof activeProject==="function") return activeProject();
  }catch(_){}
  if(typeof data!=="undefined"){
    return data.projects?.find(p=>p.id===data.activeProjectId) || null;
  }
  return null;
}

function openCutSafe(id){
  try{
    if(typeof openCutModal==="function") openCutModal(id);
  }catch(err){
    console.error("openCutModal failed",err);
  }
}

/* ---------- robust tabs ---------- */
const paneMap={
  board:"#advancedBoardPane",
  dialogue:"#advancedDialoguePane",
  characters:"#advancedCharactersPane",
  stats:"#advancedStatsPane"
};

function showPane(name){
  qa(".adv-tab").forEach(btn=>{
    btn.classList.toggle("active",btn.dataset.advtab===name);
    btn.setAttribute("aria-pressed",btn.dataset.advtab===name?"true":"false");
  });

  qa(".advanced-pane").forEach(p=>p.classList.remove("active"));
  const pane=q(paneMap[name]);
  if(pane)pane.classList.add("active");

  if(name==="dialogue") renderDialogueSafe();
  if(name==="characters") renderCharacterDialogueSafe();
  if(name==="stats") renderStatsSafe();
}

/* capture 단계에서 클릭을 직접 처리해 다른 핸들러 오류의 영향을 받지 않음 */
document.addEventListener("click",e=>{
  const btn=e.target.closest?.(".adv-tab");
  if(!btn)return;
  e.preventDefault();
  e.stopPropagation();
  showPane(btn.dataset.advtab||"board");
},true);

/* ---------- dialogue ---------- */
function renderDialogueSafe(){
  const box=q("#dialogueView"),ep=getEpisode();
  if(!box)return;
  box.innerHTML="";
  if(!ep){
    box.innerHTML="<div class='empty-state'>선택된 회차가 없습니다.</div>";
    return;
  }

  (ep.cuts||[]).forEach((c,i)=>{
    const row=document.createElement("div");
    row.className="dialogue-row";
    row.innerHTML=
      `<div class="dialogue-row-head">
        <strong>CUT ${i+1}</strong>
        <small>${esc(c.characters||"")}</small>
      </div>
      <p>${esc(c.dialogue||"(대사 없음)")}</p>`;
    row.addEventListener("click",()=>openCutSafe(c.id));
    box.appendChild(row);
  });
}

/* ---------- character dialogue ---------- */
function cutCharacters(c){
  if(Array.isArray(c.characterList))return c.characterList.map(x=>String(x).trim()).filter(Boolean);
  return String(c.characters||"").split(/[,，]/).map(x=>x.trim()).filter(Boolean);
}

function renderCharacterDialogueSafe(){
  const sel=q("#characterDialogueSelect"),box=q("#characterDialogueView"),ep=getEpisode();
  if(!sel||!box)return;

  if(!ep){
    sel.innerHTML="";
    box.innerHTML="<div class='empty-state'>선택된 회차가 없습니다.</div>";
    return;
  }

  const chars=[...new Set((ep.cuts||[]).flatMap(c=>cutCharacters(c)))];
  const previous=sel.value;
  sel.innerHTML=chars.map(name=>`<option value="${esc(name)}">${esc(name)}</option>`).join("");

  if(chars.includes(previous))sel.value=previous;
  const target=sel.value||chars[0]||"";

  box.innerHTML="";
  if(!target){
    box.innerHTML="<div class='empty-state'>등장인물이 지정된 컷이 없습니다.</div>";
    return;
  }

  (ep.cuts||[]).forEach((c,i)=>{
    if(!cutCharacters(c).includes(target))return;
    const row=document.createElement("div");
    row.className="dialogue-row";
    row.innerHTML=
      `<div class="dialogue-row-head">
        <strong>CUT ${i+1}</strong>
        <small>${esc(target)}</small>
      </div>
      <p>${esc(c.dialogue||"(대사 없음)")}</p>`;
    row.addEventListener("click",()=>openCutSafe(c.id));
    box.appendChild(row);
  });
}
q("#characterDialogueSelect")?.addEventListener("change",renderCharacterDialogueSafe);

/* ---------- stats ---------- */
function renderStatsSafe(){
  const box=q("#episodeStatsGrid"),ep=getEpisode();
  if(!box)return;

  if(!ep){
    box.innerHTML="<div class='empty-state'>선택된 회차가 없습니다.</div>";
    return;
  }

  const cuts=ep.cuts||[];
  const charCounts={};
  const bgCounts={};

  cuts.forEach(c=>{
    cutCharacters(c).forEach(n=>charCounts[n]=(charCounts[n]||0)+1);
    if(c.background)bgCounts[c.background]=(bgCounts[c.background]||0)+1;
  });

  const avg=cuts.length
    ? Math.round(cuts.reduce((sum,c)=>sum+Number(c.estimatedMinutes||0),0)/cuts.length)
    : 0;

  let sceneCount=0;
  try{
    if(typeof data!=="undefined"&&Array.isArray(data.scenes)){
      sceneCount=data.scenes.filter(s=>s.episodeId===ep.id).length;
    }
  }catch(_){}

  const topCharacter=Object.entries(charCounts).sort((a,b)=>b[1]-a[1])[0];
  const topBackground=Object.entries(bgCounts).sort((a,b)=>b[1]-a[1])[0];

  const stats=[
    ["총 컷 수",cuts.length],
    ["대사 있는 컷",cuts.filter(c=>String(c.dialogue||"").trim()).length],
    ["무대사 컷",cuts.filter(c=>!String(c.dialogue||"").trim()).length],
    ["수정 필요",cuts.filter(c=>c.feedbackStatus==="needs").length],
    ["평균 예상 시간",`${avg}분`],
    ["장면 수",sceneCount],
    ["가장 많이 등장",topCharacter?`${topCharacter[0]} · ${topCharacter[1]}컷`:"-"],
    ["가장 많이 쓰는 배경",topBackground?`${topBackground[0]} · ${topBackground[1]}컷`:"-"]
  ];

  box.innerHTML=stats.map(([name,value])=>
    `<div class="stat-card"><span>${esc(name)}</span><strong>${esc(value)}</strong></div>`
  ).join("");
}

/* ---------- review mode ---------- */
/* v39: review mode is handled exclusively by review_fix.js.
   The previous document-capture handler used stopImmediatePropagation()
   and prevented the later, corrected review resolver from ever running. */

/* re-render when project/episode changes */
q("#projectSelect")?.addEventListener("change",()=>{
  setTimeout(()=>{
    renderDialogueSafe();
    renderCharacterDialogueSafe();
    renderStatsSafe();
  },20);
});
q("#episodeSelect")?.addEventListener("change",()=>{
  setTimeout(()=>{
    renderDialogueSafe();
    renderCharacterDialogueSafe();
    renderStatsSafe();
  },20);
});

/* initialize */
showPane("board");
renderDialogueSafe();
renderCharacterDialogueSafe();
renderStatsSafe();

console.info("WORKROOM v30 interaction repair loaded");
})();