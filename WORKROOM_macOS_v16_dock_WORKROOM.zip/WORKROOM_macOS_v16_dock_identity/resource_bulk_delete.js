(() => {
"use strict";

const q=s=>document.querySelector(s);
const qa=s=>[...document.querySelectorAll(s)];

let resourceSelectMode=false;
let selectedResourceIds=new Set();
let sweep=null;
let suppressClickUntil=0;

function cards(){
  return qa("#resourceGrid .resource-card");
}
function idOf(card){
  return String(card?.dataset?.id||"");
}
function visibleResourceIds(){
  return cards().map(idOf).filter(Boolean);
}
function sync(){
  const menu=q("#resourceSelectMenu");
  const box=q("#resourceBulkBox");
  const trigger=q("#toggleResourceSelectBtn");

  if(box)box.classList.toggle("active",resourceSelectMode);
  if(trigger){
    trigger.innerHTML=`☑ 선택 <span class="menu-caret">${menu?.classList.contains("open")?"▴":"▾"}</span>`;
  }

  cards().forEach(card=>{
    const id=idOf(card);
    card.classList.toggle("resource-select-mode",resourceSelectMode);
    card.classList.toggle("resource-selected",selectedResourceIds.has(id));
  });

  const count=q("#resourceSelectedCount");
  if(count)count.textContent=`${selectedResourceIds.size}개 선택`;

  const ids=visibleResourceIds();
  const all=ids.length>0&&ids.every(id=>selectedResourceIds.has(id));

  const allBtn=q("#toggleAllResourcesBtn");
  if(allBtn){
    allBtn.textContent=all?"전체선택해제":"전체선택";
    allBtn.disabled=!ids.length;
  }

  const del=q("#deleteSelectedResourcesBtn");
  if(del)del.disabled=selectedResourceIds.size===0;
}

function refresh(){
  try{if(typeof renderResources==="function")renderResources()}catch(err){console.error(err)}
  requestAnimationFrame(sync);
}

function setSelected(id,value){
  if(!id)return;
  if(value)selectedResourceIds.add(id);
  else selectedResourceIds.delete(id);
}

q("#toggleResourceSelectBtn")?.addEventListener("click",e=>{
  e.preventDefault();
  e.stopPropagation();

  const menu=q("#resourceSelectMenu");
  const opening=!menu?.classList.contains("open");
  menu?.classList.toggle("open",opening);

  if(opening){
    resourceSelectMode=true;
  }else{
    resourceSelectMode=false;
    selectedResourceIds.clear();
  }
  sync();
});

document.addEventListener("click",e=>{
  if(!e.target.closest?.("#resourceSelectMenu")){
    const menu=q("#resourceSelectMenu");
    if(menu?.classList.contains("open")){
      menu.classList.remove("open");
      resourceSelectMode=false;
      selectedResourceIds.clear();
    }
    sync();
  }
});

window.addEventListener("keydown",e=>{
  if(e.key==="Escape"){
    q("#resourceSelectMenu")?.classList.remove("open");
    resourceSelectMode=false;
    selectedResourceIds.clear();
    sync();
  }
});

q("#toggleAllResourcesBtn")?.addEventListener("click",e=>{
  e.preventDefault();
  e.stopPropagation();

  const ids=visibleResourceIds();
  const all=ids.length>0&&ids.every(id=>selectedResourceIds.has(id));

  if(all)ids.forEach(id=>selectedResourceIds.delete(id));
  else ids.forEach(id=>selectedResourceIds.add(id));

  sync();
});

q("#clearResourceSelectionBtn")?.addEventListener("click",e=>{
  e.preventDefault();
  e.stopPropagation();

  selectedResourceIds.clear();
  resourceSelectMode=false;
  q("#resourceSelectMenu")?.classList.remove("open");
  sync();
});

q("#deleteSelectedResourcesBtn")?.addEventListener("click",e=>{
  e.preventDefault();
  e.stopPropagation();

  if(!selectedResourceIds.size)return;
  if(!confirm(`선택한 자료 ${selectedResourceIds.size}개를 삭제할까요?`))return;
  if(typeof data==="undefined"||!Array.isArray(data.resources))return;

  data.resources=data.resources.filter(item=>!selectedResourceIds.has(String(item.id)));

  try{if(typeof saveData==="function")saveData()}catch(err){console.error(err)}

  selectedResourceIds.clear();
  refresh();
});

/* Normal single-click selection in selection mode. */
document.addEventListener("click",e=>{
  if(!resourceSelectMode||Date.now()<suppressClickUntil)return;

  const card=e.target.closest?.("#resourceGrid .resource-card");
  if(!card)return;

  e.preventDefault();
  e.stopPropagation();
  e.stopImmediatePropagation();

  const id=idOf(card);
  if(!id)return;

  setSelected(id,!selectedResourceIds.has(id));
  sync();
},true);

/* Sweep / drag selection. */
function cardAtPoint(x,y){
  return document.elementFromPoint(x,y)?.closest?.("#resourceGrid .resource-card")||null;
}
function touch(card){
  if(!sweep||!card)return;
  const id=idOf(card);
  if(!id||sweep.touched.has(id))return;

  sweep.touched.add(id);
  setSelected(id,sweep.selecting);
  card.classList.toggle("resource-selected",sweep.selecting);
  card.classList.add("sweep-touched");
  sync();
}
function finishSweep(){
  document.body.classList.remove("resource-sweep-selecting");
  cards().forEach(c=>c.classList.remove("sweep-touched"));
  sweep=null;
}

document.addEventListener("pointerdown",e=>{
  if(!resourceSelectMode||e.button!==0)return;

  const card=e.target.closest?.("#resourceGrid .resource-card");
  if(!card)return;

  const sx=e.clientX,sy=e.clientY;
  const startId=idOf(card);
  let started=false;

  function move(ev){
    if(!started){
      if(Math.hypot(ev.clientX-sx,ev.clientY-sy)<6)return;

      started=true;
      sweep={
        selecting:!selectedResourceIds.has(startId),
        touched:new Set()
      };
      document.body.classList.add("resource-sweep-selecting");
      touch(card);
    }

    ev.preventDefault();
    touch(cardAtPoint(ev.clientX,ev.clientY));
  }

  function up(){
    window.removeEventListener("pointermove",move,true);
    window.removeEventListener("pointerup",up,true);
    window.removeEventListener("pointercancel",cancel,true);

    if(started){
      suppressClickUntil=Date.now()+350;
      finishSweep();
    }
  }

  function cancel(){
    window.removeEventListener("pointermove",move,true);
    window.removeEventListener("pointerup",up,true);
    window.removeEventListener("pointercancel",cancel,true);
    finishSweep();
  }

  window.addEventListener("pointermove",move,true);
  window.addEventListener("pointerup",up,true);
  window.addEventListener("pointercancel",cancel,true);
},true);

/* Reapply selection after resource cards are rebuilt. */
["resourceProjectSelect","resourceKindFilter"].forEach(id=>{
  q("#"+id)?.addEventListener("change",()=>setTimeout(sync,30));
});

const grid=q("#resourceGrid");
if(grid){
  const obs=new MutationObserver(()=>requestAnimationFrame(sync));
  obs.observe(grid,{childList:true});
}

setTimeout(sync,100);

window.__workroomResourceSelectionActive=()=>resourceSelectMode;
window.__workroomEndResourceSelection=()=>{
  resourceSelectMode=false;
  selectedResourceIds.clear();
  q("#resourceSelectMenu")?.classList.remove("open");
  sync();
};
console.info("WORKROOM v105 resource selection rebuilt");
})();