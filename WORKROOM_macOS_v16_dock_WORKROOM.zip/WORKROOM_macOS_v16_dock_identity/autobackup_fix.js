(() => {
"use strict";

const q=s=>document.querySelector(s);
const DB_NAME="WORKROOM_Backups_v71";
const STORE_NAME="snapshots";
const MAX=8;
let dbPromise=null;

function openDB(){
  if(dbPromise)return dbPromise;

  dbPromise=new Promise((resolve,reject)=>{
    if(!("indexedDB" in window)){
      reject(new Error("이 브라우저는 IndexedDB를 지원하지 않습니다."));
      return;
    }

    const req=indexedDB.open(DB_NAME,1);

    req.onupgradeneeded=()=>{
      const db=req.result;
      if(!db.objectStoreNames.contains(STORE_NAME)){
        const store=db.createObjectStore(STORE_NAME,{keyPath:"id"});
        store.createIndex("at","at");
      }
    };

    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error||new Error("백업 데이터베이스를 열 수 없습니다."));
  });

  return dbPromise;
}

async function allSnapshots(){
  const db=await openDB();
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(STORE_NAME,"readonly");
    const req=tx.objectStore(STORE_NAME).getAll();
    req.onsuccess=()=>{
      const items=Array.isArray(req.result)?req.result:[];
      items.sort((a,b)=>(b.at||0)-(a.at||0));
      resolve(items);
    };
    req.onerror=()=>reject(req.error);
  });
}

async function putSnapshot(item){
  const db=await openDB();
  await new Promise((resolve,reject)=>{
    const tx=db.transaction(STORE_NAME,"readwrite");
    tx.objectStore(STORE_NAME).put(item);
    tx.oncomplete=()=>resolve();
    tx.onerror=()=>reject(tx.error);
    tx.onabort=()=>reject(tx.error||new Error("백업 저장이 중단되었습니다."));
  });

  const items=await allSnapshots();
  const excess=items.slice(MAX);

  if(excess.length){
    await new Promise((resolve,reject)=>{
      const tx=db.transaction(STORE_NAME,"readwrite");
      const store=tx.objectStore(STORE_NAME);
      excess.forEach(x=>store.delete(x.id));
      tx.oncomplete=()=>resolve();
      tx.onerror=()=>reject(tx.error);
    });
  }
}

async function deleteAllSnapshots(){
  const db=await openDB();
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(STORE_NAME,"readwrite");
    tx.objectStore(STORE_NAME).clear();
    tx.oncomplete=()=>resolve();
    tx.onerror=()=>reject(tx.error);
  });
}

function snapshotPayload(){
  if(typeof data==="undefined")throw new Error("WORKROOM 데이터를 찾을 수 없습니다.");

  // structuredClone keeps large data out of localStorage and avoids JSON duplication
  // until IndexedDB serializes it.
  try{
    return structuredClone(data);
  }catch(_){
    return JSON.parse(JSON.stringify(data));
  }
}

async function makeSnapshot(reason="manual"){
  const item={
    id:crypto.randomUUID?.()||String(Date.now()),
    at:Date.now(),
    reason,
    data:snapshotPayload()
  };

  await putSnapshot(item);
  await render();
  return item;
}

async function restoreSnapshot(id){
  const items=await allSnapshots();
  const item=items.find(x=>x.id===id);
  if(!item)return;

  if(!confirm("이 백업 시점으로 데이터를 복원할까요?\n현재 데이터는 덮어씌워집니다."))return;

  try{
    const restored=item.data;
    Object.keys(data).forEach(k=>delete data[k]);
    Object.assign(data,structuredClone(restored));

    if(typeof saveData==="function")saveData();

    alert("백업 데이터를 복원했습니다.");
    location.reload();
  }catch(err){
    alert("백업 복원에 실패했습니다.\n"+(err?.message||err));
  }
}

async function render(){
  const status=q("#backupStatus");
  const box=q("#snapshotList");

  try{
    const items=await allSnapshots();

    if(status){
      status.classList.remove("is-error");
      status.classList.add("is-good");
      status.textContent=items.length
        ? `최근 백업 · ${new Date(items[0].at).toLocaleString("ko-KR")}`
        : "백업 기록 없음";
    }

    if(!box)return;
    box.innerHTML="";

    items.forEach(item=>{
      const row=document.createElement("div");
      row.className="snapshot-item";

      const left=document.createElement("div");
      const strong=document.createElement("strong");
      strong.textContent=item.reason==="auto"?"자동 백업":"수동 백업";
      const time=document.createElement("span");
      time.textContent=new Date(item.at).toLocaleString("ko-KR");
      left.append(strong,time);

      const restore=document.createElement("button");
      restore.className="glass-button secondary";
      restore.type="button";
      restore.textContent="복원";
      restore.addEventListener("click",()=>restoreSnapshot(item.id));

      row.append(left,restore);
      box.appendChild(row);
    });
  }catch(err){
    if(status){
      status.classList.add("is-error");
      status.textContent="백업 저장소를 열 수 없음";
    }
    console.error("backup render",err);
  }
}

q("#manualSnapshotBtn")?.addEventListener("click",async e=>{
  e.preventDefault();
  e.stopPropagation();
  e.stopImmediatePropagation();

  const btn=q("#manualSnapshotBtn");
  const old=btn?.textContent||"지금 백업";

  try{
    if(btn){
      btn.disabled=true;
      btn.textContent="백업 중…";
    }

    await makeSnapshot("manual");

    if(btn)btn.textContent="백업 완료 ✓";
    if(q("#backupStatus")){
      q("#backupStatus").classList.remove("is-error");
      q("#backupStatus").classList.add("is-good");
      q("#backupStatus").textContent="지금 백업 완료 ✓";
    }

    setTimeout(()=>{
      if(btn){
        btn.disabled=false;
        btn.textContent=old;
      }
    },1200);
  }catch(err){
    console.error(err);

    if(btn){
      btn.disabled=false;
      btn.textContent=old;
    }

    if(q("#backupStatus")){
      q("#backupStatus").classList.add("is-error");
      q("#backupStatus").textContent="백업 실패";
    }

    alert(
      "자동백업 생성에 실패했습니다.\n"+
      (err?.message||String(err))+
      "\n\n브라우저의 사이트 데이터 저장이 차단되어 있지 않은지 확인해주세요."
    );
  }
},true);

/* Old v70 localStorage snapshots are deliberately no longer written.
   If they exist, remove them to recover quota space. */
try{
  localStorage.removeItem("webtoonWorkroom.autoSnapshots.v70");
}catch(_){}

/* Auto backup every 10 minutes into IndexedDB. */
setInterval(async()=>{
  try{
    await makeSnapshot("auto");
  }catch(err){
    console.warn("auto snapshot failed",err);
  }
},10*60*1000);

setTimeout(render,100);

console.info("WORKROOM v71 IndexedDB autobackup loaded");
})();