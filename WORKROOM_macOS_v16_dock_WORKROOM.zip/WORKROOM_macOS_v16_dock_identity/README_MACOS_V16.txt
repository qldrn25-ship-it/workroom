WORKROOM macOS v16 — Dock WORKROOM 표시 수정

이번 버전은 macOS Dock에 Electron 대신 WORKROOM으로 표시되도록 수정했습니다.

- 앱 이름: WORKROOM
- 앱 번들: WORKROOM.app
- 실행 파일 이름: WORKROOM
- Bundle ID: com.workroom.desktop
- Dock 아이콘: 갈색 WORKROOM 아이콘
- 브라우저 탭/앱 아이콘도 같은 갈색 WORKROOM 아이콘
- macOS CLIP STUDIO 활성 앱 감지 워크타이머 유지
- 기존 작품관리/투두/자료실/메모 마크다운/캐릭터 자유정보 등 기능 포함

Mac에서:
1. 압축 해제
2. BUILD_MAC.command 실행
3. dist 폴더에서 WORKROOM.app 또는 DMG 확인

기존 Dock에 Electron으로 고정된 아이콘이 있다면:
1. 기존 Electron 아이콘을 Dock에서 제거
2. 새 WORKROOM.app 실행
3. Dock의 WORKROOM 아이콘 우클릭
4. 옵션 > Dock에 유지
