(() => {
"use strict";

const q=s=>document.querySelector(s);

function resolveEpisode(){
  try{
    if(typeof activeEpisode==="function"){
      const ep=activeEpisode();
      if(ep)return ep;
    }
  }catch(_){}

  if(typeof data!=="undefined"){
    const id=q("#episodeSelect")?.value || data.activeEpisodeId;
    return (data.episodes||[]).find(e=>String(e.id)===String(id)) || null;
  }
  return null;
}

function resolveOpenCut(){
  const ep=resolveEpisode();
  const id=q("#cutId")?.value;
  if(!ep || !id)return null;
  return (ep.cuts||[]).find(c=>String(c.id)===String(id)) || null;
}

function setPreview(value){
  const preview=q("#cutColorLabelPreview");
  if(!preview)return;
  preview.dataset.label=value||"";
  preview.title={
    red:"빨강 · 수정",
    yellow:"노랑 · 중요",
    blue:"파랑 · 배경",
    purple:"보라 · 어시",
    green:"초록 · 확인완료"
  }[value]||"색상 라벨 없음";
}

function loadColorLabel(){
  const select=q("#cutColorLabel");
  if(!select)return;

  const cut=resolveOpenCut();
  const value=cut?.colorLabel || "";

  // Keep unknown legacy values from breaking the control.
  if([...select.options].some(o=>o.value===value)){
    select.value=value;
  }else{
    select.value="";
  }
  setPreview(select.value);
}

function saveColorLabel(){
  const select=q("#cutColorLabel");
  const cut=resolveOpenCut();
  if(!select || !cut)return;

  cut.colorLabel=select.value||"";
  setPreview(cut.colorLabel);

  try{
    if(typeof saveData==="function")saveData();
    else if(typeof STORAGE_KEY!=="undefined"){
      localStorage.setItem(STORAGE_KEY,JSON.stringify(data));
    }
  }catch(err){
    console.error("color label save failed",err);
  }

  // Update the cut card immediately if it is visible.
  const card=q(`#cutsGrid .cut-card[data-id="${CSS.escape(String(cut.id))}"]`);
  if(card){
    ["red","yellow","blue","purple","green"].forEach(label=>{
      card.classList.toggle("label-"+label,cut.colorLabel===label);
    });
  }
}

/* Load after any cut card opens. Capture click on cards and add a short delayed sync. */
document.addEventListener("click",e=>{
  const card=e.target.closest?.("#cutsGrid .cut-card");
  if(card){
    setTimeout(loadColorLabel,20);
    setTimeout(loadColorLabel,100);
  }
},true);

/* Also sync whenever the modal becomes open, regardless of which module opened it. */
const modal=q("#cutModal");
if(modal){
  const obs=new MutationObserver(()=>{
    if(modal.classList.contains("open"))setTimeout(loadColorLabel,0);
  });
  obs.observe(modal,{attributes:true,attributeFilter:["class"]});
}

q("#cutColorLabel")?.addEventListener("change",saveColorLabel);

/* Defensive initial sync. */
setTimeout(loadColorLabel,100);

console.info("WORKROOM Desktop v44 color label fix loaded");
})();