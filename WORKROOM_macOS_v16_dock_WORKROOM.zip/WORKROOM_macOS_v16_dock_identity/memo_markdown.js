
(()=>{
"use strict";

function esc(s=""){
  return String(s).replace(/[&<>"']/g,ch=>({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[ch]));
}
function safeHref(raw=""){
  const v=String(raw).trim();
  if(/^https?:\/\//i.test(v) || /^mailto:/i.test(v)) return v;
  return "";
}
function inline(text=""){
  let s=esc(text);

  // protect inline code first
  const codes=[];
  s=s.replace(/`([^`\n]+)`/g,(_,code)=>{
    const key=`@@CODE${codes.length}@@`;
    codes.push(`<code>${code}</code>`);
    return key;
  });

  // links
  s=s.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g,(_,label,url)=>{
    const href=safeHref(url);
    return href
      ? `<a href="${esc(href)}" target="_blank" rel="noopener noreferrer">${label}</a>`
      : `${label} (${esc(url)})`;
  });

  // emphasis
  s=s.replace(/\*\*([^*\n]+)\*\*/g,"<strong>$1</strong>");
  s=s.replace(/__([^_\n]+)__/g,"<strong>$1</strong>");
  s=s.replace(/(^|[\s(])\*([^*\n]+)\*(?=$|[\s).,!?:;])/g,"$1<em>$2</em>");
  s=s.replace(/~~([^~\n]+)~~/g,"<del>$1</del>");

  codes.forEach((code,i)=>{ s=s.replace(`@@CODE${i}@@`,code); });
  return s;
}

function renderMarkdown(source="", opts={}){
  const lines=String(source||"").replace(/\r\n?/g,"\n").split("\n");
  const out=[];
  let inCode=false, codeLines=[];
  let listType=null;

  function closeList(){
    if(listType){out.push(`</${listType}>`);listType=null;}
  }
  function flushCode(){
    if(!inCode)return;
    out.push(`<pre><code>${esc(codeLines.join("\n"))}</code></pre>`);
    codeLines=[];
  }

  for(let i=0;i<lines.length;i++){
    const line=lines[i];

    if(/^```/.test(line.trim())){
      if(inCode){
        inCode=false;
        flushCode();
      }else{
        closeList();
        inCode=true;
      }
      continue;
    }
    if(inCode){codeLines.push(line);continue;}

    if(!line.trim()){
      closeList();
      if(!opts.compact) out.push('<div class="md-spacer"></div>');
      continue;
    }

    let m;
    if((m=line.match(/^(#{1,4})\s+(.+)$/))){
      closeList();
      const level=m[1].length;
      out.push(`<h${level}>${inline(m[2])}</h${level}>`);
      continue;
    }
    if((m=line.match(/^>\s?(.*)$/))){
      closeList();
      out.push(`<blockquote>${inline(m[1])}</blockquote>`);
      continue;
    }
    if((m=line.match(/^\s*[-*+]\s+\[([ xX])\]\s+(.+)$/))){
      if(listType!=="ul"){closeList();listType="ul";out.push("<ul>");}
      const checked=m[1].toLowerCase()==="x";
      out.push(`<li class="md-task ${checked?"done":""}" data-md-task-line="${i}">
        <input class="md-task-checkbox" type="checkbox" ${checked?"checked":""} aria-label="체크리스트 상태 변경">
        <span>${inline(m[2])}</span>
      </li>`);
      continue;
    }
    if((m=line.match(/^\s*[-*+]\s+(.+)$/))){
      if(listType!=="ul"){closeList();listType="ul";out.push("<ul>");}
      out.push(`<li>${inline(m[1])}</li>`);
      continue;
    }
    if((m=line.match(/^\s*\d+[.)]\s+(.+)$/))){
      if(listType!=="ol"){closeList();listType="ol";out.push("<ol>");}
      out.push(`<li>${inline(m[1])}</li>`);
      continue;
    }
    if(/^---+$/.test(line.trim())){
      closeList();out.push("<hr>");continue;
    }

    closeList();
    out.push(`<p>${inline(line)}</p>`);
  }

  closeList();
  if(inCode){inCode=false;flushCode();}
  return out.join("");
}

window.renderMemoMarkdown=renderMarkdown;

const $=s=>document.querySelector(s);
const content=$("#memoContent");
const preview=$("#memoMarkdownPreview");
const writeTab=$("#memoMdWriteTab");
const previewTab=$("#memoMdPreviewTab");

function refreshPreview(){
  if(preview) preview.innerHTML=renderMarkdown(content?.value||"");
}
function setMode(mode){
  const isPreview=mode==="preview";
  if(content) content.hidden=isPreview;
  if(preview) preview.hidden=!isPreview;
  $("#memoMarkdownToolbar")?.classList.toggle("disabled",isPreview);
  writeTab?.classList.toggle("active",!isPreview);
  previewTab?.classList.toggle("active",isPreview);
  if(isPreview)refreshPreview();
}
writeTab?.addEventListener("click",()=>setMode("write"));
previewTab?.addEventListener("click",()=>setMode("preview"));

function wrapSelection(before,after=before,placeholder="텍스트"){
  if(!content)return;
  const start=content.selectionStart,end=content.selectionEnd;
  const selected=content.value.slice(start,end)||placeholder;
  content.setRangeText(before+selected+after,start,end,"end");
  content.dispatchEvent(new Event("input",{bubbles:true}));
  content.focus();
}
function linePrefix(prefix,placeholder="항목"){
  if(!content)return;
  const start=content.selectionStart,end=content.selectionEnd;
  const value=content.value;
  const lineStart=value.lastIndexOf("\n",Math.max(0,start-1))+1;
  let lineEnd=value.indexOf("\n",end);
  if(lineEnd<0)lineEnd=value.length;
  let selected=value.slice(lineStart,lineEnd);
  if(!selected)selected=placeholder;
  const replaced=selected.split("\n").map(x=>prefix+x).join("\n");
  content.setRangeText(replaced,lineStart,lineEnd,"end");
  content.dispatchEvent(new Event("input",{bubbles:true}));
  content.focus();
}

$("#memoMarkdownToolbar")?.addEventListener("click",e=>{
  const btn=e.target.closest("[data-md]");
  if(!btn || btn.closest(".disabled"))return;
  const action=btn.dataset.md;
  if(action==="bold")wrapSelection("**","**","굵은 글씨");
  else if(action==="italic")wrapSelection("*","*","기울임");
  else if(action==="heading")linePrefix("## ","제목");
  else if(action==="bullet")linePrefix("- ","목록");
  else if(action==="check")linePrefix("- [ ] ","할 일");
  else if(action==="quote")linePrefix("> ","인용문");
  else if(action==="code")wrapSelection("`","`","코드");
  else if(action==="link"){
    if(!content)return;
    const start=content.selectionStart,end=content.selectionEnd;
    const selected=content.value.slice(start,end)||"링크";
    content.setRangeText(`[${selected}](https://)`,start,end,"end");
    content.dispatchEvent(new Event("input",{bubbles:true}));
    content.focus();
  }
});

content?.addEventListener("input",()=>{
  if(preview && !preview.hidden)refreshPreview();
});


function toggleTaskLine(lineIndex, checked){
  if(!content)return;
  const lines=String(content.value||"").replace(/\r\n?/g,"\n").split("\n");
  if(lineIndex<0 || lineIndex>=lines.length)return;

  const line=lines[lineIndex];
  const updated=line.replace(/^(\s*[-*+]\s+\[)([ xX])(\]\s+)/, `$1${checked?"x":" "}$3`);
  if(updated===line)return;

  lines[lineIndex]=updated;
  content.value=lines.join("\n");
  content.dispatchEvent(new Event("input",{bubbles:true}));
  content.dispatchEvent(new Event("change",{bubbles:true}));

  // Existing memo auto-save listens to the textarea/input flow.
  refreshPreview();
}

// Preview checklist is editable: click changes markdown source - [ ] <-> - [x].
preview?.addEventListener("change",e=>{
  const checkbox=e.target.closest(".md-task-checkbox");
  if(!checkbox)return;
  const item=checkbox.closest("[data-md-task-line]");
  if(!item)return;
  const lineIndex=Number(item.dataset.mdTaskLine);
  if(!Number.isInteger(lineIndex))return;
  toggleTaskLine(lineIndex,checkbox.checked);
});

// Markdown links inside memo cards should open directly instead of opening editor.
document.addEventListener("click",e=>{
  const link=e.target.closest("#memoBoard .markdown-body a");
  if(!link)return;
  e.stopPropagation();
},true);

// Every time memo modal is opened, return to write mode.
const memoModal=$("#memoModal");
if(memoModal){
  const obs=new MutationObserver(()=>{
    if(memoModal.classList.contains("open"))setMode("write");
  });
  obs.observe(memoModal,{attributes:true,attributeFilter:["class"]});
}
})();
