(() => {
"use strict";
const q=s=>document.querySelector(s);
const esc=v=>String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
const uid=()=>globalThis.crypto?.randomUUID?.()||("id-"+Date.now()+"-"+Math.random().toString(16).slice(2));

function currentProject(){
  try{return typeof activeProject==="function"?activeProject():data.projects?.find(p=>p.id===data.activeProjectId)}catch(_){return null}
}
function currentEpisode(){
  try{return typeof activeEpisode==="function"?activeEpisode():data.episodes?.find(e=>e.id===data.activeEpisodeId)}catch(_){return null}
}
function persist(){
  try{
    if(typeof saveData==="function"){saveData();return}
    if(typeof STORAGE_KEY!=="undefined")localStorage.setItem(STORAGE_KEY,JSON.stringify(data));
  }catch(err){console.error(err)}
}

/* QUICK MEMO: independent handlers */
function openQuick(){
  const modal=q("#quickMemoModal");
  if(!modal)return;
  q("#quickMemoText").value="";
  modal.classList.add("open");
  requestAnimationFrame(()=>q("#quickMemoText")?.focus());
}
document.addEventListener("click",e=>{
  const b=e.target.closest?.("#quickMemoBtn");
  if(!b)return;
  e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();
  openQuick();
},true);
q("#closeQuickMemoX")?.addEventListener("click",e=>{e.preventDefault();q("#quickMemoModal")?.classList.remove("open")});

q("#quickMemoForm")?.addEventListener("submit",e=>{
  e.preventDefault();e.stopPropagation();
  const text=q("#quickMemoText")?.value.trim()||"";
  const scope=q("#quickMemoScope")?.value||"general";
  if(!text)return;
  const p=currentProject(),ep=currentEpisode();

  // Cut scope: use currently open cut ID when available.
  let cut=null;
  const cutId=q("#cutId")?.value||"";
  if(ep&&cutId)cut=(ep.cuts||[]).find(c=>c.id===cutId)||null;

  if(scope==="cut"&&cut){
    cut.note=(cut.note?cut.note+"\n":"")+text;
  }else if(scope==="episode"&&ep){
    ep.memo=(ep.memo?ep.memo+"\n":"")+text;
  }else{
    if(!Array.isArray(data.memos))data.memos=[];
    data.memos.push({
      id:uid(),type:"아이디어",
      tag:scope==="project"?(p?.name||""):scope==="episode"?(ep?.name||""):"빠른메모",
      title:text.slice(0,30)||"빠른 메모",content:text,pinned:false,image:"",updated:Date.now()
    });
  }
  persist();
  try{if(typeof renderMemos==="function")renderMemos()}catch(_){}
  q("#quickMemoModal")?.classList.remove("open");
});

/* DATA CHECK: independent scan + repair */
let issues=[];
function scan(){
  issues=[];
  if(typeof data==="undefined"||!data){issues.push({type:"data-missing",label:"WORKROOM 데이터 객체를 찾을 수 없음"});return issues}
  const seen=new Set();
  const check=(obj,label)=>{
    if(!obj||typeof obj!=="object"){issues.push({type:"invalid-object",label});return}
    if(!obj.id)issues.push({type:"missing-id",label,obj});
    else if(seen.has(obj.id))issues.push({type:"duplicate-id",label,obj});
    else seen.add(obj.id);
  };
  (data.projects||[]).forEach((p,i)=>check(p,`작품 ${p.name||i+1}`));
  (data.episodes||[]).forEach((ep,i)=>{
    check(ep,`회차 ${ep.name||i+1}`);
    if(!(data.projects||[]).some(p=>p.id===ep.projectId))issues.push({type:"orphan-episode",label:`${ep.name||"회차"}: 연결 작품 없음`,obj:ep});
    (ep.cuts||[]).forEach((c,j)=>{
      check(c,`${ep.name||"회차"} CUT ${j+1}`);
      if(c.sceneId&&!(data.scenes||[]).some(s=>s.id===c.sceneId))issues.push({type:"bad-scene",label:`${ep.name||"회차"} CUT ${j+1}: 없는 장면 참조`,obj:c});
    });
  });
  (data.memos||[]).forEach((m,i)=>check(m,`메모 ${m.title||i+1}`));
  (data.resources||[]).forEach((r,i)=>check(r,`자료 ${r.name||i+1}`));
  (data.scenes||[]).forEach((s,i)=>{
    check(s,`장면 ${s.name||i+1}`);
    if(!(data.episodes||[]).some(ep=>ep.id===s.episodeId))issues.push({type:"orphan-scene",label:`${s.name||"장면"}: 연결 회차 없음`,obj:s});
  });
  return issues;
}
function renderScan(){
  scan();
  const sum=q("#dataCheckSummary"),box=q("#dataCheckList");
  if(sum)sum.textContent=issues.length?`문제 ${issues.length}건 발견`:"문제가 발견되지 않았습니다.";
  if(box)box.innerHTML=issues.length
    ?issues.map(x=>`<div class="data-issue"><strong>${esc(x.type)}</strong> · ${esc(x.label)}</div>`).join("")
    :"<div class='empty-state'>데이터 상태가 정상입니다.</div>";
}
function openCheck(){
  const modal=q("#dataCheckModal");if(!modal)return;
  renderScan();modal.classList.add("open");
}
document.addEventListener("click",e=>{
  const b=e.target.closest?.("#runDataCheckBtn");
  if(!b)return;
  e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();
  openCheck();
},true);
q("#closeDataCheckX")?.addEventListener("click",e=>{e.preventDefault();q("#dataCheckModal")?.classList.remove("open")});
q("#repairDataBtn")?.addEventListener("click",()=>{
  scan();
  const seen=new Set();
  const fix=obj=>{if(!obj.id||seen.has(obj.id))obj.id=uid();seen.add(obj.id)};
  (data.projects||[]).forEach(fix);(data.episodes||[]).forEach(fix);(data.memos||[]).forEach(fix);(data.resources||[]).forEach(fix);(data.scenes||[]).forEach(fix);
  (data.episodes||[]).forEach(ep=>(ep.cuts||[]).forEach(fix));
  const firstProject=data.projects?.[0]?.id||"";
  (data.episodes||[]).forEach(ep=>{
    if(!(data.projects||[]).some(p=>p.id===ep.projectId))ep.projectId=firstProject;
    (ep.cuts||[]).forEach(c=>{if(c.sceneId&&!(data.scenes||[]).some(s=>s.id===c.sceneId))c.sceneId=""});
  });
  if(Array.isArray(data.scenes))data.scenes=data.scenes.filter(s=>(data.episodes||[]).some(ep=>ep.id===s.episodeId));
  persist();renderScan();
  try{if(typeof renderEpisodes==="function")renderEpisodes()}catch(_){}
});

/* ESC closes both */
window.addEventListener("keydown",e=>{
  if(e.key!=="Escape")return;
  if(q("#quickMemoModal")?.classList.contains("open")){e.preventDefault();q("#quickMemoModal").classList.remove("open")}
  else if(q("#dataCheckModal")?.classList.contains("open")){e.preventDefault();q("#dataCheckModal").classList.remove("open")}
},true);

console.info("WORKROOM v32 dashboard fixes loaded");
})();