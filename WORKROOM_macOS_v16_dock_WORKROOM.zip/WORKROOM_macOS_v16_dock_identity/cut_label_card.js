(() => {
"use strict";

const q=s=>document.querySelector(s);
const qa=s=>[...document.querySelectorAll(s)];

const labelText={
  red:"수정",
  yellow:"중요",
  blue:"배경",
  purple:"어시",
  green:"확인완료"
};

function currentEpisodeSafe(){
  try{
    if(typeof activeEpisode==="function"){
      const ep=activeEpisode();
      if(ep)return ep;
    }
  }catch(_){}

  if(typeof data!=="undefined"){
    const id=q("#episodeSelect")?.value || data.activeEpisodeId;
    return (data.episodes||[]).find(e=>String(e.id)===String(id)) || null;
  }
  return null;
}

function decorateCutCards(){
  const ep=currentEpisodeSafe();
  if(!ep)return;

  qa("#cutsGrid .cut-card").forEach(card=>{
    const id=card.dataset.id;
    const cut=(ep.cuts||[]).find(c=>String(c.id)===String(id));
    if(!cut)return;

    // remove old badge before rebuilding
    card.querySelector(".cut-card-label-badge")?.remove();

    const label=cut.colorLabel || "";
    if(!labelText[label])return;

    const badge=document.createElement("span");
    badge.className=`cut-card-label-badge label-${label}`;
    badge.textContent=labelText[label];
    const head=card.querySelector(".cut-head");
    const status=head?.querySelector(".status-pill");
    if(head && status){
      head.insertBefore(badge,status);
    }else if(head){
      head.appendChild(badge);
    }else{
      card.appendChild(badge);
    }
  });
}

/* Run after any cut render. */
const originalRenderCuts =
  (typeof renderCuts==="function") ? renderCuts : null;

if(originalRenderCuts){
  renderCuts=function(){
    const result=originalRenderCuts.apply(this,arguments);
    requestAnimationFrame(decorateCutCards);
    return result;
  };
}

/* Also refresh after label changes and common UI actions. */
q("#cutColorLabel")?.addEventListener("change",()=>setTimeout(decorateCutCards,20));
q("#episodeSelect")?.addEventListener("change",()=>setTimeout(decorateCutCards,30));
q("#projectSelect")?.addEventListener("change",()=>setTimeout(decorateCutCards,30));

const grid=q("#cutsGrid");
if(grid){
  const obs=new MutationObserver(()=>decorateCutCards());
  obs.observe(grid,{childList:true,subtree:false});
}

setTimeout(decorateCutCards,100);

console.info("WORKROOM Local v45 cut label badge loaded");
})();