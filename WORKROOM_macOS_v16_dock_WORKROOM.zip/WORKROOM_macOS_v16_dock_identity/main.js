const { app, BrowserWindow, ipcMain } = require("electron");

app.setName("WORKROOM");
const path = require("path");
const { execFile } = require("child_process");

let mainWindow = null;

function createWindow(){
  mainWindow = new BrowserWindow({
    width: 1480,
    height: 940,
    minWidth: 1080,
    minHeight: 700,
    title: "WORKROOM",
    backgroundColor: "#f4eee8",
    icon: path.join(__dirname, "assets", "workroom-icon.png"),
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });
  mainWindow.loadFile("index.html");
}

app.whenReady().then(()=>{
  if (process.platform === "darwin" && app.dock) {
    try { app.dock.setIcon(path.join(__dirname, "assets", "workroom-icon.png")); }
    catch (e) { console.error("WORKROOM Dock icon 설정 실패", e); }
  }

  createWindow();
  app.on("activate",()=>{
    if(BrowserWindow.getAllWindows().length===0) createWindow();
  });
});
app.on("window-all-closed",()=>{
  if(process.platform!=="darwin") app.quit();
});

// macOS foreground app detection.
// NSWorkspace reports the real frontmost application, independent of window title.
ipcMain.handle("workroom:get-active-app", async ()=>{
  if(process.platform!=="darwin"){
    return { ok:false, platform:process.platform, appName:"", bundleId:"", path:"", idleSeconds:0 };
  }

  const script = `
ObjC.import('AppKit');
ObjC.import('CoreGraphics');

const ws = $.NSWorkspace.sharedWorkspace;
const app = ws.frontmostApplication;
const name = ObjC.unwrap(app.localizedName) || "";
const bundle = ObjC.unwrap(app.bundleIdentifier) || "";
const url = app.bundleURL;
const appPath = url ? ObjC.unwrap(url.path) : "";
const idle = $.CGEventSource.secondsSinceLastEventType(
  $.kCGEventSourceStateCombinedSessionState,
  $.kCGAnyInputEventType
);

JSON.stringify({
  appName: name,
  bundleId: bundle,
  path: appPath,
  idleSeconds: Number(idle)
});
`;

  return await new Promise(resolve=>{
    execFile("/usr/bin/osascript", ["-l","JavaScript","-e",script], {timeout:2500}, (err, stdout)=>{
      if(err){
        resolve({ok:false, appName:"", bundleId:"", path:"", idleSeconds:0, error:String(err.message||err)});
        return;
      }
      try{
        const parsed=JSON.parse(String(stdout||"").trim());
        resolve({ok:true, ...parsed});
      }catch(e){
        resolve({ok:false, appName:"", bundleId:"", path:"", idleSeconds:0, error:String(e)});
      }
    });
  });
});
