(() => {
"use strict";

const groups=[...document.querySelectorAll(".cut-menu-group")];

function closeAll(except=null){
  groups.forEach(g=>{
    if(g!==except)g.classList.remove("open");
  });
}

document.addEventListener("click",e=>{
  const trigger=e.target.closest?.(".cut-menu-trigger");
  if(trigger){
    e.preventDefault();
    e.stopPropagation();

    const group=trigger.closest(".cut-menu-group");
    const willOpen=!group.classList.contains("open");
    closeAll(group);
    group.classList.toggle("open",willOpen);
    return;
  }

  if(!e.target.closest?.(".cut-menu-group")){
    closeAll();
  }
});

document.addEventListener("keydown",e=>{
  if(e.key==="Escape")closeAll();
});

// Keep the Cut menu open while selection mode is active,
// so bulk actions remain immediately available.
const cutGroup=document.querySelector('[data-cutmenu="cut"]')?.closest(".cut-menu-group");
const selectBtn=document.querySelector("#toggleCutSelectBtn");
if(selectBtn&&cutGroup){
  selectBtn.addEventListener("click",()=>{
    setTimeout(()=>{
      if(typeof cutSelectMode!=="undefined" && cutSelectMode){
        cutGroup.classList.add("open");
      }
    },0);
  });
}

// Don't close a menu when operating controls inside it.
document.querySelectorAll(".cut-dropdown-menu").forEach(menu=>{
  menu.addEventListener("click",e=>e.stopPropagation());
});

console.info("WORKROOM Local v46 compact cuts toolbar loaded");
})();