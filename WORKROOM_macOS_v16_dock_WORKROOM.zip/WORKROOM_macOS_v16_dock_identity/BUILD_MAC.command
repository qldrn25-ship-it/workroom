#!/bin/bash
set -e
cd "$(dirname "$0")"

echo "========================================"
echo " WORKROOM macOS v16"
echo "========================================"

if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo "Node.js LTS가 필요합니다."
  echo "Node.js를 설치한 뒤 다시 실행해주세요."
  read -p "Enter를 누르면 종료합니다..."
  exit 1
fi

echo ""
echo "[1/2] 필요한 빌드 도구 설치..."
npm install

echo ""
echo "[2/2] WORKROOM.app / DMG 생성..."
npm run dist:mac

echo ""
echo "완료되었습니다."
echo "dist 폴더에서 WORKROOM.app 또는 DMG를 확인하세요."
open dist
