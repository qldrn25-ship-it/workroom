(() => {
"use strict";

const q=s=>document.querySelector(s);
const qa=s=>[...document.querySelectorAll(s)];

function normalizeHex(value){
  const v=String(value||"").trim();
  return /^#[0-9a-fA-F]{6}$/.test(v)?v.toLowerCase():"";
}

function rangeSchedules(){
  if(typeof data==="undefined"||!Array.isArray(data.schedules))return [];
  return data.schedules
    .filter(s=>s.date&&s.endDate&&s.endDate>s.date)
    .sort((a,b)=>String(a.date).localeCompare(String(b.date)) || String(a.endDate).localeCompare(String(b.endDate)));
}

function isoAddDays(iso,n){
  const [y,m,d]=iso.split("-").map(Number);
  const dt=new Date(y,m-1,d);
  dt.setDate(dt.getDate()+n);
  return `${dt.getFullYear()}-${String(dt.getMonth()+1).padStart(2,"0")}-${String(dt.getDate()).padStart(2,"0")}`;
}

function overlap(a1,a2,b1,b2){
  return a1<=b2 && b1<=a2;
}

function assignLanes(items){
  const lanes=[];
  return items.map(item=>{
    let lane=0;
    while(lanes[lane] && overlap(item.start,item.end,lanes[lane].start,lanes[lane].end))lane++;
    lanes[lane]={start:item.start,end:item.end};
    return {...item,lane};
  });
}

function getOrCreateOverlay(grid){
  let overlay=grid.querySelector(":scope > .calendar-range-overlay");
  if(!overlay){
    overlay=document.createElement("div");
    overlay.className="calendar-range-overlay";
    grid.appendChild(overlay);
  }
  overlay.innerHTML="";
  return overlay;
}

function renderContinuousRanges(){
  const grid=q("#calendarGrid");
  if(!grid)return;

  const days=qa("#calendarGrid > .day");
  if(days.length!==42)return;

  const overlay=getOrCreateOverlay(grid);
  const dateToIndex=new Map(days.map((day,i)=>[day.dataset.date,i]));
  const visibleStart=days[0].dataset.date;
  const visibleEnd=days[41].dataset.date;
  if(!visibleStart||!visibleEnd)return;

  const visibleRanges=rangeSchedules()
    .filter(s=>s.date<=visibleEnd && s.endDate>=visibleStart)
    .map(s=>({
      schedule:s,
      start:s.date<visibleStart?visibleStart:s.date,
      end:s.endDate>visibleEnd?visibleEnd:s.endDate
    }));

  const withLanes=assignLanes(visibleRanges);
  const gridRect=grid.getBoundingClientRect();
  const gapX=days.length>1
    ? Math.max(0,days[1].getBoundingClientRect().left-days[0].getBoundingClientRect().right)
    : 0;

  withLanes.forEach(item=>{
    const s=item.schedule;
    let cursor=item.start;
    let firstSegment=true;

    while(cursor<=item.end){
      const startIndex=dateToIndex.get(cursor);
      if(startIndex===undefined)break;

      const weekEndIndex=Math.floor(startIndex/7)*7+6;
      const possibleWeekEnd=days[Math.min(weekEndIndex,41)].dataset.date;
      const segEnd=item.end<possibleWeekEnd?item.end:possibleWeekEnd;
      const endIndex=dateToIndex.get(segEnd);
      if(endIndex===undefined)break;

      const firstDay=days[startIndex];
      const lastDay=days[endIndex];
      const firstRect=firstDay.getBoundingClientRect();
      const lastRect=lastDay.getBoundingClientRect();

      const bar=document.createElement("button");
      bar.type="button";
      const isLastSegment=segEnd===item.end;
      bar.className="calendar-range-bar "+
        (firstSegment&&isLastSegment?"range-start range-end":
         firstSegment?"range-start":
         isLastSegment?"range-end":"range-middle");
      if(s.id) bar.dataset.scheduleId=s.id;

      const color=normalizeHex(s.colorLabel)||"var(--brown)";
      bar.style.setProperty("--range-color",color);
      bar.style.left=`${firstRect.left-gridRect.left+3}px`;
      bar.style.top=`${firstRect.top-gridRect.top+56+(item.lane%3)*24}px`;
      bar.style.width=`${lastRect.right-firstRect.left-6}px`;

      const label=document.createElement("span");
      label.className="range-label";
      label.textContent=firstSegment
        ? `${s.stage||"일정"} · ${s.title||""}`
        : `↳ ${s.title||""}`;
      bar.appendChild(label);

      bar.title=`${s.title||""}\n${s.date} ~ ${s.endDate}`;
      bar.addEventListener("click",e=>{
        e.preventDefault();
        e.stopPropagation();
        try{
          if(typeof openScheduleModal==="function")openScheduleModal(s.id);
        }catch(err){console.error(err)}
      });

      overlay.appendChild(bar);

      firstSegment=false;
      cursor=isoAddDays(segEnd,1);
    }
  });
}

function rerender(){
  requestAnimationFrame(()=>{
    renderContinuousRanges();
    setTimeout(renderContinuousRanges,30);
  });
}

/* Wrap calendar rendering so bars always follow month changes and edits. */
if(typeof renderCalendar==="function"){
  const base=renderCalendar;
  renderCalendar=function(){
    const result=base.apply(this,arguments);
    rerender();
    return result;
  };
}

/* Month navigation and window resize can change geometry. */
window.addEventListener("resize",()=>{
  clearTimeout(renderContinuousRanges._resizeTimer);
  renderContinuousRanges._resizeTimer=setTimeout(renderContinuousRanges,80);
});

q("#prevMonthBtn")?.addEventListener("click",()=>setTimeout(renderContinuousRanges,30));
q("#nextMonthBtn")?.addEventListener("click",()=>setTimeout(renderContinuousRanges,30));
q("#todayBtn")?.addEventListener("click",()=>setTimeout(renderContinuousRanges,30));

/* Existing schedule/color changes. */
q("#scheduleForm")?.addEventListener("submit",()=>setTimeout(renderContinuousRanges,50));
q("#deleteScheduleBtn")?.addEventListener("click",()=>setTimeout(renderContinuousRanges,50));
q("#scheduleColor")?.addEventListener("input",()=>setTimeout(renderContinuousRanges,20));

setTimeout(renderContinuousRanges,120);

console.info("WORKROOM Local v65 continuous calendar ranges loaded");
})();