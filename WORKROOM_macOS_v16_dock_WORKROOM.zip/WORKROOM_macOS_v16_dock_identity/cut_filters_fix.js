(() => {
"use strict";

const q=s=>document.querySelector(s);
const qa=s=>[...document.querySelectorAll(s)];

function getEpisode(){
  try{
    if(typeof activeEpisode==="function"){
      const ep=activeEpisode();
      if(ep)return ep;
    }
  }catch(_){}

  if(typeof data!=="undefined"){
    const id=q("#episodeSelect")?.value||data.activeEpisodeId;
    return (data.episodes||[]).find(e=>String(e.id)===String(id))||null;
  }
  return null;
}

function getScenes(ep){
  if(typeof data==="undefined")return [];
  if(!Array.isArray(data.scenes))data.scenes=[];
  return ep?data.scenes.filter(s=>String(s.episodeId)===String(ep.id)):[];
}

function feedbackState(c){
  if(c.feedbackStatus==="needs"||c.feedbackStatus==="resolved")return c.feedbackStatus;
  if(c.reviewNeedsFix===true)return "needs";
  if(c.reviewed===true && !c.feedbackStatus)return "resolved";
  return "";
}

function populateSceneFilter(){
  const sel=q("#sceneFilterSelect");
  const ep=getEpisode();
  if(!sel||!ep)return;

  const previous=sel.value||"all";
  const scenes=getScenes(ep);

  sel.innerHTML='<option value="all">전체 장면</option>'+
    scenes.map(s=>`<option value="${String(s.id).replace(/"/g,"&quot;")}">${String(s.name||"장면")}</option>`).join("");

  sel.value=[...sel.options].some(o=>o.value===previous)?previous:"all";
}

function applyFilters(){
  const ep=getEpisode();
  const grid=q("#cutsGrid");
  if(!ep||!grid)return;

  const sceneValue=q("#sceneFilterSelect")?.value||"all";
  const feedbackValue=q("#feedbackFilterSelect")?.value||"all";

  qa("#cutsGrid .cut-card").forEach(card=>{
    const id=card.dataset.id;
    const cut=(ep.cuts||[]).find(c=>String(c.id)===String(id));
    if(!cut){
      card.hidden=false;
      card.style.removeProperty("display");
      return;
    }

    const sceneMatch=
      sceneValue==="all" ||
      String(cut.sceneId||"")===String(sceneValue);

    const state=feedbackState(cut);
    const feedbackMatch=
      feedbackValue==="all" ||
      state===feedbackValue;

    const visible=sceneMatch&&feedbackMatch;
    card.hidden=!visible;
    card.style.display=visible?"":"none";
  });
}

function refreshFilters(){
  populateSceneFilter();
  requestAnimationFrame(applyFilters);
}

/* Own filter changes independently from advanced.js */
q("#sceneFilterSelect")?.addEventListener("change",e=>{
  e.stopPropagation();
  applyFilters();
});

q("#feedbackFilterSelect")?.addEventListener("change",e=>{
  e.stopPropagation();
  applyFilters();
});

/* Rebuild after relevant state changes */
q("#episodeSelect")?.addEventListener("change",()=>setTimeout(refreshFilters,20));
q("#projectSelect")?.addEventListener("change",()=>setTimeout(refreshFilters,20));

q("#sceneForm")?.addEventListener("submit",()=>setTimeout(refreshFilters,40));

q("#reviewFlagBtn")?.addEventListener("click",()=>setTimeout(applyFilters,40));
q("#reviewResolveBtn")?.addEventListener("click",()=>setTimeout(applyFilters,40));

/* Cut modal saves can alter scene/feedback */
q("#cutForm")?.addEventListener("submit",()=>setTimeout(refreshFilters,40));

/* Observe card-list rebuild only; do not touch whole DOM */
const grid=q("#cutsGrid");
if(grid){
  const obs=new MutationObserver(records=>{
    if(records.some(r=>r.type==="childList")){
      requestAnimationFrame(applyFilters);
    }
  });
  obs.observe(grid,{childList:true});
}

/* Rewrap renderCuts so filters reapply after any module redraws cards */
if(typeof renderCuts==="function"){
  const baseRenderCuts=renderCuts;
  renderCuts=function(){
    const result=baseRenderCuts.apply(this,arguments);
    requestAnimationFrame(()=>{
      populateSceneFilter();
      applyFilters();
    });
    return result;
  };
}

setTimeout(refreshFilters,100);

console.info("WORKROOM v69 independent cut filters loaded");
})();