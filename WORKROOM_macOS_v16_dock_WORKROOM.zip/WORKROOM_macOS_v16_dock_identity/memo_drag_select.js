(() => {
"use strict";

const qa=s=>[...document.querySelectorAll(s)];

let sweep=null;
let suppressClickUntil=0;

function inMode(){
  try{return !!memoSelectMode}catch(_){return false}
}
function selected(id){
  try{return selectedMemoIds.has(id)}catch(_){return false}
}
function setSelected(id,value){
  try{
    if(value)selectedMemoIds.add(id);
    else selectedMemoIds.delete(id);
  }catch(_){}
}
function cards(){
  return qa("#memoBoard .memo-card");
}
function idForCard(card){
  const idx=cards().indexOf(card);
  if(idx<0)return "";
  try{
    const items=visibleMemoItems();
    return String(items[idx]?.id||"");
  }catch(_){return ""}
}
function cardAtPoint(x,y){
  return document.elementFromPoint(x,y)?.closest?.("#memoBoard .memo-card")||null;
}
function sync(){
  try{if(typeof syncMemoSelectionUI==="function")syncMemoSelectionUI()}catch(_){}
  cards().forEach(card=>{
    const id=idForCard(card);
    card.classList.toggle("selected",selected(id));
  });
}
function touch(card){
  if(!sweep||!card)return;
  const id=idForCard(card);
  if(!id||sweep.touched.has(id))return;

  sweep.touched.add(id);
  setSelected(id,sweep.selecting);
  card.classList.toggle("selected",sweep.selecting);
  card.classList.add("sweep-touched");
  sync();
}
function finish(){
  document.body.classList.remove("memo-sweep-selecting");
  cards().forEach(c=>c.classList.remove("sweep-touched"));
  sweep=null;
}

document.addEventListener("pointerdown",e=>{
  if(!inMode()||e.button!==0)return;

  const card=e.target.closest?.("#memoBoard .memo-card");
  if(!card)return;

  const sx=e.clientX,sy=e.clientY;
  const startId=idForCard(card);
  let started=false;

  function move(ev){
    if(!started){
      if(Math.hypot(ev.clientX-sx,ev.clientY-sy)<6)return;

      started=true;
      sweep={
        selecting:!selected(startId),
        touched:new Set()
      };
      document.body.classList.add("memo-sweep-selecting");
      touch(card);
    }

    ev.preventDefault();
    touch(cardAtPoint(ev.clientX,ev.clientY));
  }

  function up(){
    window.removeEventListener("pointermove",move,true);
    window.removeEventListener("pointerup",up,true);
    window.removeEventListener("pointercancel",cancel,true);

    if(started){
      suppressClickUntil=Date.now()+350;
      finish();
    }
  }

  function cancel(){
    window.removeEventListener("pointermove",move,true);
    window.removeEventListener("pointerup",up,true);
    window.removeEventListener("pointercancel",cancel,true);
    finish();
  }

  window.addEventListener("pointermove",move,true);
  window.addEventListener("pointerup",up,true);
  window.addEventListener("pointercancel",cancel,true);
},true);

/* Prevent the existing card onclick from toggling one extra time after a sweep. */
document.addEventListener("click",e=>{
  if(Date.now()>=suppressClickUntil)return;
  if(e.target.closest?.("#memoBoard .memo-card")){
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
  }
},true);

console.info("WORKROOM v84 memo sweep selection loaded");
})();