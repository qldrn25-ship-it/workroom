
const STORAGE_KEY = "webtoonWorkroom.v1";

const defaultData = {
  schedules: [
    {id: crypto.randomUUID(), date: todayISO(), project:"샘플 작품", episode:"1화", stage:"콘티", title:"1화 콘티 정리", progress:45, status:"doing", memo:"장면 전환 리듬 체크"}
  ],
  memos: [
    {id: crypto.randomUUID(), type:"트리트먼트", tag:"1화", title:"1화 핵심 흐름", content:"오프닝 → 사건 발생 → 주인공의 선택 → 마지막 컷에서 다음 화 훅.", pinned:true, updated:Date.now()}
  ],
  episodes: [
    {id: crypto.randomUUID(), name:"1화", cuts:Array.from({length:6},(_,i)=>({
      id:crypto.randomUUID(), description:i===0?"도입부. 도시 전경에서 천천히 주인공에게 접근.":"", dialogue:i===0?"내레이션을 이곳에 적어보세요.":"", status:i===0?"rough":"todo", tag:i===0?"오프닝":"", note:""
    }))}
  ],
  activeEpisodeId:null
};

function todayISO(){
  const d=new Date();
  const off=d.getTimezoneOffset();
  return new Date(d.getTime()-off*60000).toISOString().slice(0,10);
}
function deepClone(v){return JSON.parse(JSON.stringify(v))}
function loadData(){
  try{
    const parsed=JSON.parse(localStorage.getItem(STORAGE_KEY));
    if(parsed && parsed.schedules && parsed.memos && parsed.episodes) return parsed;
  }catch(e){}
  const d=deepClone(defaultData);
  d.activeEpisodeId=d.episodes[0]?.id||null;
  return d;
}
let data=loadData();

// v11 migration: 기존 회차 데이터를 작품 구조로 연결한다.
if(!Array.isArray(data.projects)) data.projects=[];
if(data.projects.length===0){
  const firstProjectId=crypto.randomUUID();
  data.projects.push({id:firstProjectId,name:"기본 작품"});
  data.episodes.forEach(ep=>{ if(!ep.projectId) ep.projectId=firstProjectId; });
  data.activeProjectId=firstProjectId;
}
if(!data.activeProjectId || !data.projects.some(p=>p.id===data.activeProjectId)){
  data.activeProjectId=data.projects[0]?.id||null;
}
data.episodes.forEach(ep=>{
  if(!ep.projectId) ep.projectId=data.activeProjectId;
});
if(!data.activeEpisodeId || !data.episodes.some(ep=>ep.id===data.activeEpisodeId && ep.projectId===data.activeProjectId)){
  data.activeEpisodeId=data.episodes.find(ep=>ep.projectId===data.activeProjectId)?.id||null;
}

// v18 migration
if(!Array.isArray(data.trash)) data.trash=[];
data.episodes.forEach(ep=>{
  if(ep.deadline===undefined) ep.deadline="";
  if(ep.memo===undefined) ep.memo="";
  (ep.cuts||[]).forEach(c=>{
    if(c.image===undefined) c.image="";
    if(c.important===undefined) c.important=false;
    if(c.characters===undefined) c.characters="";
  });
});
data.schedules.forEach(s=>{
    if(!s.id)s.id=crypto.randomUUID?.()||String(Date.now()+Math.random());
    if(s.endDate===undefined)s.endDate="";
  });

// 휴지통은 30일이 지난 항목을 자동 정리한다.
data.trash=data.trash.filter(x=>Date.now()-(x.deletedAt||0) < 30*24*60*60*1000);

function normalizeImportedData(){
  if(!Array.isArray(data.projects))data.projects=[];
  if(!Array.isArray(data.episodes))data.episodes=[];
  if(!Array.isArray(data.memos))data.memos=[];
  if(!Array.isArray(data.schedules))data.schedules=[];
  data.schedules.forEach(s=>{if(s.endDate===undefined)s.endDate="";});
  if(!Array.isArray(data.trash))data.trash=[];
  if(!data.projects.length){
    const pid=crypto.randomUUID();
    data.projects.push({id:pid,name:"기본 작품"});
    data.episodes.forEach(ep=>ep.projectId=ep.projectId||pid);
  }
  data.activeProjectId=data.projects.some(p=>p.id===data.activeProjectId)?data.activeProjectId:data.projects[0]?.id||null;
  data.episodes.forEach(ep=>{
    ep.projectId=ep.projectId||data.activeProjectId;
    ep.deadline=ep.deadline||"";
    ep.memo=ep.memo||"";
    if(!Array.isArray(ep.cuts))ep.cuts=[];
    ep.cuts.forEach(c=>{
      c.image=c.image||"";
      c.important=!!c.important;
      c.characters=c.characters||"";
      c.status=c.status||"todo";
    });
  });
  if(!data.episodes.some(ep=>ep.id===data.activeEpisodeId && ep.projectId===data.activeProjectId)){
    data.activeEpisodeId=data.episodes.find(ep=>ep.projectId===data.activeProjectId)?.id||null;
  }
  data.trash=data.trash.filter(x=>Date.now()-(x.deletedAt||0) < 30*24*60*60*1000);
}

const THEME_KEY="webtoonWorkroom.theme";
let currentTheme=localStorage.getItem(THEME_KEY)||"light";

function applyTheme(theme){
  currentTheme=theme==="dark"?"dark":"light";
  document.body.classList.toggle("dark-theme",currentTheme==="dark");

  const icon=document.querySelector("#themeToggleIcon");
  const text=document.querySelector("#themeToggleText");
  const button=document.querySelector("#themeToggle");

  if(icon) icon.textContent=currentTheme==="dark"?"☀":"☾";
  if(text) text.textContent=currentTheme==="dark"?"LIGHT":"DARK";
  if(button){
    const next=currentTheme==="dark"?"밝은":"어두운";
    button.setAttribute("aria-label",`${next} 테마로 전환`);
    button.title=`${next} 테마로 전환`;
  }
}
applyTheme(currentTheme);

let calendarCursor=new Date();
calendarCursor.setDate(1);

const $=s=>document.querySelector(s);
const $$=s=>[...document.querySelectorAll(s)];

$("#themeToggle").addEventListener("click",()=>{
  const next=currentTheme==="dark"?"light":"dark";
  localStorage.setItem(THEME_KEY,next);
  applyTheme(next);
});

function saveData(){
  try{
    localStorage.setItem(STORAGE_KEY,JSON.stringify(data));
  }catch(err){
    if(err && (err.name==="QuotaExceededError" || err.code===22)){
      alert("브라우저 저장 공간이 부족합니다. 사진이 많은 경우 '데이터 백업'으로 보관한 뒤 오래된 사진 메모를 정리해 주세요.");
      return false;
    }
    throw err;
  }
  $("#saveText").textContent="저장 중…";
  $(".save-dot").style.background="#b18a69";
  clearTimeout(saveData._t);
  saveData._t=setTimeout(()=>{
    $("#saveText").textContent="자동 저장됨";
    $(".save-dot").style.background="#75906e";
  },350);
  updateTodayCount();
}

function switchView(view){
  $$(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
  $$(".view").forEach(v=>v.classList.remove("active"));
  $("#"+view+"View").classList.add("active");
  $("#pageTitle").textContent={dashboard:"대시보드",calendar:"캘린더",memo:"메모판",cuts:"컷별 관리",resources:"자료실",pomodoro:"뽀모도로 타이머",worktimer:"워크 타이머",works:"작품관리",todo:"투두리스트"}[view]||"WORKROOM";
  if(view==="dashboard") renderDashboard();
  if(view==="calendar") renderCalendar();
  if(view==="memo") renderMemos();
  if(view==="cuts") renderEpisodes();
  if(view==="works" && typeof window.renderWorkManager==="function") window.renderWorkManager();
  if(view==="todo" && typeof window.renderTodoList==="function") window.renderTodoList();
}
$$(".nav-btn").forEach(b=>b.addEventListener("click",()=>switchView(b.dataset.view)));

function updateToday(){
  const d=new Date();
  $("#todayText").textContent=new Intl.DateTimeFormat("ko-KR",{month:"long",day:"numeric",weekday:"short"}).format(d);
  updateTodayCount();
}
function updateTodayCount(){
  const n=data.schedules.filter(s=>s.date===todayISO()).length;
  $("#todayScheduleCount").textContent=`오늘 일정 ${n}개`;
}
updateToday();


let lastTrashId=null;
function daysUntil(dateStr){
  if(!dateStr)return null;
  const a=new Date(todayISO()+"T00:00:00");
  const b=new Date(dateStr+"T00:00:00");
  return Math.round((b-a)/86400000);
}
function ddayLabel(dateStr){
  const d=daysUntil(dateStr);
  if(d===null)return "마감일 없음";
  if(d===0)return "D-DAY";
  return d>0?`D-${d}`:`D+${Math.abs(d)}`;
}
function cutCompletion(ep){
  const cuts=ep?.cuts||[];
  if(!cuts.length)return 0;
  return Math.round(cuts.filter(c=>c.status==="done").length/cuts.length*100);
}
function pushTrash(type,payload,context={}){
  const item={trashId:crypto.randomUUID(),type,deletedAt:Date.now(),payload:deepClone(payload),context};
  data.trash.push(item);
  lastTrashId=item.trashId;
  saveData();
  showUndoToast(type);
  return item;
}
function showUndoToast(type){
  const labels={memo:"메모",cut:"컷",episode:"회차",project:"작품"};
  $("#undoText").textContent=`${labels[type]||"항목"}이(가) 휴지통으로 이동했습니다.`;
  $("#undoToast").classList.add("show");
  clearTimeout(showUndoToast._t);
  showUndoToast._t=setTimeout(()=>$("#undoToast").classList.remove("show"),7000);
}
function restoreTrashItem(trashId){
  const item=data.trash.find(x=>x.trashId===trashId);
  if(!item)return;
  if(item.type==="memo"){
    if(!data.memos.some(x=>x.id===item.payload.id)) data.memos.push(item.payload);
  }else if(item.type==="cut"){
    const ep=data.episodes.find(x=>x.id===item.context.episodeId);
    if(ep && !ep.cuts.some(x=>x.id===item.payload.id)){
      const at=Math.max(0,Math.min(ep.cuts.length,item.context.index??ep.cuts.length));
      ep.cuts.splice(at,0,item.payload);
    }
  }else if(item.type==="episode"){
    if(!data.episodes.some(x=>x.id===item.payload.id)) data.episodes.push(item.payload);
  }else if(item.type==="project"){
    const bundle=item.payload;
    if(!data.projects.some(x=>x.id===bundle.project.id)) data.projects.push(bundle.project);
    bundle.episodes.forEach(ep=>{ if(!data.episodes.some(x=>x.id===ep.id)) data.episodes.push(ep); });
  }
  data.trash=data.trash.filter(x=>x.trashId!==trashId);
  saveData();
  renderDashboard();
  if($("#memoView").classList.contains("active"))renderMemos();
  if($("#cutsView").classList.contains("active"))renderEpisodes();
}
$("#undoBtn").addEventListener("click",()=>{
  if(lastTrashId) restoreTrashItem(lastTrashId);
  lastTrashId=null;
  $("#undoToast").classList.remove("show");
});

function renderDashboard(){
  const grid=$("#dashboardGrid"); grid.innerHTML="";
  $("#trashCountBadge").textContent=data.trash.length;
  if(!data.projects.length){
    grid.innerHTML=`<div class="empty-state">아직 작품이 없습니다.<br>컷별 관리에서 작품을 만들어 주세요.</div>`;
  } else {
    data.projects.forEach(p=>{
      const eps=data.episodes.filter(e=>e.projectId===p.id);
      const current=eps.find(e=>(e.cuts||[]).some(c=>c.status!=="done"))||eps[eps.length-1]||null;
      const nearest=[...eps].filter(e=>e.deadline).sort((a,b)=>a.deadline.localeCompare(b.deadline)).find(e=>daysUntil(e.deadline)>=0);
      const allCuts=eps.flatMap(e=>e.cuts||[]);
      const done=allCuts.filter(c=>c.status==="done").length;
      const pct=allCuts.length?Math.round(done/allCuts.length*100):0;
      const nextSchedule=[...data.schedules].filter(s=>s.project===p.name && s.date>=todayISO()).sort((a,b)=>a.date.localeCompare(b.date))[0];
      const card=document.createElement("article");
      card.className="dashboard-card glass";
      card.innerHTML=`<div class="dashboard-card-head"><div><span class="tiny-label">PROJECT</span><h3>${esc(p.name)}</h3></div><span class="dash-percent">${pct}%</span></div>
        <div class="dashboard-current">${current?`<strong>${esc(current.name)}</strong><span>${(current.cuts||[]).filter(c=>c.status==="done").length}/${(current.cuts||[]).length}컷 완료</span>`:"<span>회차 없음</span>"}</div>
        <div class="progress-track"><div class="progress-fill" style="width:${pct}%"></div></div>
        <div class="dashboard-meta"><span>${nearest?`${esc(nearest.name)} · ${ddayLabel(nearest.deadline)}`:"마감일 없음"}</span><span>${nextSchedule?`다음 일정 ${nextSchedule.date}`:"예정 일정 없음"}</span></div>`;
      card.addEventListener("click",()=>{data.activeProjectId=p.id;data.activeEpisodeId=current?.id||eps[0]?.id||null;saveData();switchView("cuts")});
      grid.appendChild(card);
    });
  }
  renderTrash();
}
function renderTrash(){
  const list=$("#trashList");
  if(!list)return;
  list.innerHTML="";
  $("#trashCountBadge").textContent=data.trash.length;
  if(!data.trash.length){list.innerHTML=`<div class="empty-state">휴지통이 비어 있습니다.</div>`;return;}
  [...data.trash].sort((a,b)=>b.deletedAt-a.deletedAt).forEach(item=>{
    const labels={memo:"메모",cut:"컷",episode:"회차",project:"작품"};
    let name=item.type==="project"?item.payload.project?.name:item.payload?.title||item.payload?.name||"컷";
    const row=document.createElement("div");row.className="trash-row";
    row.innerHTML=`<div><strong>${labels[item.type]||item.type} · ${esc(name||"")}</strong><span>${new Date(item.deletedAt).toLocaleString("ko-KR")}</span></div><button class="glass-button secondary">복구</button>`;
    row.querySelector("button").onclick=()=>restoreTrashItem(item.trashId);
    list.appendChild(row);
  });
}
$("#openTrashBtn").onclick=()=>{$("#trashPanel").classList.add("open");renderTrash()};
$("#closeTrashBtn").onclick=()=>$("#trashPanel").classList.remove("open");
$("#emptyTrashBtn").onclick=()=>{if(!data.trash.length)return;if(confirm("휴지통을 완전히 비울까요? 이 작업은 되돌릴 수 없습니다.")){data.trash=[];lastTrashId=null;saveData();renderTrash();}};

function openImageLightbox(src){
  const lightbox=$("#imageLightbox");
  const image=$("#lightboxImage");
  if(!lightbox || !image)return;

  image.src=src;
  lightbox.classList.add("open");
  lightbox.setAttribute("aria-hidden","false");
  lightbox.setAttribute("tabindex","-1");
  document.body.classList.add("lightbox-open");

  // 이미지 자체를 클릭한 뒤에도 키보드 ESC가 안정적으로 동작하도록
  // 확대보기 레이어에 포커스를 둔다.
  requestAnimationFrame(()=>lightbox.focus({preventScroll:true}));
}

function closeImageLightbox(){
  const lightbox=$("#imageLightbox");
  const image=$("#lightboxImage");
  if(!lightbox)return;

  lightbox.classList.remove("open");
  lightbox.setAttribute("aria-hidden","true");
  lightbox.style.display="";
  document.body.classList.remove("lightbox-open");

  if(image){
    setTimeout(()=>{
      if(!lightbox.classList.contains("open")){
        image.removeAttribute("src");
      }
    },80);
  }
}

/* LIGHTBOX ESC CAPTURE v22 */
window.addEventListener("keydown",e=>{
  if(e.key!=="Escape")return;

  const lightbox=document.querySelector("#imageLightbox");
  if(lightbox && lightbox.classList.contains("open")){
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    closeImageLightbox();
  }
},true);
/* END LIGHTBOX ESC CAPTURE v22 */



/* LIGHTBOX X CAPTURE v23 */
document.addEventListener("click",e=>{
  const closeBtn=e.target.closest?.("#closeImageLightbox");
  if(!closeBtn)return;

  const lightbox=document.querySelector("#imageLightbox");
  if(!lightbox || !lightbox.classList.contains("open"))return;

  e.preventDefault();
  e.stopPropagation();
  e.stopImmediatePropagation();
  closeImageLightbox();
},true);
/* END LIGHTBOX X CAPTURE v23 */

const closeImageLightboxBtn=$("#closeImageLightbox");
const imageLightboxEl=$("#imageLightbox");



if(imageLightboxEl){
  // 확대 이미지 바깥의 어두운 영역을 누르면 닫기.
  imageLightboxEl.addEventListener("click",e=>{
    if(e.target===imageLightboxEl){
      e.preventDefault();
      e.stopPropagation();
      closeImageLightbox();
    }
  });

  // 이미지 자체를 누르는 것은 닫기 동작으로 취급하지 않는다.
  const inner=imageLightboxEl.querySelector(".image-lightbox-inner");
  if(inner){
    ["click","mousedown","mouseup","pointerdown","pointerup"].forEach(type=>{
      inner.addEventListener(type,e=>e.stopPropagation());
    });
  }
}

$("#cutImagePreview").addEventListener("click",e=>{e.preventDefault();e.stopPropagation();openImageLightbox(cutImageDraft)});
$("#memoImagePreview").addEventListener("click",e=>{e.preventDefault();e.stopPropagation();openImageLightbox(memoImageDraft)});

/* CALENDAR */
function renderCalendar(){
  const y=calendarCursor.getFullYear(), m=calendarCursor.getMonth();
  $("#monthLabel").textContent=`${y}. ${String(m+1).padStart(2,"0")}`;
  const first=new Date(y,m,1);
  const start=new Date(y,m,1-first.getDay());
  const grid=$("#calendarGrid"); grid.innerHTML="";
  for(let i=0;i<42;i++){
    const d=new Date(start); d.setDate(start.getDate()+i);
    const iso=localISO(d);
    const day=document.createElement("div");
    day.className="day"+(d.getMonth()!==m?" other":"")+(iso===todayISO()?" today":"");
    day.dataset.date=iso;
    const events=data.schedules.filter(s=>{
      const startDate=s.date||"";
      const endDate=s.endDate||startDate;
      return startDate<=iso && iso<=endDate;
    });
    const deadlineEvents=data.episodes.filter(ep=>ep.deadline===iso).map(ep=>({
      deadline:true,
      episodeId:ep.id,
      projectId:ep.projectId,
      title:`${data.projects.find(p=>p.id===ep.projectId)?.name||""} ${ep.name} 마감`
    }));
    const allEvents=[...deadlineEvents,...events.filter(ev=>!(ev.endDate&&ev.endDate>ev.date))];
    day.innerHTML=`<div class="day-number">${d.getDate()}</div><div class="events"></div>`;
    day.addEventListener("dblclick",e=>{
      if(e.target.closest(".event-chip")) return;
      openScheduleModal(null,iso);
    });
    const box=day.querySelector(".events");
    allEvents.slice(0,3).forEach(ev=>{
      const btn=document.createElement("button");
      const isRange=!ev.deadline && ev.endDate && ev.endDate>ev.date;
      const rangePos=isRange?(iso===ev.date?" range-start":iso===ev.endDate?" range-end":" range-middle"):"";
      btn.className="event-chip"+(ev.deadline?" deadline-chip":"")+(ev.status==="done"?" done":"")+(isRange?" range-event":"")+rangePos;
      if(!ev.deadline && ev.id) btn.dataset.scheduleId=ev.id;
      btn.textContent=ev.deadline?`마감 · ${ev.title}`:`${isRange?(iso===ev.date?"↔ ":""):""}${ev.stage} · ${ev.title}`;
      const rangeText=isRange?` / ${ev.date.replaceAll("-",".")} ~ ${ev.endDate.replaceAll("-",".")}`:"";
      btn.title=ev.deadline?ev.title:`${ev.project||""} ${ev.episode||""} / ${ev.progress||0}%${rangeText}`;
      btn.addEventListener("click",e=>{
        e.stopPropagation();
        if(ev.deadline){data.activeProjectId=ev.projectId;data.activeEpisodeId=ev.episodeId;saveData();switchView("cuts");}
        else openScheduleModal(ev.id);
      });
      box.appendChild(btn);
    });
    if(allEvents.length>3){
      const more=document.createElement("div");more.className="more-events";more.textContent=`+${allEvents.length-3} more`;box.appendChild(more);
    }
    grid.appendChild(day);
  }
}
function localISO(d){
  const off=d.getTimezoneOffset();
  return new Date(d.getTime()-off*60000).toISOString().slice(0,10);
}
$("#prevMonth").onclick=()=>{calendarCursor.setMonth(calendarCursor.getMonth()-1);renderCalendar()}
$("#nextMonth").onclick=()=>{calendarCursor.setMonth(calendarCursor.getMonth()+1);renderCalendar()}
$("#addScheduleBtn").onclick=()=>openScheduleModal(null,todayISO());

function openScheduleModal(id,date){
  const modal=$("#scheduleModal");
  const s=id?data.schedules.find(x=>x.id===id):null;
  $("#scheduleModalTitle").textContent=s?"일정 편집":"일정 추가";
  $("#scheduleId").value=s?.id||"";
  $("#scheduleDate").value=s?.date||date||todayISO();
  $("#scheduleEndDate").value=s?.endDate||"";
  $("#scheduleEndDate").min=$("#scheduleDate").value;
  $("#scheduleProject").value=s?.project||"";
  $("#scheduleEpisode").value=s?.episode||"";
  $("#scheduleStage").value=s?.stage||"글콘티";
  $("#scheduleTitle").value=s?.title||"";
  $("#scheduleProgress").value=s?.progress??0;
  $("#scheduleStatus").value=s?.status||"todo";
  $("#scheduleMemo").value=s?.memo||"";
  $("#deleteScheduleBtn").style.visibility=s?"visible":"hidden";
  modal.classList.add("open");
}
function closeScheduleModal(){ $("#scheduleModal").classList.remove("open");}
$$(".close-modal").forEach(b=>b.onclick=closeScheduleModal);
// 캘린더 일정 편집창은 배경 클릭이나 텍스트 드래그로 닫히지 않는다.
// 일정 창 외부에서 발생하는 클릭/포인터 이벤트는 닫기 동작으로 처리하지 않는다.
["click","mousedown","mouseup","pointerdown","pointerup"].forEach(type=>{
  $("#scheduleModal").addEventListener(type,e=>{
    if(e.target.id==="scheduleModal"){
      e.preventDefault();
      e.stopPropagation();
    }
  });
});
$("#scheduleModal .modal").addEventListener("click",e=>e.stopPropagation());
$("#scheduleModal .modal").addEventListener("mousedown",e=>e.stopPropagation());
$("#scheduleModal .modal").addEventListener("mouseup",e=>e.stopPropagation());
$("#scheduleModal .modal").addEventListener("pointerdown",e=>e.stopPropagation());
$("#scheduleModal .modal").addEventListener("pointerup",e=>e.stopPropagation());
$("#scheduleDate").addEventListener("change",()=>{
  const start=$("#scheduleDate").value;
  const end=$("#scheduleEndDate");
  end.min=start;
  if(end.value && end.value<start)end.value=start;
});
$("#scheduleEndDate").addEventListener("change",()=>{
  const start=$("#scheduleDate").value;
  if($("#scheduleEndDate").value && $("#scheduleEndDate").value<start){
    $("#scheduleEndDate").value=start;
  }
});
$("#scheduleForm").onsubmit=e=>{
  e.preventDefault();
  const id=$("#scheduleId").value||crypto.randomUUID();
  const startDate=$("#scheduleDate").value;
  const endDate=$("#scheduleEndDate").value;
  if(endDate && endDate<startDate){
    alert("종료일은 시작일보다 빠를 수 없습니다.");
    return;
  }
  const obj={id,date:startDate,endDate,project:$("#scheduleProject").value.trim(),episode:$("#scheduleEpisode").value.trim(),stage:$("#scheduleStage").value,title:$("#scheduleTitle").value.trim(),progress:Number($("#scheduleProgress").value||0),status:$("#scheduleStatus").value,memo:$("#scheduleMemo").value};
  const idx=data.schedules.findIndex(x=>x.id===id);
  if(idx>=0)data.schedules[idx]=obj;else data.schedules.push(obj);
  saveData();renderCalendar();closeScheduleModal();
}
$("#deleteScheduleBtn").onclick=()=>{
  const id=$("#scheduleId").value;if(!id)return;
  data.schedules=data.schedules.filter(x=>x.id!==id);saveData();renderCalendar();closeScheduleModal();
}

/* MEMOS */
let memoSelectMode=false;
let selectedMemoIds=new Set();
let memoDeleteInProgress=false;

function visibleMemoItems(){
  const q=$("#memoSearch").value.trim().toLowerCase();
  let items=[...data.memos].sort((a,b)=>(b.pinned-a.pinned)||((b.updated||0)-(a.updated||0)));
  if(q){
    items=items.filter(m=>[m.title,m.content,m.type,m.tag].some(v=>(v||"").toLowerCase().includes(q)));
  }
  return items;
}

function syncMemoSelectionUI(){
  $("#toggleMemoSelectBtn").textContent=memoSelectMode?"✕ 선택 모드 종료":"☑ 메모 선택";
  $("#memoBulkBox").classList.toggle("active",memoSelectMode);
  $("#memoSelectedCount").textContent=`${selectedMemoIds.size}개 선택`;

  const visibleIds=visibleMemoItems().map(m=>m.id);
  const allVisibleSelected=visibleIds.length>0 && visibleIds.every(id=>selectedMemoIds.has(id));

  $("#toggleAllMemosBtn").textContent=allVisibleSelected?"전체선택해제":"전체선택";
  $("#toggleAllMemosBtn").disabled=visibleIds.length===0;
  $("#deleteSelectedMemosBtn").disabled=selectedMemoIds.size===0;
}

function renderMemos(){
  const items=visibleMemoItems();
  const board=$("#memoBoard");board.innerHTML="";
  syncMemoSelectionUI();
  if(!items.length){board.innerHTML=`<div class="empty-state">아직 메모가 없습니다.<br>새 메모를 만들어 이야기를 쌓아보세요.</div>`;return}
  items.forEach(m=>{
    const el=document.createElement("article");
    el.className="memo-card"+(m.pinned?" pinned":"")+(m.image?" has-image":"")+(memoSelectMode?" select-mode":"")+(selectedMemoIds.has(m.id)?" selected":"");
    const imageHtml=m.image?`<div class="memo-card-image"><img src="${m.image}" alt="${esc(m.title)} 첨부 이미지"></div>`:"";
    const memoBodyHtml=(typeof window.renderMemoMarkdown==="function")
      ? window.renderMemoMarkdown(m.content||"내용 없음",{compact:true})
      : esc(m.content||"내용 없음");
    el.innerHTML=`<div class="memo-select-check"></div>${imageHtml}<span class="memo-type">${esc(m.type)}</span><h4>${esc(m.title)}</h4><div class="memo-preview markdown-body">${memoBodyHtml}</div><div class="memo-meta"><span>${esc(m.tag||"태그 없음")}</span><span>${formatDate(m.updated)}</span></div>`;
    el.onclick=()=>{
      if(memoSelectMode){
        if(selectedMemoIds.has(m.id)) selectedMemoIds.delete(m.id);
        else selectedMemoIds.add(m.id);
        syncMemoSelectionUI();
        el.classList.toggle("selected",selectedMemoIds.has(m.id));
        return;
      }
      openMemoModal(m.id);
    };
    board.appendChild(el);
  });
}
function formatDate(ts){if(!ts)return"";return new Intl.DateTimeFormat("ko-KR",{month:"numeric",day:"numeric"}).format(new Date(ts))}
function esc(str=""){return str.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
$("#memoSearch").oninput=()=>{
  // 검색 결과가 바뀌어도 기존 선택은 유지하되,
  // 전체선택 버튼은 현재 보이는 메모 기준으로 동작한다.
  renderMemos();
};

$("#toggleMemoSelectBtn").addEventListener("click",()=>{
  memoSelectMode=!memoSelectMode;
  if(!memoSelectMode) selectedMemoIds.clear();
  syncMemoSelectionUI();
  renderMemos();
});

$("#toggleAllMemosBtn").addEventListener("click",()=>{
  const visibleIds=visibleMemoItems().map(m=>m.id);
  if(!visibleIds.length)return;

  const allSelected=visibleIds.every(id=>selectedMemoIds.has(id));

  if(allSelected){
    visibleIds.forEach(id=>selectedMemoIds.delete(id));
  }else{
    visibleIds.forEach(id=>selectedMemoIds.add(id));
  }

  syncMemoSelectionUI();
  renderMemos();
});

$("#deleteSelectedMemosBtn").addEventListener("click",()=>{
  if(!selectedMemoIds.size)return;

  const count=selectedMemoIds.size;
  const ok=confirm(`선택한 메모 ${count}개를 삭제할까요?`);
  if(!ok)return;

  const doomed=data.memos.filter(m=>selectedMemoIds.has(m.id));
  doomed.forEach(m=>pushTrash("memo",m));
  data.memos=data.memos.filter(m=>!selectedMemoIds.has(m.id));
  selectedMemoIds.clear();

  saveData();
  syncMemoSelectionUI();
  renderMemos();
});

$("#addMemoBtn").onclick=()=>openMemoModal();

let memoImageDraft="";

function updateMemoImageUI(){
  const has=!!memoImageDraft;
  $("#memoImageEmpty").style.display=has?"none":"flex";
  $("#memoImagePreviewWrap").classList.toggle("active",has);
  $("#memoImageActions").classList.toggle("active",has);
  if(has) $("#memoImagePreview").src=memoImageDraft;
  else $("#memoImagePreview").removeAttribute("src");
}

async function compressMemoImage(file){
  if(!file || !file.type.startsWith("image/")) throw new Error("이미지 파일이 아닙니다.");
  const raw=await fileToDataURL(file);
  const img=await loadImage(raw);
  const maxSide=1600;
  let w=img.width,h=img.height;
  const scale=Math.min(1,maxSide/Math.max(w,h));
  w=Math.max(1,Math.round(w*scale));
  h=Math.max(1,Math.round(h*scale));
  const canvas=document.createElement("canvas");
  canvas.width=w; canvas.height=h;
  const ctx=canvas.getContext("2d");
  ctx.drawImage(img,0,0,w,h);
  return canvas.toDataURL("image/jpeg",0.82);
}
function fileToDataURL(file){
  return new Promise((resolve,reject)=>{
    const r=new FileReader();
    r.onload=()=>resolve(r.result);
    r.onerror=reject;
    r.readAsDataURL(file);
  });
}
function loadImage(src){
  return new Promise((resolve,reject)=>{
    const img=new Image();
    img.onload=()=>resolve(img);
    img.onerror=reject;
    img.src=src;
  });
}
async function handleMemoImage(file){
  try{
    memoImageDraft=await compressMemoImage(file);
    updateMemoImageUI();
    scheduleMemoDraftAutosave();
  }catch(err){
    alert("사진을 불러오지 못했습니다.");
  }
}

$("#memoImageInput").addEventListener("change",e=>{
  const f=e.target.files?.[0];
  if(f) handleMemoImage(f);
  e.target.value="";
});
$("#replaceMemoImageBtn").onclick=()=>{
  $("#memoImageInput").click();
};
$("#removeMemoImageBtn").onclick=()=>{
  memoImageDraft="";
  updateMemoImageUI();
  scheduleMemoDraftAutosave();
};
$("#memoImageDrop").addEventListener("dragover",e=>{
  e.preventDefault();
  $("#memoImageDrop").classList.add("dragover");
});
$("#memoImageDrop").addEventListener("dragleave",()=>{
  $("#memoImageDrop").classList.remove("dragover");
});
$("#memoImageDrop").addEventListener("drop",e=>{
  e.preventDefault();
  $("#memoImageDrop").classList.remove("dragover");
  const f=[...e.dataTransfer.files].find(x=>x.type.startsWith("image/"));
  if(f) handleMemoImage(f);
});

function openMemoModal(id){
  memoDeleteInProgress=false;
  const m=id?data.memos.find(x=>x.id===id):null;
  $("#memoModalTitle").textContent=m?"메모 편집":"새 메모";
  $("#memoId").value=m?.id||"";
  $("#memoType").value=m?.type||"글콘티";
  $("#memoTag").value=m?.tag||"";
  $("#memoTitle").value=m?.title||"";
  $("#memoContent").value=m?.content||"";
  $("#memoPinned").checked=!!m?.pinned;
  memoImageDraft=m?.image||"";
  updateMemoImageUI();
  $("#deleteMemoBtn").style.visibility=m?"visible":"hidden";
  $("#memoModal").classList.add("open");
}
function closeMemoModal(){
  clearTimeout(memoDraftSaveTimer);

  // 일반 X 닫기일 때는 마지막 내용을 저장한다.
  // 저장 버튼 직후/삭제 직후에는 이미 처리됐으므로 중복 저장을 건너뛴다.
  if(
    $("#memoModal").classList.contains("open") &&
    !memoDeleteInProgress &&
    !memoCloseSkipSave
  ){
    saveOpenMemoDraft({render:true});
  }

  $("#memoModal").classList.remove("open");
  memoDeleteInProgress=false;
  memoCloseSkipSave=false;
}
$("#closeMemoX").addEventListener("click",e=>{
  e.preventDefault();
  e.stopPropagation();
  closeMemoModal();
});

// 메모 편집창은 오직 X 버튼으로만 닫힌다.
// 배경 클릭/드래그/포인터 이동은 전부 닫기 동작과 분리한다.
["click","mousedown","mouseup","pointerdown","pointerup"].forEach(type=>{
  $("#memoModal").addEventListener(type,e=>{
    if(e.target.id==="memoModal"){
      e.preventDefault();
      e.stopPropagation();
    }
  });
});
$("#memoModal .modal").addEventListener("click",e=>e.stopPropagation());
$("#memoModal .modal").addEventListener("mousedown",e=>e.stopPropagation());
$("#memoModal .modal").addEventListener("mouseup",e=>e.stopPropagation());
$("#memoModal .modal").addEventListener("pointerdown",e=>e.stopPropagation());
$("#memoModal .modal").addEventListener("pointerup",e=>e.stopPropagation());
let memoDraftSaveTimer=null;
let memoCloseSkipSave=false;

function saveOpenMemoDraft({render=false}={}){
  if(!$("#memoModal").classList.contains("open"))return;

  let id=$("#memoId").value;
  const title=$("#memoTitle").value.trim();

  // 새 메모는 사용자가 실제로 뭔가 입력한 시점에만 자동 생성한다.
  const hasAnyContent=
    title ||
    $("#memoContent").value.trim() ||
    $("#memoTag").value.trim() ||
    memoImageDraft;

  if(!id && !hasAnyContent)return;

  if(!id){
    id=crypto.randomUUID();
    $("#memoId").value=id;
  }

  const obj={
    id,
    type:$("#memoType").value,
    tag:$("#memoTag").value.trim(),
    title:title || "제목 없는 메모",
    content:$("#memoContent").value,
    pinned:$("#memoPinned").checked,
    image:memoImageDraft,
    updated:Date.now()
  };

  const idx=data.memos.findIndex(x=>x.id===id);
  if(idx>=0)data.memos[idx]=obj;
  else data.memos.push(obj);

  saveData();
  if(render)renderMemos();
}

function scheduleMemoDraftAutosave(){
  clearTimeout(memoDraftSaveTimer);
  memoDraftSaveTimer=setTimeout(()=>{
    saveOpenMemoDraft({render:false});
  },180);
}

["memoTitle","memoTag","memoContent"].forEach(id=>{
  $("#"+id).addEventListener("input",scheduleMemoDraftAutosave);
});
$("#memoType").addEventListener("change",scheduleMemoDraftAutosave);
$("#memoPinned").addEventListener("change",scheduleMemoDraftAutosave);

$("#memoForm").onsubmit=e=>{
  e.preventDefault();
  clearTimeout(memoDraftSaveTimer);

  // 저장 버튼 = 메모 작업 완료.
  // 먼저 저장한 뒤 편집창을 자동으로 닫는다.
  saveOpenMemoDraft({render:true});
  $("#saveText").textContent="저장됨";
  memoCloseSkipSave=true;
  closeMemoModal();
}
$("#deleteMemoBtn").onclick=()=>{
  const id=$("#memoId").value;
  if(!id)return;

  const memo=data.memos.find(x=>x.id===id);
  const ok=confirm(`메모 "${memo?.title||"제목 없는 메모"}"를 삭제할까요?`);
  if(!ok)return;

  clearTimeout(memoDraftSaveTimer);
  memoDeleteInProgress=true;

  pushTrash("memo",memo||data.memos.find(x=>x.id===id)||{id,title:"제목 없는 메모"});
  data.memos=data.memos.filter(x=>x.id!==id);
  selectedMemoIds.delete(id);

  // 현재 편집 중인 ID도 비워 자동저장이 삭제 메모를 되살리지 못하게 한다.
  $("#memoId").value="";
  memoImageDraft="";

  saveData();
  renderMemos();
  closeMemoModal();
}

/* PROJECTS + EPISODES + CUTS */
function activeProject(){
  return data.projects.find(p=>p.id===data.activeProjectId)||data.projects[0]||null;
}
function projectEpisodes(projectId=data.activeProjectId){
  return data.episodes.filter(e=>e.projectId===projectId);
}
function activeEpisode(){
  return data.episodes.find(e=>e.id===data.activeEpisodeId && e.projectId===data.activeProjectId)||projectEpisodes()[0]||null;
}

function renderProjects(){
  const sel=$("#projectSelect");
  sel.innerHTML="";

  data.projects.forEach(p=>{
    const o=document.createElement("option");
    o.value=p.id;
    o.textContent=p.name;
    sel.appendChild(o);
  });

  if(!activeProject() && data.projects[0]) data.activeProjectId=data.projects[0].id;
  sel.value=data.activeProjectId||"";
}

function renderEpisodes(){
  renderProjects();

  const eps=projectEpisodes();
  const sel=$("#episodeSelect");
  sel.innerHTML="";

  eps.forEach(e=>{
    const o=document.createElement("option");
    o.value=e.id;
    o.textContent=e.name;
    sel.appendChild(o);
  });

  if(!activeEpisode()){
    data.activeEpisodeId=eps[0]?.id||null;
  }

  sel.value=data.activeEpisodeId||"";
  renderCuts();
}

$("#projectSelect").onchange=e=>{
  data.activeProjectId=e.target.value;
  data.activeEpisodeId=projectEpisodes(data.activeProjectId)[0]?.id||null;
  selectedCutIds.clear();
  syncBulkSelectionUI();
  saveData();
  renderEpisodes();
};

$("#newProjectBtn").onclick=()=>{
  $("#newProjectName").value="";
  $("#projectModal").classList.add("open");
  setTimeout(()=>$("#newProjectName").focus(),0);
};

$$(".close-project-modal").forEach(b=>b.onclick=()=>$("#projectModal").classList.remove("open"));
$("#projectModal").addEventListener("click",e=>{
  if(e.target.id==="projectModal") $("#projectModal").classList.remove("open");
});

$("#projectForm").onsubmit=e=>{
  e.preventDefault();
  const name=$("#newProjectName").value.trim();
  if(!name)return;

  const project={id:crypto.randomUUID(),name};
  data.projects.push(project);
  data.activeProjectId=project.id;
  data.activeEpisodeId=null;

  saveData();
  $("#projectModal").classList.remove("open");
  $("#projectForm").reset();
  renderEpisodes();
};

$("#deleteProjectBtn").addEventListener("click",()=>{
  const project=activeProject();
  if(!project)return;

  const epCount=projectEpisodes(project.id).length;
  const cutCount=projectEpisodes(project.id).reduce((sum,ep)=>sum+(ep.cuts?.length||0),0);

  const ok=confirm(
    `작품 "${project.name}"을 삭제할까요?\n\n`+
    `이 작품의 회차 ${epCount}개와 컷 ${cutCount}개도 함께 삭제됩니다.\n`+
    `삭제한 데이터는 현재 로컬 저장소에서 제거됩니다.`
  );
  if(!ok)return;

  pushTrash("project",{project,episodes:projectEpisodes(project.id)});
  data.episodes=data.episodes.filter(ep=>ep.projectId!==project.id);
  data.projects=data.projects.filter(p=>p.id!==project.id);

  data.activeProjectId=data.projects[0]?.id||null;
  data.activeEpisodeId=data.activeProjectId
    ? data.episodes.find(ep=>ep.projectId===data.activeProjectId)?.id||null
    : null;

  selectedCutIds.clear();
  saveData();
  syncBulkSelectionUI();
  renderEpisodes();
});

$("#episodeSelect").onchange=e=>{
  data.activeEpisodeId=e.target.value;
  selectedCutIds.clear();
  syncBulkSelectionUI();
  saveData();
  renderCuts();
};

$("#newEpisodeBtn").onclick=()=>{
  if(!activeProject()){
    $("#projectModal").classList.add("open");
    return;
  }
  $("#episodeModal").classList.add("open");
};

$$(".close-episode-modal").forEach(b=>b.onclick=()=>$("#episodeModal").classList.remove("open"));
$("#episodeModal").addEventListener("click",e=>{if(e.target.id==="episodeModal")$("#episodeModal").classList.remove("open")});

$("#episodeForm").onsubmit=e=>{
  e.preventDefault();

  const project=activeProject();
  if(!project)return;

  const name=$("#newEpisodeName").value.trim();
  const n=Math.max(0,Math.min(300,Number($("#newEpisodeCuts").value||0)));

  const ep={
    id:crypto.randomUUID(),
    projectId:project.id,
    name,
    deadline:"",
    memo:"",
    cuts:Array.from({length:n},()=>({
      id:crypto.randomUUID(),
      description:"",
      dialogue:"",
      status:"todo",
      tag:"",
      note:"",
      image:"",
      important:false,
      characters:""
    }))
  };

  data.episodes.push(ep);
  data.activeEpisodeId=ep.id;

  saveData();
  $("#episodeModal").classList.remove("open");
  $("#episodeForm").reset();
  $("#newEpisodeCuts").value=20;
  renderEpisodes();
};

$("#deleteEpisodeBtn").addEventListener("click",()=>{
  const ep=activeEpisode();
  const project=activeProject();
  if(!ep || !project)return;

  const cutCount=ep.cuts?.length||0;
  const ok=confirm(
    `회차 "${ep.name}"을 삭제할까요?\n\n`+
    `이 회차의 컷 ${cutCount}개도 함께 삭제됩니다.`
  );
  if(!ok)return;

  pushTrash("episode",ep,{projectId:project.id});
  data.episodes=data.episodes.filter(x=>x.id!==ep.id);
  data.activeEpisodeId=projectEpisodes(project.id)[0]?.id||null;

  selectedCutIds.clear();
  saveData();
  syncBulkSelectionUI();
  renderEpisodes();
});

$("#addCutBtn").onclick=()=>{
  const ep=activeEpisode();

  if(!activeProject()){
    $("#projectModal").classList.add("open");
    return;
  }
  if(!ep){
    $("#episodeModal").classList.add("open");
    return;
  }

  const cut={id:crypto.randomUUID(),description:"",dialogue:"",status:"todo",tag:"",note:"",image:"",important:false,characters:""};
  ep.cuts.push(cut);
  saveData();
  renderCuts();
  openCutModal(cut.id);
};


$("#episodeSettingsBtn").addEventListener("click",()=>{
  const ep=activeEpisode(); if(!ep)return;
  $("#episodeSettingsTitle").textContent=`${ep.name} 설정`;
  $("#editEpisodeName").value=ep.name||"";
  $("#episodeDeadline").value=ep.deadline||"";
  $("#episodeMemo").value=ep.memo||"";
  $("#episodeSettingsModal").classList.add("open");
});
$("#closeEpisodeSettingsX").onclick=()=>$("#episodeSettingsModal").classList.remove("open");
$("#episodeSettingsForm").onsubmit=e=>{
  e.preventDefault();
  const ep=activeEpisode(); if(!ep)return;
  ep.name=$("#editEpisodeName").value.trim()||ep.name;
  ep.deadline=$("#episodeDeadline").value;
  ep.memo=$("#episodeMemo").value;
  saveData(); $("#episodeSettingsModal").classList.remove("open"); renderEpisodes(); renderCalendar();
};

let cutStatusFilter="all";
let cutCharacterFilter="all";
let importantOnly=false;
$("#cutStatusFilter").onchange=e=>{cutStatusFilter=e.target.value;renderCuts()};
$("#cutCharacterFilter").onchange=e=>{cutCharacterFilter=e.target.value;renderCuts()};
$("#importantFilterBtn").onclick=()=>{importantOnly=!importantOnly;$("#importantFilterBtn").textContent=importantOnly?"★ 중요 컷만":"☆ 중요 컷만";renderCuts()};
$("#resetCutFiltersBtn").onclick=()=>{cutStatusFilter="all";cutCharacterFilter="all";importantOnly=false;$("#cutStatusFilter").value="all";$("#cutCharacterFilter").value="all";$("#importantFilterBtn").textContent="☆ 중요 컷만";renderCuts()};

const statusLabel={todo:"미작업",rough:"러프",line:"선화",color:"채색",post:"후보정",assistant:"어시",done:"완료"};

let cutSelectMode=false;
let selectedCutIds=new Set();

function syncBulkSelectionUI(){
  $("#toggleCutSelectBtn").textContent=cutSelectMode?"✕ 선택 모드 종료":"☑ 컷 선택";
  $("#bulkStatusBox").classList.toggle("active",cutSelectMode);
  $("#bulkSelectedCount").textContent=`${selectedCutIds.size}개 선택`;

  const ep=activeEpisode();
  const totalCuts=ep?.cuts.length||0;
  const allSelected=totalCuts>0 && selectedCutIds.size===totalCuts;
  $("#toggleAllCutsBtn").textContent=allSelected?"전체선택해제":"전체선택";
  $("#toggleAllCutsBtn").disabled=totalCuts===0;

  $("#applyBulkStatusBtn").disabled=selectedCutIds.size===0;
  $("#deleteSelectedCutsBtn").disabled=selectedCutIds.size===0;

  $("#deleteProjectBtn").disabled=!activeProject();
  $("#deleteEpisodeBtn").disabled=!activeEpisode();
}

function clearCutSelection(){
  selectedCutIds.clear();
  syncBulkSelectionUI();
  renderCuts();
}

$("#toggleCutSelectBtn").addEventListener("click",()=>{
  cutSelectMode=!cutSelectMode;
  if(!cutSelectMode) selectedCutIds.clear();
  syncBulkSelectionUI();
  renderCuts();
});

$("#clearCutSelectionBtn").addEventListener("click",clearCutSelection);

$("#toggleAllCutsBtn").addEventListener("click",()=>{
  const ep=activeEpisode();
  if(!ep || ep.cuts.length===0)return;

  const allSelected=selectedCutIds.size===ep.cuts.length;

  if(allSelected){
    selectedCutIds.clear();
  }else{
    selectedCutIds=new Set(ep.cuts.map(c=>c.id));
  }

  syncBulkSelectionUI();
  renderCuts();
});

$("#applyBulkStatusBtn").addEventListener("click",()=>{
  if(!selectedCutIds.size)return;
  const ep=activeEpisode();
  if(!ep)return;

  const nextStatus=$("#bulkStatusSelect").value;

  ep.cuts.forEach(c=>{
    if(selectedCutIds.has(c.id)) c.status=nextStatus;
  });

  saveData();
  selectedCutIds.clear();
  syncBulkSelectionUI();
  renderCuts();
});

$("#deleteSelectedCutsBtn").addEventListener("click",()=>{
  if(!selectedCutIds.size)return;

  const ep=activeEpisode();
  if(!ep)return;

  const count=selectedCutIds.size;
  const ok=confirm(`선택한 컷 ${count}개를 삭제할까요?\n삭제한 컷은 현재 로컬 데이터에서 제거됩니다.`);
  if(!ok)return;

  ep.cuts.forEach((c,idx)=>{if(selectedCutIds.has(c.id))pushTrash("cut",c,{episodeId:ep.id,index:idx})});
  ep.cuts=ep.cuts.filter(c=>!selectedCutIds.has(c.id));

  selectedCutIds.clear();
  saveData();
  syncBulkSelectionUI();
  renderCuts();
});

function renderCuts(){
  const ep=activeEpisode(), grid=$("#cutsGrid");grid.innerHTML="";
  syncBulkSelectionUI();
  const project=activeProject();
  $("#projectName").textContent=project?.name||"작품 없음";
  if(!ep){
    $("#episodeName").textContent="회차 없음";$("#cutCount").textContent="0";$("#cutDoneCount").textContent="0";$("#cutProgressText").textContent="0%";$("#cutProgressFill").style.width="0%";
    grid.innerHTML=`<div class="empty-state">${project?"이 작품에 회차가 없습니다.<br>새 회차를 만들어 주세요.":"먼저 작품을 만들어 주세요."}</div>`;return;
  }
  $("#episodeName").textContent=ep.name;
  $("#cutCount").textContent=ep.cuts.length;
  const done=ep.cuts.filter(c=>c.status==="done").length;
  const pct=ep.cuts.length?Math.round(done/ep.cuts.length*100):0;
  $("#cutDoneCount").textContent=done;$("#cutProgressText").textContent=pct+"%";$("#cutProgressFill").style.width=pct+"%";
  const counts={todo:0,rough:0,line:0,color:0,post:0,assistant:0,done:0};
  ep.cuts.forEach(c=>counts[c.status]=(counts[c.status]||0)+1);
  $("#stageStats").innerHTML=Object.entries(counts)
    .map(([k,v])=>`<span class="stage-stat-tag status-tag-${k}"><b>${statusLabel[k]}</b> ${v}</span>`)
    .join("");
  $("#episodeNotePreview").textContent=ep.memo?`회차 메모 · ${ep.memo}`:"회차 메모 없음";
  $("#deadlineDisplay").textContent=ep.deadline?`${ep.deadline} · ${ddayLabel(ep.deadline)}`:"마감일 미설정";

  const chars=[...new Set(ep.cuts.flatMap(c=>(c.characters||"").split(",").map(x=>x.trim()).filter(Boolean)))].sort();
  const charSel=$("#cutCharacterFilter");
  const keep=cutCharacterFilter;
  charSel.innerHTML=`<option value="all">전체 캐릭터</option>`+chars.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join("");
  if(chars.includes(keep))charSel.value=keep;else{cutCharacterFilter="all";charSel.value="all";}

  const visible=ep.cuts.map((c,i)=>({c,i})).filter(({c})=>{
    if(cutStatusFilter!=="all"&&c.status!==cutStatusFilter)return false;
    if(importantOnly&&!c.important)return false;
    if(cutCharacterFilter!=="all"&&!(c.characters||"").split(",").map(x=>x.trim()).includes(cutCharacterFilter))return false;
    return true;
  });
  visible.forEach(({c,i})=>{
    const el=document.createElement("article");
    el.className="cut-card status-"+(c.status||"todo")+(cutSelectMode?" select-mode":"")+(selectedCutIds.has(c.id)?" selected":"");
    el.draggable=!cutSelectMode;
    el.dataset.id=c.id;
    const cutImg=c.image?`<div class="cut-thumb"><img src="${c.image}" alt="CUT ${i+1} 이미지"></div>`:"";
    el.innerHTML=`<div class="cut-select-check"></div>${cutImg}
      <div class="cut-head"><span class="cut-number">CUT ${String(i+1).padStart(2,"0")}${c.important?` <span class="important-star">★</span>`:""}</span><span class="status-pill status-tag-${c.status||"todo"}">${statusLabel[c.status]||c.status}</span></div>
      <div class="cut-desc">${esc(c.description||"컷 설명을 입력하세요.")}</div>
      <div class="cut-dialogue">${esc(c.dialogue||"대사 없음")}</div>
      <div class="cut-characters">${esc(c.characters||"")}</div>
      <div class="cut-tag">${esc(c.tag||"")}</div><div class="drag-handle">${cutSelectMode?"":"⋮⋮"}</div>`;

    const thumb=el.querySelector(".cut-thumb");
    if(thumb)thumb.addEventListener("click",e=>{e.stopPropagation();openImageLightbox(c.image)});

    el.onclick=e=>{
      if(cutSelectMode){
        if(selectedCutIds.has(c.id)) selectedCutIds.delete(c.id);
        else selectedCutIds.add(c.id);
        syncBulkSelectionUI();
        el.classList.toggle("selected",selectedCutIds.has(c.id));
        return;
      }

      if(el.dataset.justDragged==="1"){
        el.dataset.justDragged="0";
        return;
      }
      if(draggedCutId)return;
      openCutModal(c.id);
    };

    if(!cutSelectMode){
      el.addEventListener("dragstart",()=>{el.dataset.justDragged="1"});
    }
    grid.appendChild(el);
  });
}
let draggedCutId=null;
let cutInsertIndex=null;

function clearCutDropIndicators(){
  $$("#cutsGrid .cut-card").forEach(card=>{
    card.classList.remove("insert-before","insert-after");
  });
}

function isInsideCutsGrid(clientX,clientY){
  const grid=$("#cutsGrid");
  if(!grid)return false;
  const rect=grid.getBoundingClientRect();
  return clientX>=rect.left &&
         clientX<=rect.right &&
         clientY>=rect.top &&
         clientY<=rect.bottom;
}

function getDropPosition(e){
  const ep=activeEpisode();
  if(!ep || !draggedCutId) return null;

  // 컷 영역 밖에서는 어떤 이동도 허용하지 않는다.
  if(!isInsideCutsGrid(e.clientX,e.clientY)) return null;

  const target=e.target.closest(".cut-card");

  // 컷 영역의 빈 공간에 놓은 경우에만 맨 끝 삽입을 허용한다.
  if(!target){
    return {index:ep.cuts.length, target:null, side:"after"};
  }

  // 자기 자신 위에서는 현재 위치를 유지한다.
  if(target.dataset.id===draggedCutId){
    return null;
  }

  const targetOriginalIndex=ep.cuts.findIndex(c=>c.id===target.dataset.id);
  if(targetOriginalIndex<0) return null;

  const draggedOriginalIndex=ep.cuts.findIndex(c=>c.id===draggedCutId);
  const rect=target.getBoundingClientRect();

  const side=e.clientX < rect.left + rect.width/2 ? "before" : "after";

  let boundary=targetOriginalIndex+(side==="after"?1:0);

  if(draggedOriginalIndex < boundary) boundary--;

  boundary=Math.max(0,Math.min(ep.cuts.length-1,boundary));

  return {index:boundary,target,side};
}

$("#cutsGrid").addEventListener("dragstart",e=>{
  const card=e.target.closest(".cut-card");
  if(!card)return;

  draggedCutId=card.dataset.id;
  cutInsertIndex=null;

  document.body.classList.add("cut-dragging");
  card.classList.add("dragging");

  e.dataTransfer.effectAllowed="move";
  try{
    e.dataTransfer.setData("text/plain",draggedCutId);
  }catch(_){}

  // 브라우저의 기본 드래그 고스트가 너무 불투명하게 겹치지 않도록 한다.
  requestAnimationFrame(()=>card.classList.add("drag-source"));
});

$("#cutsGrid").addEventListener("dragover",e=>{
  if(!draggedCutId)return;

  e.preventDefault();
  e.stopPropagation();
  e.dataTransfer.dropEffect="move";
  clearCutDropIndicators();

  const pos=getDropPosition(e);
  if(!pos){
    cutInsertIndex=null;
    return;
  }

  cutInsertIndex=pos.index;

  if(pos.target){
    pos.target.classList.add(pos.side==="before" ? "insert-before" : "insert-after");
  }
});

$("#cutsGrid").addEventListener("drop",e=>{
  e.preventDefault();

  const ep=activeEpisode();
  if(!ep || !draggedCutId)return;

  // drop 순간에도 컷 영역 내부인지 다시 확인한다.
  // 영역 밖이면 순서 변경을 취소하고 원본을 그대로 유지한다.
  const pos=getDropPosition(e);
  const requestedIndex=pos ? pos.index : null;

  if(requestedIndex===null || requestedIndex===undefined){
    draggedCutId=null;
    cutInsertIndex=null;
    document.body.classList.remove("cut-dragging");
    clearCutDropIndicators();
    renderCuts();
    return;
  }

  const fromIndex=ep.cuts.findIndex(c=>c.id===draggedCutId);
  if(fromIndex<0){
    draggedCutId=null;
    cutInsertIndex=null;
    clearCutDropIndicators();
    return;
  }

  // 중요: movedCut 객체를 그대로 꺼냈다가 다시 삽입한다.
  // 컷 내용을 복사/재생성/덮어쓰기 하지 않으므로 어떤 컷도 사라지지 않는다.
  const [movedCut]=ep.cuts.splice(fromIndex,1);

  let insertIndex = requestedIndex;
  if(insertIndex===null || insertIndex===undefined){
    insertIndex=ep.cuts.length;
  }
  insertIndex=Math.max(0,Math.min(ep.cuts.length,insertIndex));

  ep.cuts.splice(insertIndex,0,movedCut);

  draggedCutId=null;
  cutInsertIndex=null;
  clearCutDropIndicators();

  saveData();
  renderCuts();
});

$("#cutsGrid").addEventListener("dragend",e=>{
  const card=e.target.closest(".cut-card");
  if(card){
    card.classList.remove("dragging","drag-source");
  }
  draggedCutId=null;
  cutInsertIndex=null;
  document.body.classList.remove("cut-dragging");
  clearCutDropIndicators();
});

// 드래그 포인터가 컷 영역을 벗어나면 삽입 후보를 즉시 취소한다.
$("#cutsGrid").addEventListener("dragleave",e=>{
  if(!draggedCutId)return;

  const grid=$("#cutsGrid");
  const rect=grid.getBoundingClientRect();

  if(
    e.clientX<=rect.left ||
    e.clientX>=rect.right ||
    e.clientY<=rect.top ||
    e.clientY>=rect.bottom
  ){
    cutInsertIndex=null;
    clearCutDropIndicators();
  }
});

// 컷을 드래그하는 동안 브라우저가 파일/텍스트 드롭 등
// 다른 기본 동작으로 넘어가지 않도록 전역에서 막는다.
document.addEventListener("dragover",e=>{
  if(!draggedCutId)return;

  if(!e.target.closest("#cutsGrid")){
    e.preventDefault();
    e.dataTransfer.dropEffect="none";
    cutInsertIndex=null;
    clearCutDropIndicators();
  }
});

document.addEventListener("drop",e=>{
  if(!draggedCutId)return;

  if(!e.target.closest("#cutsGrid")){
    e.preventDefault();
    e.stopPropagation();

    draggedCutId=null;
    cutInsertIndex=null;
    document.body.classList.remove("cut-dragging");
    clearCutDropIndicators();
    renderCuts();
  }
});
var cutImageDraft="";

function openCutModal(id){
  const ep=activeEpisode(), c=ep?.cuts.find(x=>x.id===id);if(!c)return;
  const idx=ep.cuts.findIndex(x=>x.id===id);
  $("#cutModalTitle").textContent=`${ep.name} · CUT ${idx+1}`;
  $("#cutId").value=c.id;$("#cutDescription").value=c.description||"";$("#cutDialogue").value=c.dialogue||"";$("#cutStatus").value=c.status||"todo";$("#cutTag").value=c.tag||"";$("#cutCharacters").value=c.characters||"";$("#cutImportant").checked=!!c.important;
  cutImageDraft=c.image||"";
  if(typeof updateCutImageUI==="function")updateCutImageUI();
  $("#cutModal").classList.add("open");
}
function closeCutModal(){
  clearTimeout(cutDraftSaveTimer);

  try{
    if($("#cutModal").classList.contains("open") && !cutCloseSkipSave){
      saveOpenCutDraft({render:true});
    }
  }catch(err){
    console.error("cut close autosave failed",err);
  }

  $("#cutModal").classList.remove("open");
  cutCloseSkipSave=false;
}

$("#closeCutX").addEventListener("click",e=>{
  e.preventDefault();
  e.stopPropagation();
  e.stopImmediatePropagation();
  closeCutModal();
});

// 컷 편집창은 오직 X 버튼으로만 닫힌다.
// 배경 클릭/드래그/포인터 이동은 전부 닫기 동작과 분리한다.
["click","mousedown","mouseup","pointerdown","pointerup"].forEach(type=>{
  $("#cutModal").addEventListener(type,e=>{
    if(e.target.id==="cutModal"){
      e.preventDefault();
      e.stopPropagation();
    }
  });
});
$("#cutModal .modal").addEventListener("click",e=>e.stopPropagation());
$("#cutModal .modal").addEventListener("mousedown",e=>e.stopPropagation());
$("#cutModal .modal").addEventListener("mouseup",e=>e.stopPropagation());
$("#cutModal .modal").addEventListener("pointerdown",e=>e.stopPropagation());
$("#cutModal .modal").addEventListener("pointerup",e=>e.stopPropagation());
let cutDraftSaveTimer=null;
let cutCloseSkipSave=false;

function saveOpenCutDraft({render=false}={}){
  const ep=activeEpisode();
  const id=$("#cutId").value;
  const c=ep?.cuts.find(x=>x.id===id);
  if(!c)return;

  c.description=$("#cutDescription").value;
  c.dialogue=$("#cutDialogue").value;
  c.status=$("#cutStatus").value;
  c.tag=$("#cutTag").value.trim();
  c.characters=$("#cutCharacters").value.trim();
  c.important=$("#cutImportant").checked;
  c.image=(typeof cutImageDraft!=="undefined" ? cutImageDraft : (c.image||""));

  saveData();
  if(render) renderCuts();
}

function scheduleCutDraftAutosave(){
  clearTimeout(cutDraftSaveTimer);
  cutDraftSaveTimer=setTimeout(()=>{
    saveOpenCutDraft({render:false});
  },180);
}

// 컷 편집창의 모든 텍스트/상태는 입력 즉시 자동저장한다.
// 따라서 X, 취소, ESC로 닫아도 이미 입력한 내용은 유지된다.
["cutDescription","cutDialogue","cutTag","cutCharacters"].forEach(id=>{
  $("#"+id).addEventListener("input",scheduleCutDraftAutosave);
});
$("#cutImportant").addEventListener("change",scheduleCutDraftAutosave);
$("#cutStatus").addEventListener("change",()=>{
  clearTimeout(cutDraftSaveTimer);
  saveOpenCutDraft({render:false});
});



function updateCutImageUI(){
  const has=!!cutImageDraft;
  $("#cutImageEmpty").style.display=has?"none":"flex";
  $("#cutImagePreviewWrap").classList.toggle("active",has);
  $("#cutImageActions").classList.toggle("active",has);
  if(has)$("#cutImagePreview").src=cutImageDraft;else $("#cutImagePreview").removeAttribute("src");
}
async function handleCutImage(file){
  try{cutImageDraft=await compressMemoImage(file);updateCutImageUI();scheduleCutDraftAutosave();}
  catch(_){alert("컷 이미지를 불러오지 못했습니다.");}
}
$("#cutImageInput").onchange=e=>{const f=e.target.files?.[0];if(f)handleCutImage(f);e.target.value=""};
$("#replaceCutImageBtn").onclick=()=>$("#cutImageInput").click();
$("#removeCutImageBtn").onclick=()=>{cutImageDraft="";updateCutImageUI();scheduleCutDraftAutosave()};
$("#cutImageDrop").addEventListener("dragover",e=>{e.preventDefault();$("#cutImageDrop").classList.add("dragover")});
$("#cutImageDrop").addEventListener("dragleave",()=>$("#cutImageDrop").classList.remove("dragover"));
$("#cutImageDrop").addEventListener("drop",e=>{e.preventDefault();$("#cutImageDrop").classList.remove("dragover");const f=[...e.dataTransfer.files].find(x=>x.type.startsWith("image/"));if(f)handleCutImage(f)});
$("#duplicateCutBtn").onclick=()=>{
  saveOpenCutDraft({render:false});
  const ep=activeEpisode(), id=$("#cutId").value, idx=ep?.cuts.findIndex(c=>c.id===id);
  if(!ep||idx<0)return;
  const clone=deepClone(ep.cuts[idx]);clone.id=crypto.randomUUID();
  ep.cuts.splice(idx+1,0,clone);saveData();renderCuts();
};

$("#cutForm").onsubmit=e=>{
  e.preventDefault();
  e.stopPropagation();
  $("#saveCutBtn")?.click();
}
$("#deleteCutBtn").onclick=()=>{
  const ep=activeEpisode(),id=$("#cutId").value;if(!ep||!id)return;
  const idx=ep.cuts.findIndex(x=>x.id===id); if(idx<0)return;
  if(!confirm("이 컷을 삭제할까요? 휴지통에서 복구할 수 있습니다."))return;
  pushTrash("cut",ep.cuts[idx],{episodeId:ep.id,index:idx});
  ep.cuts.splice(idx,1);saveData();renderCuts();$("#cutModal").classList.remove("open");
}

/* BACKUP */
const BACKUP_FORMAT="webtoon-workroom-backup";
const BACKUP_VERSION=26;

function makePortableBackup(){
  return {
    format:BACKUP_FORMAT,
    version:BACKUP_VERSION,
    exportedAt:new Date().toISOString(),
    data:JSON.parse(JSON.stringify(data)),
    preferences:{
      theme:localStorage.getItem("webtoonWorkroom.theme")||"light",
      dailyGoal:localStorage.getItem("webtoonWorkroom.dailyGoal")||"20"
    }
  };
}

function extractBackupData(parsed){
  if(!parsed || typeof parsed!=="object" || Array.isArray(parsed)){
    throw new Error("backup-root-invalid");
  }

  // v26+ 표준 포맷
  if(parsed.format===BACKUP_FORMAT && parsed.data && typeof parsed.data==="object"){
    return {payload:parsed.data,preferences:parsed.preferences||{}};
  }

  // v1~v25: 데이터 객체 자체를 그대로 내보내던 구형 포맷
  if(
    Array.isArray(parsed.schedules) ||
    Array.isArray(parsed.memos) ||
    Array.isArray(parsed.episodes) ||
    Array.isArray(parsed.projects)
  ){
    return {payload:parsed,preferences:{}};
  }

  // 일부 중간 테스트 버전에서 {data:{...}} 형태로 저장된 파일도 허용
  if(parsed.data && typeof parsed.data==="object" && !Array.isArray(parsed.data)){
    const d=parsed.data;
    if(
      Array.isArray(d.schedules) ||
      Array.isArray(d.memos) ||
      Array.isArray(d.episodes) ||
      Array.isArray(d.projects)
    ){
      return {payload:d,preferences:parsed.preferences||{}};
    }
  }

  throw new Error("backup-schema-invalid");
}

$("#exportBtn").onclick=()=>{
  try{
    const backup=makePortableBackup();
    const blob=new Blob([JSON.stringify(backup,null,2)],{type:"application/json;charset=utf-8"});
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a");
    a.href=url;
    a.download=`webtoon-workroom-backup-${todayISO()}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
  }catch(err){
    console.error("backup export failed",err);
    alert("백업 파일을 만드는 중 오류가 발생했습니다.");
  }
};

$("#importInput").onchange=async e=>{
  const f=e.target.files?.[0];
  if(!f)return;

  let parsed;
  try{
    const text=(await f.text()).replace(/^\uFEFF/,"").trim();
    if(!text)throw new Error("empty-file");
    parsed=JSON.parse(text);
  }catch(err){
    console.error("backup parse failed",err);
    alert("백업 파일을 읽을 수 없습니다. JSON 형식의 WORKROOM 백업 파일인지 확인해 주세요.");
    e.target.value="";
    return;
  }

  try{
    const {payload,preferences}=extractBackupData(parsed);

    // 기존 현재 상태를 먼저 보관해 잘못된 복원에 대비한다.
    try{
      localStorage.setItem("webtoonWorkroom.preImportBackup",JSON.stringify(data));
    }catch(_){}

    data=payload;
    normalizeImportedData();

    if(preferences.theme){
      localStorage.setItem("webtoonWorkroom.theme",preferences.theme);
      applyTheme(preferences.theme);
    }
    if(preferences.dailyGoal!==undefined){
      localStorage.setItem("webtoonWorkroom.dailyGoal",String(preferences.dailyGoal));
    }

    const saved=saveData();
    if(saved===false){
      throw new Error("storage-full");
    }

    // 기본 화면 즉시 갱신.
    renderDashboard();
    renderCalendar();
    renderMemos();
    renderEpisodes();

    // Production Suite가 추가한 자료실/타이머/검색 데이터도 재정규화/갱신.
    window.dispatchEvent(new CustomEvent("workroom:data-imported"));

    alert("백업을 정상적으로 불러왔습니다.");
  }catch(err){
    console.error("backup import failed",err);

    if(err?.message==="storage-full"){
      alert("백업 데이터가 브라우저 저장 공간보다 큽니다. 이미지가 많은 백업은 저장 공간을 확보한 뒤 다시 시도해 주세요.");
    }else{
      alert("WORKROOM 백업 구조를 확인할 수 없습니다. v1 이후 WORKROOM에서 만든 JSON 백업 파일을 선택해 주세요.");
    }
  }finally{
    e.target.value="";
  }
};

/* keyboard */
document.addEventListener("keydown",e=>{
  if(e.key!=="Escape")return;

  // 이미지 확대보기는 ESC로 항상 닫을 수 있다.
  const lightbox=$("#imageLightbox");
  if(lightbox?.classList.contains("open")){
    e.preventDefault();
    e.stopPropagation();
    closeImageLightbox();
    return;
  }

  // 메모판/컷 편집창은 기존 정책대로 X 버튼으로만 닫힌다.
  if($("#memoModal").classList.contains("open") || $("#cutModal").classList.contains("open")){
    e.preventDefault();
    e.stopPropagation();
    return;
  }

  // 캘린더 일정창 역시 바깥 클릭/ESC로 닫히지 않는다.
  if($("#scheduleModal").classList.contains("open")){
    e.preventDefault();
    e.stopPropagation();
    return;
  }

  $("#episodeModal").classList.remove("open");
  $("#projectModal").classList.remove("open");
});

renderDashboard();
renderCalendar();
renderMemos();
syncBulkSelectionUI();
renderEpisodes();
