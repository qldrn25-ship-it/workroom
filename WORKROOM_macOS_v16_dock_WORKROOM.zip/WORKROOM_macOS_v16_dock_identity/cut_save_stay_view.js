(() => {
"use strict";

const q=s=>document.querySelector(s);
const qa=s=>[...document.querySelectorAll(s)];

function keepCutsView(){
  qa(".view").forEach(v=>v.classList.remove("active"));
  q("#cutsView")?.classList.add("active");
  qa(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.view==="cuts"));
  if(q("#pageTitle"))q("#pageTitle").textContent="컷별 관리";
}

function currentCut(){
  try{
    const ep=typeof activeEpisode==="function"?activeEpisode():null;
    const id=q("#cutId")?.value||"";
    return ep?.cuts?.find(c=>String(c.id)===String(id))||null;
  }catch(_){
    return null;
  }
}

function saveCurrentCutFromUI(){
  const cut=currentCut();
  if(!cut)throw new Error("저장할 컷을 찾을 수 없습니다.");

  /*
   First use the existing saver if it is available.
   Then explicitly save the scene field, because it is managed by a later module.
  */
  if(typeof saveOpenCutDraft==="function"){
    try{
      saveOpenCutDraft({render:false});
    }catch(err){
      console.warn("legacy cut saver failed; using direct save",err);
      const value=(sel,fallback="")=>q(sel)?.value??fallback;
      cut.description=value("#cutDescription");
      cut.dialogue=value("#cutDialogue");
      cut.status=value("#cutStatus","todo");
      cut.tag=value("#cutTag").trim();
      cut.characters=value("#cutCharacters").trim();
      cut.note=value("#cutNote");
      cut.important=!!q("#cutImportant")?.checked;
    }
  }else{
    const value=(sel,fallback="")=>q(sel)?.value??fallback;
    cut.description=value("#cutDescription");
    cut.dialogue=value("#cutDialogue");
    cut.status=value("#cutStatus","todo");
    cut.tag=value("#cutTag").trim();
    cut.characters=value("#cutCharacters").trim();
    cut.note=value("#cutNote");
    cut.important=!!q("#cutImportant")?.checked;
  }

  if(q("#cutScene")){
    cut.sceneId=q("#cutScene").value||"";
  }

  try{
    if(typeof saveCutSuiteFields==="function")saveCutSuiteFields();
  }catch(err){
    console.warn("optional suite fields save skipped",err);
  }

  try{
    if(typeof saveAdvancedCutFields==="function")saveAdvancedCutFields();
  }catch(err){
    console.warn("optional advanced fields save skipped",err);
  }

  if(typeof saveData==="function")saveData();
}

q("#saveCutBtn")?.addEventListener("click",e=>{
  e.preventDefault();
  e.stopPropagation();
  e.stopImmediatePropagation();

  const btn=q("#saveCutBtn");
  const oldText=btn?.textContent||"저장";

  try{
    if(btn){
      btn.disabled=true;
      btn.textContent="저장 중…";
    }

    saveCurrentCutFromUI();

    /*
     Close directly. Do not call closeCutModal(), because older close handlers
     may trigger another render/save chain.
    */
    try{
      if(typeof cutCloseSkipSave!=="undefined")cutCloseSkipSave=true;
    }catch(_){}

    q("#cutModal")?.classList.remove("open");

    try{
      if(typeof renderCuts==="function")renderCuts();
    }catch(err){
      console.error("renderCuts after cut save",err);
    }

    keepCutsView();

    if(q("#saveText"))q("#saveText").textContent="저장됨";

    if(btn)btn.textContent="저장 완료 ✓";

    setTimeout(()=>{
      keepCutsView();
      if(btn){
        btn.disabled=false;
        btn.textContent=oldText;
      }
    },500);
  }catch(err){
    console.error("cut save button failed",err);
    alert("컷 저장 중 오류가 발생했습니다.\n"+(err?.message||String(err)));

    if(btn){
      btn.disabled=false;
      btn.textContent=oldText;
    }
  }finally{
    try{
      if(typeof cutCloseSkipSave!=="undefined")cutCloseSkipSave=false;
    }catch(_){}
  }
},true);

/* Enter-based accidental form submission uses the same button path. */
q("#cutForm")?.addEventListener("submit",e=>{
  e.preventDefault();
  e.stopPropagation();
},true);

console.info("WORKROOM v98 explicit cut save button loaded");
})();