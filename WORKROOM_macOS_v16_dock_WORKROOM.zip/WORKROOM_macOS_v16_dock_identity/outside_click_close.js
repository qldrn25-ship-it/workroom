(() => {
"use strict";

const q=s=>document.querySelector(s);
const qa=s=>[...document.querySelectorAll(s)];

/*
 Close helpers for editors that have their own autosave/cleanup routines.
 We prefer those routines when available, otherwise we simply remove .open.
*/
function closeBackdrop(backdrop){
  if(!backdrop)return;

  const id=backdrop.id||"";

  try{
    if(id==="cutModal" && typeof closeCutModal==="function"){
      closeCutModal();
      return;
    }
  }catch(err){
    console.warn("closeCutModal fallback",err);
  }

  try{
    if(id==="memoModal" && typeof closeMemoModal==="function"){
      closeMemoModal();
      return;
    }
  }catch(err){
    console.warn("closeMemoModal fallback",err);
  }

  try{
    if(id==="resourceModal" && typeof closeResourceModal==="function"){
      closeResourceModal();
      return;
    }
  }catch(err){
    console.warn("closeResourceModal fallback",err);
  }

  /* Dedicated modal cleanup for a few workflow-specific windows. */
  if(id==="resourceMoveModal"){
    try{
      if(typeof closeMoveModal==="function"){
        closeMoveModal();
        return;
      }
    }catch(_){}
  }

  backdrop.classList.remove("open");
}

/*
 Use pointerup instead of pointerdown:
 - dragging text inside a modal and releasing outside should NOT close it.
 - only a click that begins and ends on the backdrop itself closes the modal.
*/
let pressedBackdrop=null;

document.addEventListener("pointerdown",e=>{
  const backdrop=e.target.closest?.(".modal-backdrop");
  pressedBackdrop=(backdrop && e.target===backdrop)?backdrop:null;
},true);

document.addEventListener("pointerup",e=>{
  const backdrop=e.target.closest?.(".modal-backdrop");

  if(
    pressedBackdrop &&
    backdrop===pressedBackdrop &&
    e.target===backdrop
  ){
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    closeBackdrop(backdrop);
  }

  pressedBackdrop=null;
},true);

document.addEventListener("pointercancel",()=>{
  pressedBackdrop=null;
},true);

/*
 Image/lightbox overlays may not use .modal-backdrop.
 If their own close button exists, clicking the bare overlay closes them too.
*/
const lightboxSelectors=[
  "#imageLightbox",
  ".image-lightbox",
  ".lightbox-backdrop",
  ".image-preview-lightbox"
];

document.addEventListener("click",e=>{
  for(const sel of lightboxSelectors){
    const overlay=e.target.closest?.(sel);
    if(!overlay || e.target!==overlay)continue;

    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();

    const closeBtn=
      overlay.querySelector("[data-close-lightbox]") ||
      overlay.querySelector(".lightbox-close") ||
      overlay.querySelector(".image-lightbox-close") ||
      overlay.querySelector(".round-btn");

    if(closeBtn){
      closeBtn.click();
    }else{
      overlay.classList.remove("open","active","show");
    }
    return;
  }
},true);

/*
 Older versions explicitly prevented backdrop clicks for cut/memo modals.
 Capture handlers above run first, but also make the backdrop itself clickable
 and modal inner panels non-closing.
*/
qa(".modal-backdrop").forEach(backdrop=>{
  backdrop.style.pointerEvents="auto";
  const inner=backdrop.querySelector(".modal");
  if(inner)inner.style.pointerEvents="auto";
});

console.info("WORKROOM v100 outside-click modal close loaded");
})();