(() => {
"use strict";
const $a=s=>document.querySelector(s), $$a=s=>[...document.querySelectorAll(s)];
const ADV_KEY="webtoonWorkroom.advanced.v29";
let adv={showArchived:false,recent:[],favorites:[],reviewIndex:0,lastCutId:""};
try{adv={...adv,...JSON.parse(localStorage.getItem(ADV_KEY)||"{}")}}catch(_){}
function persistAdv(){localStorage.setItem(ADV_KEY,JSON.stringify(adv))}
function ae(v=""){return String(v).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

function ensureAdvancedData(){
  if(!Array.isArray(data.scenes))data.scenes=[];
  if(!data.projectSettings)data.projectSettings={};
  data.projects.forEach(p=>{
    if(p.archived===undefined)p.archived=false;
    if(p.deliveryStatus===undefined)p.deliveryStatus="";
    if(!data.projectSettings[p.id])data.projectSettings[p.id]={checklist:["콘티","러프","선화","밑색","명암","말풍선","효과","검수"]};
    if(!Array.isArray(data.projectSettings[p.id].checklist))data.projectSettings[p.id].checklist=["콘티","러프","선화","밑색","명암","말풍선","효과","검수"];
  });
  data.episodes.forEach(ep=>{
    if(ep.deliveryStatus===undefined)ep.deliveryStatus="";
    (ep.cuts||[]).forEach(c=>{
      if(c.sceneId===undefined)c.sceneId="";
      if(c.assignee===undefined)c.assignee="";
      if(c.colorLabel===undefined)c.colorLabel="";
      if(c.feedbackStatus===undefined)c.feedbackStatus="";
      if(c.feedback===undefined)c.feedback="";
      if(!c.checklist||typeof c.checklist!=="object")c.checklist={};
      if(!c.stageImages||typeof c.stageImages!=="object")c.stageImages={storyboard:"",rough:"",line:"",final:""};
      ["storyboard","rough","line","final"].forEach(k=>{if(c.stageImages[k]===undefined)c.stageImages[k]=""});
      if(c.reviewed===undefined)c.reviewed=false;
    })
  });
}
ensureAdvancedData();
try{localStorage.setItem(STORAGE_KEY,JSON.stringify(data))}catch(_){}

/* recent + favorites */
function addRecent(kind,id,label,projectId="",episodeId=""){
  adv.recent=adv.recent.filter(x=>!(x.kind===kind&&x.id===id));
  adv.recent.unshift({kind,id,label,projectId,episodeId,at:Date.now()});
  adv.recent=adv.recent.slice(0,8);persistAdv();renderShortcuts();
}
function toggleFavorite(kind,id,label,projectId="",episodeId=""){
  const i=adv.favorites.findIndex(x=>x.kind===kind&&x.id===id);
  if(i>=0)adv.favorites.splice(i,1);else adv.favorites.unshift({kind,id,label,projectId,episodeId});
  persistAdv();renderShortcuts();syncFavoriteButtons();
}
function gotoShortcut(x){
  if(x.kind==="project"){data.activeProjectId=x.id;data.activeEpisodeId=data.episodes.find(e=>e.projectId===x.id)?.id||null;saveData();switchView("cuts")}
  if(x.kind==="episode"){const ep=data.episodes.find(e=>e.id===x.id);if(ep){data.activeProjectId=ep.projectId;data.activeEpisodeId=ep.id;saveData();switchView("cuts")}}
  if(x.kind==="cut"){const ep=data.episodes.find(e=>e.id===x.episodeId);if(ep){data.activeProjectId=ep.projectId;data.activeEpisodeId=ep.id;saveData();switchView("cuts");setTimeout(()=>openCutModal(x.id),40)}}
  if(x.kind==="memo"){switchView("memo");setTimeout(()=>openMemoModal(x.id),40)}
}
function renderShortcuts(){
  const r=$a("#recentWorkList"),f=$a("#favoriteList");if(!r||!f)return;
  r.innerHTML=adv.recent.length?"":"<div class='soft-help'>최근 작업 없음</div>";
  adv.recent.forEach(x=>{const el=document.createElement("div");el.className="shortcut-item";el.innerHTML=`<span>${ae(x.label)}</span><small>${x.kind}</small>`;el.onclick=()=>gotoShortcut(x);r.appendChild(el)});
  f.innerHTML=adv.favorites.length?"":"<div class='soft-help'>즐겨찾기 없음</div>";
  adv.favorites.forEach(x=>{const el=document.createElement("div");el.className="shortcut-item";el.innerHTML=`<span>${ae(x.label)}</span><button type="button" class="mini-remove">×</button>`;el.onclick=e=>{if(e.target.tagName==="BUTTON"){toggleFavorite(x.kind,x.id,x.label,x.projectId,x.episodeId);return}gotoShortcut(x)};f.appendChild(el)});
}
function syncFavoriteButtons(){
  const p=activeProject();
  if($a("#favoriteProjectBtn"))$a("#favoriteProjectBtn").textContent=adv.favorites.some(x=>x.kind==="project"&&x.id===p?.id)?"★ 즐겨찾기":"☆ 즐겨찾기";
}
$a("#favoriteProjectBtn")?.addEventListener("click",()=>{const p=activeProject();if(p)toggleFavorite("project",p.id,p.name,p.id,"")});
renderShortcuts();syncFavoriteButtons();

/* archive */
function applyArchiveFilterToProjectSelect(){
  const sel=$a("#projectSelect");if(!sel)return;
  [...sel.options].forEach(o=>{
    const p=data.projects.find(x=>x.id===o.value);
    o.hidden=!!p?.archived&&!adv.showArchived;
    o.textContent=p?.archived?`${p.name} · 보관`:p?.name||o.textContent;
  });
}
const baseRenderProjects=renderProjects;
renderProjects=function(){baseRenderProjects();applyArchiveFilterToProjectSelect();syncFavoriteButtons()}
$a("#archiveProjectBtn")?.addEventListener("click",()=>{
  const p=activeProject();if(!p)return;
  p.archived=!p.archived;saveData();renderProjects();renderDashboard();$a("#archiveProjectBtn").textContent=p.archived?"보관 해제":"보관";
});
$a("#toggleArchiveBtn")?.addEventListener("click",()=>{
  adv.showArchived=!adv.showArchived;persistAdv();renderProjects();renderDashboard();$a("#toggleArchiveBtn").textContent=adv.showArchived?"보관 작품 숨기기":"보관 작품 보기";
});

/* scenes */
function currentScenes(){
  const ep=activeEpisode();
  if(!Array.isArray(data.scenes))data.scenes=[];
  return ep?data.scenes.filter(s=>s.episodeId===ep.id):[];
}
function populateSceneUI(selectedSceneId){
  const ep=activeEpisode();
  if(!Array.isArray(data.scenes))data.scenes=[];
  const scenes=ep
    ? data.scenes.filter(s=>String(s.episodeId)===String(ep.id))
    : [];

  const filter=$a("#sceneFilterSelect");
  if(filter){
    const prev=filter.value||"all";
    filter.innerHTML='<option value="all">전체 장면</option>'+
      scenes.map(s=>`<option value="${ae(s.id)}">${ae(s.name||"장면")}</option>`).join("");
    filter.value=[...filter.options].some(o=>String(o.value)===String(prev))?prev:"all";
  }

  const cutScene=$a("#cutScene");
  if(cutScene){
    const desired=selectedSceneId!==undefined
      ? String(selectedSceneId||"")
      : String(cutScene.value||"");

    cutScene.disabled=false;
    cutScene.style.pointerEvents="auto";
    cutScene.innerHTML='<option value="">장면 없음</option>'+
      scenes.map(s=>`<option value="${ae(s.id)}">${ae(s.name||"장면")}</option>`).join("");

    if([...cutScene.options].some(o=>String(o.value)===desired)){
      cutScene.value=desired;
    }else{
      cutScene.value="";
    }
  }
}
$a("#newSceneBtn")?.addEventListener("click",()=>{
  const ep=activeEpisode();
  if(!ep){alert("먼저 작품과 화수를 선택해주세요.");return;}
  if(!Array.isArray(data.scenes))data.scenes=[];
  $a("#sceneNameInput").value="";
  $a("#sceneBackgroundInput").value="";
  $a("#sceneNoteInput").value="";
  $a("#sceneModal").classList.add("open");
  setTimeout(()=>$a("#sceneNameInput")?.focus(),0);
});
$a("#closeSceneX")?.addEventListener("click",()=> $a("#sceneModal").classList.remove("open"));
$a("#sceneForm")?.addEventListener("submit",e=>{
  e.preventDefault();
  const ep=activeEpisode();if(!ep)return;
  if(!Array.isArray(data.scenes))data.scenes=[];
  const name=$a("#sceneNameInput").value.trim();
  if(!name){alert("장면 이름을 입력해주세요.");return;}
  data.scenes.push({
    id:crypto.randomUUID?.()||String(Date.now()),
    episodeId:ep.id,
    name,
    background:$a("#sceneBackgroundInput").value.trim(),
    note:$a("#sceneNoteInput").value.trim()
  });
  saveData();
  populateSceneUI();
  applyAdvancedCardDecorations();
  $a("#sceneModal").classList.remove("open");
});

/* checklist settings */
function projectChecklist(){const p=activeProject();return p?(data.projectSettings[p.id]?.checklist||[]):[]}
function renderChecklistSettings(){
  const box=$a("#checklistSettingsList");if(!box)return;box.innerHTML="";
  projectChecklist().forEach((name,i)=>{
    const row=document.createElement("div");row.className="checklist-setting-row";
    row.innerHTML=`<input value="${ae(name)}"><button class="glass-button danger" type="button">삭제</button>`;
    row.querySelector("input").onchange=e=>{data.projectSettings[activeProject().id].checklist[i]=e.target.value.trim()||name;saveData();renderCutChecklist()};
    row.querySelector("button").onclick=()=>{data.projectSettings[activeProject().id].checklist.splice(i,1);saveData();renderChecklistSettings();renderCutChecklist()};
    box.appendChild(row)
  })
}
$a("#manageChecklistBtn")?.addEventListener("click",()=>{renderChecklistSettings();$a("#checklistModal").classList.add("open")});
$a("#closeChecklistX")?.addEventListener("click",()=> $a("#checklistModal").classList.remove("open"));
$a("#addChecklistItemBtn")?.addEventListener("click",()=>{
  const v=$a("#newChecklistItemInput").value.trim();if(!v||!activeProject())return;
  data.projectSettings[activeProject().id].checklist.push(v);$a("#newChecklistItemInput").value="";saveData();renderChecklistSettings();renderCutChecklist()
});
function renderCutChecklist(){
  const ep=activeEpisode(),c=ep?.cuts.find(x=>x.id===$a("#cutId")?.value),box=$a("#cutChecklistList");if(!c||!box)return;
  box.innerHTML="";
  projectChecklist().forEach(name=>{
    const lab=document.createElement("label");lab.className="cut-check-item";lab.innerHTML=`<input type="checkbox" ${c.checklist[name]?"checked":""}><span>${ae(name)}</span>`;
    lab.querySelector("input").onchange=e=>{c.checklist[name]=e.target.checked;saveData()};
    box.appendChild(lab)
  })
}

/* stage images */
const stageLabels={storyboard:"콘티",rough:"러프",line:"선화",final:"완성"};
async function imageToCompressedData(file){
  try{return await compressMemoImage(file)}catch(_){return ""}
}


/* cut modal advanced fields */
const baseOpenCutModalAdv=openCutModal;
openCutModal=function(id){
  /* Always let the original editor open first. */
  baseOpenCutModalAdv(id);

  const ep=activeEpisode();
  const c=ep?.cuts.find(x=>String(x.id)===String(id));
  if(!c)return;

  adv.lastCutId=id;
  persistAdv();
  addRecent(
    "cut",
    id,
    `${activeProject()?.name||""} ${ep.name} · CUT ${ep.cuts.findIndex(x=>String(x.id)===String(id))+1}`,
    ep.projectId,
    ep.id
  );

  /* Scene list must be populated after cutId/current episode are ready. */
  populateSceneUI(c.sceneId||"");

  /* Only touch optional fields if they still exist in this build. */
const feedbackStatus=$a("#cutFeedbackStatus");
  if(feedbackStatus)feedbackStatus.value=c.feedbackStatus||"";

  try{renderCutChecklist()}catch(_){}
};

function saveAdvancedCutFields(){
  const ep=activeEpisode();
  const cutId=$a("#cutId")?.value;
  const c=ep?.cuts.find(x=>String(x.id)===String(cutId));
  if(!c)return;

  const scene=$a("#cutScene");
  if(scene)c.sceneId=scene.value||"";
const feedbackStatus=$a("#cutFeedbackStatus");
  if(feedbackStatus)c.feedbackStatus=feedbackStatus.value||"";

  saveData();
}

["cutScene","cutFeedbackStatus"].forEach(id=>{
  $a("#"+id)?.addEventListener("change",()=>{
    clearTimeout(saveAdvancedCutFields._t);
    saveAdvancedCutFields._t=setTimeout(saveAdvancedCutFields,120);
  });
});

/* filters + board decoration */
function populateAdvancedFilters(){ populateSceneUI(); }
function applyAdvancedCardDecorations(){
  const ep=activeEpisode();if(!ep)return;
  $$a("#cutsGrid .cut-card").forEach(card=>{
    const c=ep.cuts.find(x=>x.id===card.dataset.id);if(!c)return;
    ["red","yellow","blue","purple","green"].forEach(x=>card.classList.toggle("label-"+x,c.colorLabel===x));
    card.classList.toggle("feedback-needs",c.feedbackStatus==="needs");
    const scene=$a("#sceneFilterSelect")?.value||"all";
    const fb=$a("#feedbackFilterSelect")?.value||"all";
    const feedbackState=c.feedbackStatus||(c.reviewNeedsFix?"needs":"");
    const sceneMatch=scene==="all"||String(c.sceneId||"")===String(scene);
    const feedbackMatch=fb==="all"||feedbackState===fb;
    card.style.display=(sceneMatch&&feedbackMatch)?"":"none";
  })
}
const baseRenderCutsAdv=renderCuts;
renderCuts=function(){baseRenderCutsAdv();populateAdvancedFilters();applyAdvancedCardDecorations();renderDialogue();renderCharacterDialogue();renderStats()}
["sceneFilterSelect","feedbackFilterSelect"].forEach(id=>{
  $a("#"+id)?.addEventListener("change",()=>{
    applyAdvancedCardDecorations();
  });
});

/* tabs */
function switchAdvTab(name){
  $$a(".adv-tab").forEach(b=>b.classList.toggle("active",b.dataset.advtab===name));
  $$a(".advanced-pane").forEach(p=>p.classList.remove("active"));
  ({board:"#advancedBoardPane",dialogue:"#advancedDialoguePane",characters:"#advancedCharactersPane",stats:"#advancedStatsPane"}[name]&&$a(({board:"#advancedBoardPane",dialogue:"#advancedDialoguePane",characters:"#advancedCharactersPane",stats:"#advancedStatsPane"})[name])?.classList.add("active"));
  if(name==="dialogue")renderDialogue();if(name==="characters")renderCharacterDialogue();if(name==="stats")renderStats()
}
$$a(".adv-tab").forEach(b=>b.addEventListener("click",()=>switchAdvTab(b.dataset.advtab)));

/* dialogue modes */
function renderDialogue(){
  const box=$a("#dialogueView"),ep=activeEpisode();if(!box||!ep)return;box.innerHTML="";
  ep.cuts.forEach((c,i)=>{const row=document.createElement("div");row.className="dialogue-row";row.innerHTML=`<div class="dialogue-row-head"><strong>CUT ${i+1}</strong><small>${ae(c.characters||"")}</small></div><p>${ae(c.dialogue||"(대사 없음)")}</p>`;row.onclick=()=>openCutModal(c.id);box.appendChild(row)})
}
function renderCharacterDialogue(){
  const sel=$a("#characterDialogueSelect"),box=$a("#characterDialogueView"),ep=activeEpisode();if(!sel||!box||!ep)return;
  const chars=[...new Set(ep.cuts.flatMap(c=>(c.characterList||String(c.characters||"").split(",")).map(x=>String(x).trim()).filter(Boolean)))];
  const old=sel.value;sel.innerHTML=chars.map(x=>`<option value="${ae(x)}">${ae(x)}</option>`).join("");if(chars.includes(old))sel.value=old;
  const target=sel.value||chars[0]||"";box.innerHTML="";
  ep.cuts.forEach((c,i)=>{const names=c.characterList||String(c.characters||"").split(",").map(x=>x.trim());if(!names.includes(target))return;const row=document.createElement("div");row.className="dialogue-row";row.innerHTML=`<div class="dialogue-row-head"><strong>CUT ${i+1}</strong><small>${ae(target)}</small></div><p>${ae(c.dialogue||"(대사 없음)")}</p>`;row.onclick=()=>openCutModal(c.id);box.appendChild(row)})
}
$a("#characterDialogueSelect")?.addEventListener("change",renderCharacterDialogue);

/* stats */
function renderStats(){
  const box=$a("#episodeStatsGrid"),ep=activeEpisode();if(!box||!ep)return;const cuts=ep.cuts||[];
  const charCounts={};cuts.forEach(c=>(c.characterList||String(c.characters||"").split(",")).map(x=>String(x).trim()).filter(Boolean).forEach(n=>charCounts[n]=(charCounts[n]||0)+1));
  const bgCounts={};cuts.forEach(c=>{if(c.background)bgCounts[c.background]=(bgCounts[c.background]||0)+1});
  const avg=cuts.length?Math.round(cuts.reduce((s,c)=>s+Number(c.estimatedMinutes||0),0)/cuts.length):0;
  const cards=[
    ["총 컷 수",cuts.length],["대사 있는 컷",cuts.filter(c=>String(c.dialogue||"").trim()).length],["무대사 컷",cuts.filter(c=>!String(c.dialogue||"").trim()).length],
    ["수정 필요",cuts.filter(c=>c.feedbackStatus==="needs").length],["평균 예상 시간",avg+"분"],["장면 수",currentScenes().length],
    ["가장 많이 등장",Object.entries(charCounts).sort((a,b)=>b[1]-a[1])[0]?.join(" · ")||"-"],["가장 많이 쓰는 배경",Object.entries(bgCounts).sort((a,b)=>b[1]-a[1])[0]?.join(" · ")||"-"]
  ];
  box.innerHTML=cards.map(([k,v])=>`<div class="stat-card"><span>${ae(k)}</span><strong>${ae(v)}</strong></div>`).join("")
}

/* review mode */
let reviewIndex=0;
function openReview(){
  const ep=activeEpisode();if(!ep||!ep.cuts.length)return;reviewIndex=Math.min(reviewIndex,ep.cuts.length-1);$a("#reviewModal").classList.add("open");renderReview()
}
function renderReview(){
  const ep=activeEpisode(),c=ep?.cuts[reviewIndex],box=$a("#reviewContent");if(!c||!box)return;
  const img=c.stageImages?.final||c.image||c.stageImages?.line||c.stageImages?.rough||c.stageImages?.storyboard||"";
  $a("#reviewTitle").textContent=`${ep.name} · CUT ${reviewIndex+1} / ${ep.cuts.length}`;
  box.innerHTML=`${img?`<img class="review-cut-image" src="${img}">`:"<div class='empty-state'>이미지 없음</div>"}<div class="review-cut-meta"><span>${ae(c.status||"")}</span>${c.feedbackStatus==="needs"?"<span>⚑ 수정 필요</span>":""}</div><h4>${ae(c.description||"컷 설명 없음")}</h4><p>${ae(c.dialogue||"대사 없음")}</p><p class="soft-help">${ae(c.feedback||"")}</p>`;
  $a("#reviewPrevBtn").disabled=reviewIndex===0;$a("#reviewNextBtn").disabled=reviewIndex===ep.cuts.length-1
}
$a("#reviewModeBtn")?.addEventListener("click",openReview);$a("#closeReviewX")?.addEventListener("click",()=> $a("#reviewModal").classList.remove("open"));
$a("#reviewPrevBtn")?.addEventListener("click",()=>{reviewIndex=Math.max(0,reviewIndex-1);renderReview()});
$a("#reviewNextBtn")?.addEventListener("click",()=>{const ep=activeEpisode();reviewIndex=Math.min((ep?.cuts.length||1)-1,reviewIndex+1);renderReview()});
$a("#reviewFlagBtn")?.addEventListener("click",()=>{const c=activeEpisode()?.cuts[reviewIndex];if(c){c.feedbackStatus="needs";c.reviewed=true;saveData();renderReview();renderCuts()}});
$a("#reviewResolveBtn")?.addEventListener("click",()=>{const c=activeEpisode()?.cuts[reviewIndex];if(c){c.feedbackStatus=c.feedbackStatus==="needs"?"resolved":c.feedbackStatus;c.reviewed=true;saveData();renderReview();renderCuts()}});

/* quick memo ctrl+m */
function openQuickMemo(){ $a("#quickMemoText").value="";$a("#quickMemoModal").classList.add("open");requestAnimationFrame(()=>$a("#quickMemoText").focus())}
$a("#quickMemoBtn")?.addEventListener("click",openQuickMemo);$a("#closeQuickMemoX")?.addEventListener("click",()=> $a("#quickMemoModal").classList.remove("open"));
window.addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="m"){e.preventDefault();openQuickMemo()}},true);
$a("#quickMemoForm")?.addEventListener("submit",e=>{
  e.preventDefault();const text=$a("#quickMemoText").value.trim(),scope=$a("#quickMemoScope").value;if(!text)return;
  const p=activeProject(),ep=activeEpisode(),c=ep?.cuts.find(x=>x.id===adv.lastCutId);
  if(scope==="cut"&&c){c.note=(c.note?c.note+"\n":"")+text;saveData()}
  else if(scope==="episode"&&ep){ep.memo=(ep.memo?ep.memo+"\n":"")+text;saveData()}
  else data.memos.push({id:crypto.randomUUID(),type:"아이디어",tag:scope==="project"?p?.name||"":scope==="episode"?ep?.name||"":"빠른메모",title:text.slice(0,30)||"빠른 메모",content:text,pinned:false,image:"",updated:Date.now()});
  saveData();renderMemos();$a("#quickMemoModal").classList.remove("open")
});

/* data integrity */
let dataIssues=[];
function scanData(){
  dataIssues=[];const ids=new Set(),dups=[];
  function checkId(obj,label){if(!obj.id){dataIssues.push({type:"missing-id",label,obj})}else if(ids.has(obj.id)){dups.push(obj.id);dataIssues.push({type:"duplicate-id",label,obj})}else ids.add(obj.id)}
  data.projects.forEach(p=>checkId(p,"작품"));data.episodes.forEach(ep=>checkId(ep,"회차"));data.memos.forEach(m=>checkId(m,"메모"));data.resources?.forEach(r=>checkId(r,"자료"));
  data.episodes.forEach(ep=>{
    if(!data.projects.some(p=>p.id===ep.projectId))dataIssues.push({type:"orphan-episode",label:`회차 ${ep.name}`,obj:ep});
    (ep.cuts||[]).forEach((c,i)=>{checkId(c,`컷 ${i+1}`);if(c.sceneId&&!data.scenes.some(s=>s.id===c.sceneId))dataIssues.push({type:"bad-scene",label:`${ep.name} CUT ${i+1}`,obj:c})})
  });
  (data.scenes||[]).forEach(s=>{checkId(s,"장면");if(!data.episodes.some(ep=>ep.id===s.episodeId))dataIssues.push({type:"orphan-scene",label:s.name,obj:s})});
  return dataIssues
}
function renderDataCheck(){
  const box=$a("#dataCheckList"),sum=$a("#dataCheckSummary");scanData();sum.textContent=dataIssues.length?`문제 ${dataIssues.length}건 발견`:"문제가 발견되지 않았습니다.";
  box.innerHTML=dataIssues.length?dataIssues.map(x=>`<div class="data-issue"><strong>${ae(x.type)}</strong> · ${ae(x.label)}</div>`).join(""):"<div class='empty-state'>데이터 상태가 정상입니다.</div>"
}
$a("#runDataCheckBtn")?.addEventListener("click",()=>{renderDataCheck();$a("#dataCheckModal").classList.add("open")});$a("#closeDataCheckX")?.addEventListener("click",()=> $a("#dataCheckModal").classList.remove("open"));
$a("#repairDataBtn")?.addEventListener("click",()=>{
  scanData();const seen=new Set();
  function fix(obj){if(!obj.id||seen.has(obj.id))obj.id=crypto.randomUUID();seen.add(obj.id)}
  data.projects.forEach(fix);data.episodes.forEach(fix);data.memos.forEach(fix);data.resources?.forEach(fix);data.scenes?.forEach(fix);data.episodes.forEach(ep=>(ep.cuts||[]).forEach(fix));
  data.episodes.forEach(ep=>{if(!data.projects.some(p=>p.id===ep.projectId))ep.projectId=data.projects[0]?.id||"";(ep.cuts||[]).forEach(c=>{if(c.sceneId&&!data.scenes.some(s=>s.id===c.sceneId))c.sceneId=""})});
  data.scenes=data.scenes.filter(s=>data.episodes.some(ep=>ep.id===s.episodeId));
  saveData();renderDataCheck();renderEpisodes()
});

/* project/episode recent and labels */
$a("#projectSelect")?.addEventListener("change",()=>{const p=activeProject();if(p)addRecent("project",p.id,p.name,p.id,"");setTimeout(()=>{populateSceneUI();renderStats()},0)});
$a("#episodeSelect")?.addEventListener("change",()=>{const ep=activeEpisode(),p=activeProject();if(ep)addRecent("episode",ep.id,`${p?.name||""} ${ep.name}`,p?.id||"",ep.id);setTimeout(()=>{populateSceneUI();renderStats()},0)});

/* dashboard override: hide archived projects unless requested */
const baseRenderDashboardAdv=renderDashboard;
renderDashboard=function(){
  baseRenderDashboardAdv();renderShortcuts();
  if(!adv.showArchived){
    $$a("#dashboardGrid .project-card").forEach(card=>{
      const title=card.querySelector("h3")?.textContent||"";const p=data.projects.find(x=>x.name===title);if(p?.archived)card.style.display="none"
    })
  }
}
renderDashboard();

/* initialize */
populateSceneUI();renderDialogue();renderCharacterDialogue();renderStats();renderShortcuts();


})();