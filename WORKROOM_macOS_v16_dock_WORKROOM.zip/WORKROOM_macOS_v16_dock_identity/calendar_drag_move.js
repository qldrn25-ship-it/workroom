(() => {
"use strict";

const q=s=>document.querySelector(s);
const qa=s=>[...document.querySelectorAll(s)];

let activeDrag=null;
let ghost=null;
let suppressClickUntil=0;

function parseISO(value){
  const [y,m,d]=String(value||"").split("-").map(Number);
  return new Date(y,m-1,d);
}
function toISO(date){
  const d=new Date(date);
  const off=d.getTimezoneOffset();
  return new Date(d.getTime()-off*60000).toISOString().slice(0,10);
}
function addDays(value,n){
  const d=parseISO(value);
  d.setDate(d.getDate()+n);
  return toISO(d);
}
function diffDays(a,b){
  return Math.round((parseISO(b)-parseISO(a))/86400000);
}
function schedules(){
  return (typeof data!=="undefined"&&Array.isArray(data.schedules))?data.schedules:[];
}
function byId(id){
  return schedules().find(s=>String(s.id)===String(id))||null;
}

function calendarDays(){
  return qa("#calendarGrid > .day").filter(day=>day.dataset.date);
}

/* Geometry lookup works even when an overlay/range bar is covering the day. */
function dateAtPoint(x,y){
  const days=calendarDays();
  for(const day of days){
    const r=day.getBoundingClientRect();
    if(x>=r.left && x<=r.right && y>=r.top && y<=r.bottom){
      return day.dataset.date||null;
    }
  }
  return null;
}

function dayAtPoint(x,y){
  const date=dateAtPoint(x,y);
  return date?calendarDays().find(d=>d.dataset.date===date)||null:null;
}

function clearHighlight(){
  qa("#calendarGrid > .day.calendar-drag-over")
    .forEach(day=>day.classList.remove("calendar-drag-over"));
}

function highlightAt(x,y){
  clearHighlight();
  dayAtPoint(x,y)?.classList.add("calendar-drag-over");
}

function makeGhost(schedule,x,y){
  ghost=document.createElement("div");
  ghost.className="calendar-drag-ghost";
  ghost.textContent=`${schedule.stage||"일정"} · ${schedule.title||""}`;
  document.body.appendChild(ghost);
  moveGhost(x,y);
}
function moveGhost(x,y){
  if(!ghost)return;
  ghost.style.left=`${x+16}px`;
  ghost.style.top=`${y+16}px`;
}

function saveAndRender(){
  try{
    if(typeof saveData==="function")saveData();
  }catch(err){
    console.error("calendar drag save",err);
  }
  try{
    if(typeof renderCalendar==="function")renderCalendar();
  }catch(err){
    console.error("calendar drag render",err);
  }
}

function finishDrag(){
  document.body.classList.remove("calendar-is-dragging");
  document.body.style.userSelect="";
  clearHighlight();
  ghost?.remove();
  ghost=null;
  activeDrag=null;
}

function sourceDateFromPoint(x,y,fallback){
  return dateAtPoint(x,y)||fallback;
}

function beginDrag(e,schedule,sourceDate){
  if(e.button!==0)return;

  const startX=e.clientX;
  const startY=e.clientY;
  let started=false;

  function onMove(ev){
    if(!started){
      const distance=Math.hypot(ev.clientX-startX,ev.clientY-startY);
      if(distance<7)return;

      started=true;
      activeDrag={
        schedule,
        sourceDate:sourceDate||schedule.date
      };

      document.body.classList.add("calendar-is-dragging");
      document.body.style.userSelect="none";
      makeGhost(schedule,ev.clientX,ev.clientY);
    }

    ev.preventDefault();
    moveGhost(ev.clientX,ev.clientY);
    highlightAt(ev.clientX,ev.clientY);
  }

  function onUp(ev){
    window.removeEventListener("pointermove",onMove,true);
    window.removeEventListener("pointerup",onUp,true);
    window.removeEventListener("pointercancel",onCancel,true);

    if(!started){
      finishDrag();
      return;
    }

    const targetDate=dateAtPoint(ev.clientX,ev.clientY);

    if(targetDate){
      const s=schedule;
      const oldStart=s.date;
      const oldEnd=s.endDate||oldStart;

      /*
       Preserve the grabbed point:
       - grab first day -> dropped day becomes new first day
       - grab middle of a range -> entire range shifts by same delta
      */
      const grabbedDate=activeDrag?.sourceDate||oldStart;
      const shift=diffDays(grabbedDate,targetDate);

      s.date=addDays(oldStart,shift);

      if(oldEnd!==oldStart || s.endDate){
        s.endDate=addDays(oldEnd,shift);
      }

      saveAndRender();
    }

    suppressClickUntil=Date.now()+450;
    finishDrag();
  }

  function onCancel(){
    window.removeEventListener("pointermove",onMove,true);
    window.removeEventListener("pointerup",onUp,true);
    window.removeEventListener("pointercancel",onCancel,true);
    finishDrag();
  }

  window.addEventListener("pointermove",onMove,true);
  window.addEventListener("pointerup",onUp,true);
  window.addEventListener("pointercancel",onCancel,true);
}

/* Resolve ordinary one-day schedule chips reliably from the rendered day + text. */
function scheduleFromEventChip(chip){
  const explicit=chip.dataset.scheduleId;
  if(explicit){
    const found=byId(explicit);
    if(found)return found;
  }

  const date=chip.closest(".day")?.dataset.date;
  const text=(chip.textContent||"").trim();

  return schedules().find(s=>{
    const end=s.endDate||s.date;
    const onDate=s.date<=date && date<=end;
    const stageTitle=`${s.stage||""} · ${s.title||""}`.trim();
    return onDate && (
      text===stageTitle ||
      (s.title&&text.endsWith(s.title)) ||
      (s.title&&chip.title?.includes(s.title))
    );
  })||null;
}

/* Resolve a range bar by its title. Range bars are generated outside day nodes. */
function scheduleFromRangeBar(bar){
  const explicit=bar.dataset.scheduleId;
  if(explicit){
    const found=byId(explicit);
    if(found)return found;
  }
  const label=(bar.textContent||"").trim();
  return schedules().find(s=>
    s.endDate&&s.endDate>s.date&&s.title&&
    (label===`${s.stage||"일정"} · ${s.title}` || label.endsWith(s.title))
  )||null;
}

/*
 Use document capture, but only start our drag on actual schedule elements.
 Deadlines remain excluded.
*/
document.addEventListener("pointerdown",e=>{
  const chip=e.target.closest?.("#calendarGrid .event-chip:not(.deadline-chip)");
  if(chip){
    const s=scheduleFromEventChip(chip);
    if(!s)return;
    const sourceDate=chip.closest(".day")?.dataset.date||s.date;
    beginDrag(e,s,sourceDate);
    return;
  }

  const bar=e.target.closest?.("#calendarGrid .calendar-range-bar");
  if(bar){
    const s=scheduleFromRangeBar(bar);
    if(!s)return;

    /*
     The bar can span several cells. Determine the exact day under the pointer
     before starting so dragging from the middle behaves naturally.
    */
    const sourceDate=sourceDateFromPoint(e.clientX,e.clientY,s.date);
    beginDrag(e,s,sourceDate);
  }
},true);

/* Suppress the normal edit-click that browsers emit after a successful drag. */
document.addEventListener("click",e=>{
  if(Date.now()>=suppressClickUntil)return;

  if(e.target.closest?.("#calendarGrid .event-chip:not(.deadline-chip), #calendarGrid .calendar-range-bar")){
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
  }
},true);

console.info("WORKROOM v79 calendar drag move geometry fix loaded");
})();