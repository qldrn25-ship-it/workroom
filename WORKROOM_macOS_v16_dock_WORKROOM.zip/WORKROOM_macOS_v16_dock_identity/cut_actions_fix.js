(() => {
"use strict";

const q=s=>document.querySelector(s);

function currentEpisode(){
  try{
    if(typeof activeEpisode==="function"){
      const ep=activeEpisode();
      if(ep)return ep;
    }
  }catch(_){}

  if(typeof data!=="undefined"){
    const id=q("#episodeSelect")?.value||data.activeEpisodeId;
    return (data.episodes||[]).find(ep=>String(ep.id)===String(id))||null;
  }
  return null;
}

function currentCut(){
  const ep=currentEpisode();
  const id=q("#cutId")?.value||"";
  return ep?.cuts?.find(c=>String(c.id)===String(id))||null;
}

function persist(){
  try{
    if(typeof saveData==="function")saveData();
  }catch(err){
    console.error("cut action save failed",err);
  }
}

function refreshCuts(){
  try{
    if(typeof renderCuts==="function")renderCuts();
  }catch(err){
    console.error("cut action render failed",err);
  }
}

function closeEditorWithoutResave(){
  /*
   Deletion must not call the normal close routine because that routine
   autosaves the currently open cut and can recreate a deleted cut in
   some older extension combinations.
  */
  try{
    if(typeof cutCloseSkipSave!=="undefined")cutCloseSkipSave=true;
  }catch(_){}
  q("#cutModal")?.classList.remove("open");
}

function safeClone(value){
  try{
    return structuredClone(value);
  }catch(_){
    return JSON.parse(JSON.stringify(value));
  }
}

function freshId(){
  return crypto.randomUUID?.()||
    `cut-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function resetNestedIds(obj){
  /*
   Most nested cut data currently uses values rather than IDs, but this
   protects future checklist/image metadata from sharing generated IDs.
  */
  if(!obj||typeof obj!=="object")return;

  if(Array.isArray(obj)){
    obj.forEach(resetNestedIds);
    return;
  }

  Object.entries(obj).forEach(([key,value])=>{
    if(
      key!=="id" &&
      /(^|_)(id|uuid)$/i.test(key) &&
      typeof value==="string"
    ){
      obj[key]=freshId();
      return;
    }
    resetNestedIds(value);
  });
}

function duplicateCut(){
  const ep=currentEpisode();
  const source=currentCut();
  if(!ep||!source){
    alert("복제할 컷을 찾을 수 없습니다.");
    return;
  }

  /* Save visible editor contents first if the normal saver exists. */
  try{
    if(typeof saveOpenCutDraft==="function"){
      saveOpenCutDraft({render:false});
    }
  }catch(err){
    console.warn("pre-duplicate draft save skipped",err);
  }

  const idx=ep.cuts.findIndex(c=>String(c.id)===String(source.id));
  if(idx<0)return;

  const clone=safeClone(source);
  clone.id=freshId();
  resetNestedIds(clone);

  /* A duplicate is a new work item, not a second completion record. */
  clone.completedAt="";
  if(clone.reviewedAt!==undefined)clone.reviewedAt="";
  if(clone.updatedAt!==undefined)clone.updatedAt=Date.now();

  ep.cuts.splice(idx+1,0,clone);
  persist();
  refreshCuts();

  /* Continue editing the newly duplicated cut. */
  setTimeout(()=>{
    try{
      if(typeof openCutModal==="function")openCutModal(clone.id);
      else{
        q("#cutId").value=clone.id;
      }
    }catch(err){
      console.error("open duplicated cut failed",err);
    }
  },20);
}

function deleteCut(){
  const ep=currentEpisode();
  const cut=currentCut();
  if(!ep||!cut){
    alert("삭제할 컷을 찾을 수 없습니다.");
    return;
  }

  const idx=ep.cuts.findIndex(c=>String(c.id)===String(cut.id));
  if(idx<0)return;

  if(!confirm("이 컷을 삭제할까요? 휴지통에서 복구할 수 있습니다."))return;

  /*
   Push a copy to Trash before removing it.
   Fall back to a direct trash record if an older pushTrash implementation
   throws, so deletion itself still succeeds.
  */
  try{
    if(typeof pushTrash==="function"){
      pushTrash("cut",safeClone(cut),{episodeId:ep.id,index:idx});
    }else{
      if(!Array.isArray(data.trash))data.trash=[];
      data.trash.push({
        trashId:freshId(),
        type:"cut",
        deletedAt:Date.now(),
        payload:safeClone(cut),
        context:{episodeId:ep.id,index:idx}
      });
    }
  }catch(err){
    console.warn("pushTrash fallback",err);
    if(!Array.isArray(data.trash))data.trash=[];
    data.trash.push({
      trashId:freshId(),
      type:"cut",
      deletedAt:Date.now(),
      payload:safeClone(cut),
      context:{episodeId:ep.id,index:idx}
    });
  }

  ep.cuts.splice(idx,1);

  /* Remove it from selection state if selection mode has it. */
  try{
    if(typeof selectedCutIds!=="undefined")selectedCutIds.delete(cut.id);
  }catch(_){}

  persist();
  closeEditorWithoutResave();
  refreshCuts();

  try{
    if(typeof syncBulkSelectionUI==="function")syncBulkSelectionUI();
  }catch(_){}
}

/*
 Capture-phase handlers run before older onclick handlers.  We stop the
 event after our action, which prevents two copies/deletions from firing.
*/
q("#duplicateCutBtn")?.addEventListener("click",e=>{
  e.preventDefault();
  e.stopPropagation();
  e.stopImmediatePropagation();
  duplicateCut();
},true);

q("#deleteCutBtn")?.addEventListener("click",e=>{
  e.preventDefault();
  e.stopPropagation();
  e.stopImmediatePropagation();
  deleteCut();
},true);

console.info("WORKROOM v95 cut delete/duplicate actions loaded");
})();