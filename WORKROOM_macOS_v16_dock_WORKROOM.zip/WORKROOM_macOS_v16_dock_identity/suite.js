(() => {
"use strict";

const SUITE_VERSION = 24;
const SNAPSHOT_KEY = "webtoonWorkroom.snapshots.v24";
const GOAL_KEY = "webtoonWorkroom.dailyGoal";
const ACTIVE_TIMER_KEY = "webtoonWorkroom.activeTimer";
const $s = s => document.querySelector(s);
const $$s = s => [...document.querySelectorAll(s)];

function suiteEsc(v=""){ return String(v).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m])); }
function nowISODate(){ return todayISO(); }
function ensureSuiteData(){
  if(!Array.isArray(data.resources)) data.resources=[];
  if(!Array.isArray(data.timeLogs)) data.timeLogs=[];
  if(!data.suiteSettings) data.suiteSettings={};
  data.suiteSettings.dailyWorkHours = Number(data.suiteSettings.dailyWorkHours||6);
  data.resources.forEach(r=>{
    if(r.linkImage===undefined)r.linkImage=getEmbeddableImageFromUrl(r.url||"");
  });
  data.episodes.forEach(ep=>{
    (ep.cuts||[]).forEach(c=>{
      if(c.characterList===undefined)c.characterList=normalizeCharacterArray(c.characters||"");
      if(c.characters===undefined)c.characters=(c.characterList||[]).join(", ");
      if(c.background===undefined)c.background="";
      if(c.difficulty===undefined)c.difficulty="normal";
      if(c.estimatedMinutes===undefined)c.estimatedMinutes=30;
      if(c.completedAt===undefined)c.completedAt="";
    });
  });
}
ensureSuiteData();

function safePersist(){
  try{ localStorage.setItem(STORAGE_KEY,JSON.stringify(data)); return true; }catch(e){ return false; }
}
safePersist();

/* ---------- auto backup history ---------- */
let snapshotTimer=null;
let lastSnapshotAt=0;
function getSnapshots(){
  try{return JSON.parse(localStorage.getItem(SNAPSHOT_KEY)||"[]")}catch(e){return[]}
}
function setSnapshots(items){
  try{localStorage.setItem(SNAPSHOT_KEY,JSON.stringify(items));return true}catch(e){return false}
}
function createSnapshot(reason="자동"){
  const raw=JSON.stringify(data);
  // Large image-heavy projects can overflow localStorage. Keep history conservative.
  if(raw.length>2_500_000){
    renderSnapshots("데이터가 커서 자동 백업은 건너뜀 · JSON 백업 사용 권장");
    return false;
  }
  const items=getSnapshots();
  items.unshift({id:crypto.randomUUID(),at:Date.now(),reason,data:raw});
  while(items.length>6)items.pop();
  const ok=setSnapshots(items);
  if(ok){ lastSnapshotAt=Date.now(); renderSnapshots(); }
  return ok;
}
function scheduleSnapshot(){
  clearTimeout(snapshotTimer);
  snapshotTimer=setTimeout(()=>{
    if(Date.now()-lastSnapshotAt>5*60*1000)createSnapshot("자동");
  },1200);
}
const baseSaveData = saveData;
saveData = function(){
  const r=baseSaveData();
  scheduleSnapshot();
  if($s("#dashboardView")?.classList.contains("active")) renderTodayGoal();
  return r;
};

function renderSnapshots(message=""){
  const list=$s("#snapshotList"), status=$s("#backupStatus");
  if(!list||!status)return;
  const items=getSnapshots();
  status.textContent=message || (items[0]?`최근 백업 · ${new Date(items[0].at).toLocaleString("ko-KR")} · ${items[0].reason}`:"백업 기록 없음");
  list.innerHTML="";
  items.slice(0,4).forEach(s=>{
    const row=document.createElement("div");row.className="snapshot-row";
    row.innerHTML=`<span>${new Date(s.at).toLocaleString("ko-KR")} · ${suiteEsc(s.reason)}</span><button type="button">복원</button>`;
    row.querySelector("button").onclick=()=>{
      if(!confirm("이 시점의 데이터로 복원할까요? 현재 상태는 먼저 자동 백업합니다."))return;
      createSnapshot("복원 직전");
      try{
        data=JSON.parse(s.data);
        normalizeImportedData();
        ensureSuiteData();
        safePersist();
        renderAllSuite();
        alert("백업 시점으로 복원했습니다.");
      }catch(e){alert("백업 복원에 실패했습니다.");}
    };
    list.appendChild(row);
  });
}
$s("#manualSnapshotBtn")?.addEventListener("click",()=>createSnapshot("수동"));
renderSnapshots();

/* ---------- view extension ---------- */
const originalSwitchView = switchView;
switchView = function(view){
  originalSwitchView(view);
  if(view==="resources"){
    $s("#pageTitle").textContent="자료실";
    renderResources();
  }
};
$$s('.nav-btn[data-view="resources"]').forEach(btn=>{
  btn.addEventListener("click",()=>{
    // original listener already runs; this ensures render after it.
    setTimeout(()=>renderResources(),0);
  });
});

/* ---------- resources / characters / backgrounds ---------- */
let resourceImageDraft="";

let resourceLinkImageDraft="";

function getYouTubeId(url){
  try{
    const u=new URL(url);
    const host=u.hostname.replace(/^www\./,"");
    if(host==="youtu.be"){
      return u.pathname.split("/").filter(Boolean)[0]||"";
    }
    if(host==="youtube.com" || host==="m.youtube.com"){
      if(u.pathname==="/watch") return u.searchParams.get("v")||"";
      const parts=u.pathname.split("/").filter(Boolean);
      if(["shorts","embed","live"].includes(parts[0])) return parts[1]||"";
    }
  }catch(_){}
  return "";
}

function getEmbeddableImageFromUrl(url){
  const clean=(url||"").trim();
  if(!clean)return "";

  // Direct image links.
  if(/\.(?:jpe?g|png|webp|gif|avif)(?:[?#].*)?$/i.test(clean)){
    return clean;
  }

  // YouTube thumbnail.
  const yt=getYouTubeId(clean);
  if(yt){
    return `https://i.ytimg.com/vi/${encodeURIComponent(yt)}/hqdefault.jpg`;
  }

  return "";
}

function updateResourceLinkEmbedUI(){
  const panel=$s("#resourceLinkEmbedPreview");
  const img=$s("#resourceLinkEmbedImage");
  const help=$s("#resourceLinkEmbedHelp");
  if(!panel||!img||!help)return;

  const url=$s("#resourceUrl")?.value.trim()||"";
  const preview=getEmbeddableImageFromUrl(url);
  resourceLinkImageDraft=preview;

  panel.classList.toggle("has-image",!!preview);

  if(preview){
    img.src=preview;
    help.textContent=getYouTubeId(url)?"YouTube 썸네일 자동 임베드":"이미지 링크 자동 임베드";
  }else{
    img.removeAttribute("src");
    help.textContent=url
      ?"이 링크에서는 직접 이미지 주소를 찾을 수 없습니다"
      :"이미지 링크 또는 YouTube 링크를 입력하세요";
  }
}

function kindLabel(k){return {character:"CHARACTER",background:"BACKGROUND",reference:"REFERENCE",link:"LINK"}[k]||"RESOURCE"}
function renderResourceProjectSelect(){
  const sel=$s("#resourceProjectSelect");if(!sel)return;
  const prev=sel.value||data.activeProjectId||"all";
  sel.innerHTML=`<option value="all">전체 작품</option>`+
    data.projects.map(p=>`<option value="${p.id}">${suiteEsc(p.name)}</option>`).join("");

  if(prev==="all"){
    sel.value="all";
  }else if(data.projects.some(p=>p.id===prev)){
    sel.value=prev;
  }else if(data.projects.some(p=>p.id===data.activeProjectId)){
    sel.value=data.activeProjectId;
  }else{
    sel.value="all";
  }
}
function renderResources(){
  renderResourceProjectSelect();
  const grid=$s("#resourceGrid");if(!grid)return;
  const kind=$s("#resourceKindFilter")?.value||"all";
  const projectFilter=$s("#resourceProjectSelect")?.value||"all";
  const items=data.resources.filter(r=>
    (projectFilter==="all"||String(r.projectId)===String(projectFilter)) &&
    (kind==="all"||r.kind===kind)
  );
  grid.innerHTML="";
  if(!items.length){grid.innerHTML=`<div class="empty-state">이 작품의 자료가 없습니다.<br>캐릭터, 배경, 참고 이미지를 등록해 보세요.</div>`;updateCutSuggestionLists();return}
  items.forEach(r=>{
    const card=document.createElement("article");
    const linkImage=r.linkImage||getEmbeddableImageFromUrl(r.url||"");
    const thumbSrc=r.image||linkImage||"";
    card.className="resource-card glass"+(!r.image&&linkImage?" link-embedded":"");
    card.dataset.id=r.id;
    const thumb=thumbSrc?`<div class="resource-thumb"><img src="${thumbSrc}" alt=""></div>`:`<div class="resource-thumb"></div>`;
    const meta=r.kind==="character"?[r.profile,r.outfit].filter(Boolean).join(" · "):r.kind==="background"?(r.locationType||""):r.url||"";
    card.innerHTML=`${thumb}<div class="resource-card-body"><span class="resource-kind">${kindLabel(r.kind)}</span><h4>${suiteEsc(r.name)}</h4><p>${suiteEsc(r.notes||meta||"메모 없음")}</p>${r.url?`<button class="resource-link-open resource-direct-link" type="button" title="저장된 링크 바로 열기">↗ 링크 바로가기</button>`:""}</div>`;

    card.onclick=()=>openResourceModal(r.kind,r.id);

    const directLink=card.querySelector(".resource-direct-link");
    if(directLink){
      directLink.addEventListener("click",e=>{
        e.preventDefault();
        e.stopPropagation();
        const url=String(r.url||"").trim();
        if(!url)return;
        try{
          window.open(url,"_blank","noopener,noreferrer");
        }catch(err){
          console.error("자료 링크 열기 실패",err);
          location.href=url;
        }
      });
    }

    grid.appendChild(card);
  });
  updateCutSuggestionLists();
}
function updateCutSuggestionLists(){
  const chars=data.resources.filter(r=>r.projectId===data.activeProjectId&&r.kind==="character");
  const bgs=data.resources.filter(r=>r.projectId===data.activeProjectId&&r.kind==="background");
  const c=$s("#characterSuggestions"),b=$s("#backgroundSuggestions");
  if(c)c.innerHTML=chars.map(x=>`<option value="${suiteEsc(x.name)}"></option>`).join("");
  if(b)b.innerHTML=bgs.map(x=>`<option value="${suiteEsc(x.name)}"></option>`).join("");
}
function updateResourceImageUI(){
  const has=!!resourceImageDraft;
  $s("#resourceImageEmpty").style.display=has?"none":"flex";
  $s("#resourceImagePreviewWrap").classList.toggle("active",has);
  $s("#resourceImageActions").classList.toggle("active",has);
  if(has)$s("#resourceImagePreview").src=resourceImageDraft; else $s("#resourceImagePreview").removeAttribute("src");
}
function toggleResourceFields(kind){
  $$s(".resource-character-field").forEach(x=>x.style.display=kind==="character"?"flex":"none");
  $$s(".resource-background-field").forEach(x=>x.style.display=kind==="background"?"flex":"none");
}
function openResourceModal(kind,id=""){
  const r=id?data.resources.find(x=>x.id===id):null;
  kind=r?.kind||kind||"reference";
  $s("#resourceModalTitle").textContent=r?`${r.name} 편집`:`${{character:"캐릭터",background:"배경·장소",reference:"참고 자료",link:"링크"}[kind]||"자료"} 추가`;
  $s("#resourceId").value=r?.id||"";
  $s("#resourceKind").value=kind;
  $s("#resourceName").value=r?.name||"";
  $s("#resourceUrl").value=r?.url||"";
  resourceLinkImageDraft=r?.linkImage||getEmbeddableImageFromUrl(r?.url||"");
  updateResourceLinkEmbedUI();
  $s("#resourceProfile").value=r?.profile||"";
  $s("#resourceSpeech").value=r?.speech||"";
  $s("#resourceOutfit").value=r?.outfit||"";
  $s("#resourcePalette").value=r?.palette||"";
  if(typeof window.setCharacterCustomFields==="function"){
    window.setCharacterCustomFields(r?.customFields||[]);
  }
  $s("#resourceLocationType").value=r?.locationType||"";
  $s("#resourceNotes").value=r?.notes||"";
  resourceImageDraft=r?.image||"";
  updateResourceImageUI();toggleResourceFields(kind);
  $s("#deleteResourceBtn").style.visibility=r?"visible":"hidden";
  $s("#resourceModal").classList.add("open");
}
function closeResourceModal(){ $s("#resourceModal").classList.remove("open"); }
$s("#resourceProjectSelect")?.addEventListener("change",e=>{
  const value=e.target.value;
  if(value!=="all"){
    data.activeProjectId=value;
    safePersist();
  }
  renderResources();
});
$s("#resourceKindFilter")?.addEventListener("change",renderResources);
$s("#resourceUrl")?.addEventListener("input",updateResourceLinkEmbedUI);
$s("#resourceLinkEmbedImage")?.addEventListener("error",()=>{
  resourceLinkImageDraft="";
  $s("#resourceLinkEmbedPreview")?.classList.remove("has-image");
  $s("#resourceLinkEmbedImage")?.removeAttribute("src");
  if($s("#resourceLinkEmbedHelp")){
    $s("#resourceLinkEmbedHelp").textContent="이미지를 불러올 수 없는 링크입니다";
  }
});
$s("#addCharacterBtn")?.addEventListener("click",()=>openResourceModal("character"));
$s("#addBackgroundBtn")?.addEventListener("click",()=>openResourceModal("background"));
$s("#addReferenceBtn")?.addEventListener("click",()=>openResourceModal("reference"));
$s("#closeResourceX")?.addEventListener("click",closeResourceModal);
$s("#resourceForm")?.addEventListener("submit",e=>{
  e.preventDefault();
  const id=$s("#resourceId").value||crypto.randomUUID();
  const item={id,projectId:data.activeProjectId,kind:$s("#resourceKind").value,name:$s("#resourceName").value.trim(),url:$s("#resourceUrl").value.trim(),
    profile:$s("#resourceProfile").value.trim(),speech:$s("#resourceSpeech").value.trim(),outfit:$s("#resourceOutfit").value.trim(),palette:$s("#resourcePalette").value.trim(),
    customFields:(typeof window.getCharacterCustomFields==="function" ? window.getCharacterCustomFields() : []),
    locationType:$s("#resourceLocationType").value.trim(),notes:$s("#resourceNotes").value,image:resourceImageDraft,linkImage:resourceLinkImageDraft,updated:Date.now()};
  const idx=data.resources.findIndex(x=>x.id===id);if(idx>=0)data.resources[idx]=item;else data.resources.push(item);
  saveData();renderResources();closeResourceModal();
});
$s("#deleteResourceBtn")?.addEventListener("click",()=>{
  const id=$s("#resourceId").value;if(!id)return;
  if(!confirm("이 자료를 삭제할까요?"))return;
  data.resources=data.resources.filter(x=>x.id!==id);saveData();renderResources();closeResourceModal();
});
async function handleResourceImage(file){
  try{resourceImageDraft=await compressMemoImage(file);updateResourceImageUI()}catch(e){alert("이미지를 불러오지 못했습니다.")}
}
$s("#resourceImageInput")?.addEventListener("change",e=>{const f=e.target.files?.[0];if(f)handleResourceImage(f);e.target.value=""});
$s("#replaceResourceImageBtn")?.addEventListener("click",()=> $s("#resourceImageInput").click());
$s("#removeResourceImageBtn")?.addEventListener("click",()=>{resourceImageDraft="";updateResourceImageUI()});
$s("#resourceImageDrop")?.addEventListener("dragover",e=>{e.preventDefault();$s("#resourceImageDrop").classList.add("dragover")});
$s("#resourceImageDrop")?.addEventListener("dragleave",()=> $s("#resourceImageDrop").classList.remove("dragover"));
$s("#resourceImageDrop")?.addEventListener("drop",e=>{e.preventDefault();$s("#resourceImageDrop").classList.remove("dragover");const f=[...e.dataTransfer.files].find(x=>x.type.startsWith("image/"));if(f)handleResourceImage(f)});


/* ---------- character multi select ---------- */
let selectedCharacterNames=[];

function normalizeCharacterArray(value){
  if(Array.isArray(value)) return [...new Set(value.map(v=>String(v).trim()).filter(Boolean))];
  if(typeof value==="string") return [...new Set(value.split(/[,，\n]/).map(v=>v.trim()).filter(Boolean))];
  return [];
}
function currentProjectCharacters(){
  return data.resources.filter(r=>r.projectId===data.activeProjectId&&r.kind==="character").map(r=>r.name).filter(Boolean);
}
function syncCutCharactersHidden(){
  const input=$s("#cutCharacters");
  if(input) input.value=selectedCharacterNames.join(", ");
}
function renderCharacterChips(){
  const box=$s("#characterChipList"); if(!box)return;
  box.innerHTML="";
  selectedCharacterNames.forEach(name=>{
    const chip=document.createElement("span");
    chip.className="character-chip";
    chip.innerHTML=`<span>${suiteEsc(name)}</span><button type="button" aria-label="${suiteEsc(name)} 제거">×</button>`;
    chip.querySelector("button").onclick=e=>{
      e.preventDefault();e.stopPropagation();
      selectedCharacterNames=selectedCharacterNames.filter(x=>x!==name);
      syncCutCharactersHidden();renderCharacterChips();renderCharacterPicker();saveCharacterSelectionToCut();
    };
    box.appendChild(chip);
  });
  syncCutCharactersHidden();
}
function renderCharacterPicker(){
  const list=$s("#characterPickerList"); if(!list)return;
  const q=($s("#characterPickerSearch")?.value||"").trim().toLowerCase();
  const chars=currentProjectCharacters().filter(name=>name.toLowerCase().includes(q));
  list.innerHTML="";
  if(!chars.length){
    list.innerHTML=`<div class="character-picker-empty">자료실에 등록된 캐릭터가 없습니다.<br>자료실에서 캐릭터를 먼저 추가해 주세요.</div>`;
    return;
  }
  chars.forEach(name=>{
    const selected=selectedCharacterNames.includes(name);
    const item=document.createElement("label");
    item.className="character-picker-item"+(selected?" selected":"");
    item.innerHTML=`<input type="checkbox" ${selected?"checked":""} /><span>${suiteEsc(name)}</span>`;
    const cb=item.querySelector("input");
    cb.addEventListener("change",()=>{
      if(cb.checked){
        if(!selectedCharacterNames.includes(name)) selectedCharacterNames.push(name);
      }else{
        selectedCharacterNames=selectedCharacterNames.filter(x=>x!==name);
      }
      syncCutCharactersHidden();renderCharacterChips();renderCharacterPicker();saveCharacterSelectionToCut();
    });
    list.appendChild(item);
  });
}
function saveCharacterSelectionToCut(){
  const ep=activeEpisode();
  const c=ep?.cuts.find(x=>x.id===$s("#cutId")?.value); if(!c)return;
  c.characterList=[...selectedCharacterNames];
  c.characters=selectedCharacterNames.join(", ");
  safePersist();
}
$s("#characterPickerToggle")?.addEventListener("click",()=>{
  $s("#characterPickerPanel")?.classList.toggle("open");
  renderCharacterPicker();
});
$s("#characterPickerSearch")?.addEventListener("input",renderCharacterPicker);
$s("#clearCharacterSelectionBtn")?.addEventListener("click",()=>{
  selectedCharacterNames=[];
  syncCutCharactersHidden();renderCharacterChips();renderCharacterPicker();saveCharacterSelectionToCut();
});

/* ---------- cut effort fields ---------- */
const oldOpenCutModal=openCutModal;
openCutModal=function(id){
  oldOpenCutModal(id);

  const ep=activeEpisode();
  const c=ep?.cuts.find(x=>String(x.id)===String(id));
  if(!c)return;

  selectedCharacterNames=normalizeCharacterArray(
    c.characterList?.length?c.characterList:c.characters||""
  );
  renderCharacterChips();
  renderCharacterPicker();
  $s("#characterPickerPanel")?.classList.remove("open");

  const bg=$s("#cutBackground");
  if(bg)bg.value=c.background||"";

  const difficulty=$s("#cutDifficulty");
  if(difficulty)difficulty.value=c.difficulty||"normal";

  const estimated=$s("#cutEstimatedMinutes");
  if(estimated)estimated.value=Number(c.estimatedMinutes||30);

  updateCutSuggestionLists();
};
function saveCutSuiteFields(){
  const ep=activeEpisode();
  const c=ep?.cuts.find(x=>String(x.id)===String($s("#cutId")?.value));
  if(!c)return;

  const bg=$s("#cutBackground");
  if(bg)c.background=bg.value.trim();

  const difficulty=$s("#cutDifficulty");
  if(difficulty)c.difficulty=difficulty.value;

  const estimated=$s("#cutEstimatedMinutes");
  if(estimated)c.estimatedMinutes=Math.max(0,Number(estimated.value||0));
}
["cutBackground","cutEstimatedMinutes"].forEach(id=>$s("#"+id)?.addEventListener("input",()=>{saveCutSuiteFields();safePersist()}));
$s("#cutDifficulty")?.addEventListener("change",()=>{saveCutSuiteFields();safePersist()});
$s("#cutStatus")?.addEventListener("change",()=>{
  const ep=activeEpisode(),c=ep?.cuts.find(x=>x.id===$s("#cutId").value);if(!c)return;
  if($s("#cutStatus").value==="done"&&!c.completedAt)c.completedAt=nowISODate();
  if($s("#cutStatus").value!=="done")c.completedAt="";
  safePersist();renderTodayGoal();
});
// Capture bulk selection before original handler clears it.
let pendingBulkIds=[];
$s("#applyBulkStatusBtn")?.addEventListener("click",()=>{
  pendingBulkIds=[...selectedCutIds];
  const status=$s("#bulkStatusSelect").value;
  setTimeout(()=>{
    const ep=activeEpisode();if(!ep)return;
    ep.cuts.forEach(c=>{
      if(pendingBulkIds.includes(c.id)){
        if(status==="done"&&!c.completedAt)c.completedAt=nowISODate();
        if(status!=="done")c.completedAt="";
      }
    });
    safePersist();renderTodayGoal();
  },0);
},true);

/* add difficulty/time badges after every cuts render */
const originalRenderCuts=renderCuts;
renderCuts=function(){
  originalRenderCuts();
  const ep=activeEpisode();if(!ep)return;
  $$s("#cutsGrid .cut-card").forEach(card=>{
    const c=ep.cuts.find(x=>x.id===card.dataset.id);if(!c)return;
    let meta=card.querySelector(".cut-extra-meta");
    if(!meta){meta=document.createElement("div");meta.className="cut-extra-meta";card.querySelector(".cut-desc")?.after(meta)}
    meta.innerHTML=`<span class="cut-mini-badge">약 ${Number(c.estimatedMinutes||30)}분</span>${c.background?`<span class="cut-mini-badge">${suiteEsc(c.background)}</span>`:""}`;
  });
  
};

/* ---------- today goal ---------- */
function getDailyGoal(){return Math.max(1,Number(localStorage.getItem(GOAL_KEY)||20))}
function renderTodayGoal(){
  const goal=getDailyGoal();
  const done=data.episodes.flatMap(e=>e.cuts||[]).filter(c=>c.status==="done"&&c.completedAt===nowISODate()).length;
  const pct=Math.min(100,Math.round(done/goal*100));
  if($s("#todayGoalInput"))$s("#todayGoalInput").value=goal;
  if($s("#todayGoalText"))$s("#todayGoalText").textContent=`${done} / ${goal}컷`;
  if($s("#todayGoalPercent"))$s("#todayGoalPercent").textContent=`${pct}%`;
  if($s("#todayGoalFill"))$s("#todayGoalFill").style.width=pct+"%";
  if($s("#todayGoalHint"))$s("#todayGoalHint").textContent=done>=goal?"오늘 목표 달성 ✓":`목표까지 ${Math.max(0,goal-done)}컷 남음`;
}
$s("#todayGoalInput")?.addEventListener("change",e=>{localStorage.setItem(GOAL_KEY,Math.max(1,Number(e.target.value||20)));renderTodayGoal()});
renderTodayGoal();

/* ---------- work timer ---------- */
let timerTick=null;
let activeTimer=null;
try{activeTimer=JSON.parse(localStorage.getItem(ACTIVE_TIMER_KEY)||"null")}catch(e){}
function populateTimerSelects(){
  const ps=$s("#timerProjectSelect"),es=$s("#timerEpisodeSelect");if(!ps||!es)return;
  ps.innerHTML=data.projects.map(p=>`<option value="${p.id}">${suiteEsc(p.name)}</option>`).join("");
  ps.value=activeTimer?.projectId||data.activeProjectId||data.projects[0]?.id||"";
  const eps=data.episodes.filter(e=>e.projectId===ps.value);
  es.innerHTML=eps.map(e=>`<option value="${e.id}">${suiteEsc(e.name)}</option>`).join("");
  es.value=activeTimer?.episodeId||eps[0]?.id||"";
}
function timerElapsed(){
  if(!activeTimer)return 0;
  return (activeTimer.accumulated||0)+(activeTimer.running?Date.now()-activeTimer.startedAt:0);
}
function fmtDuration(ms){
  let s=Math.floor(ms/1000),h=Math.floor(s/3600);s%=3600;let m=Math.floor(s/60);s%=60;
  return [h,m,s].map(x=>String(x).padStart(2,"0")).join(":");
}
function renderTimer(){
  if($s("#timerClock"))$s("#timerClock").textContent=fmtDuration(timerElapsed());
  const todayMs=data.timeLogs.filter(x=>x.date===nowISODate()).reduce((a,x)=>a+(x.duration||0),0)+(activeTimer?.running?Date.now()-activeTimer.startedAt:0);
  if($s("#timerSummary"))$s("#timerSummary").textContent=`오늘 기록 ${Math.round(todayMs/60000)}분`;
  if($s("#timerStartBtn"))$s("#timerStartBtn").textContent=activeTimer?.running?"Ⅱ 일시정지":"▶ 시작";
}
function saveActiveTimer(){
  if(activeTimer)localStorage.setItem(ACTIVE_TIMER_KEY,JSON.stringify(activeTimer));else localStorage.removeItem(ACTIVE_TIMER_KEY);
}
function startTimer(){
  const projectSelect=$s("#timerProjectSelect"),episodeSelect=$s("#timerEpisodeSelect");
  if(!projectSelect||!episodeSelect)return;
  if(activeTimer?.running){
    activeTimer.accumulated=(activeTimer.accumulated||0)+(Date.now()-activeTimer.startedAt);activeTimer.running=false;
  }else{
    if(!activeTimer)activeTimer={projectId:projectSelect.value,episodeId:episodeSelect.value,accumulated:0,running:true,startedAt:Date.now()};
    else{activeTimer.projectId=projectSelect.value;activeTimer.episodeId=episodeSelect.value;activeTimer.running=true;activeTimer.startedAt=Date.now()}
  }
  saveActiveTimer();renderTimer();
}
function stopTimer(){
  if(!activeTimer)return;
  const total=timerElapsed();
  if(total>1000)data.timeLogs.push({id:crypto.randomUUID(),projectId:activeTimer.projectId,episodeId:activeTimer.episodeId,date:nowISODate(),duration:total});
  activeTimer=null;saveActiveTimer();saveData();renderTimer();
}
$s("#timerProjectSelect")?.addEventListener("change",populateTimerSelects);
$s("#timerStartBtn")?.addEventListener("click",startTimer);
$s("#timerStopBtn")?.addEventListener("click",stopTimer);
populateTimerSelects();renderTimer();timerTick=setInterval(renderTimer,1000);

/* ---------- calendar → episode link ---------- */
const originalRenderCalendar=renderCalendar;
renderCalendar=function(){
  originalRenderCalendar();
  // Existing calendar already links deadline chips. For regular schedules,
  // annotate linked ones and intercept click in capture phase.
  const days=$$s("#calendarGrid .day");
  days.forEach(day=>{
    $$s(".event-chip:not(.deadline-chip)",day).forEach(btn=>{
      const text=btn.textContent||"";
      const title=btn.title||"";
      const schedule=data.schedules.find(s=>`${s.stage} · ${s.title}`===text && `${s.project||""} ${s.episode||""} / ${s.progress||0}%`===title);
      if(!schedule)return;
      let ep=null,p=null;
      if(schedule.episodeId)ep=data.episodes.find(e=>e.id===schedule.episodeId);
      if(!ep && schedule.project&&schedule.episode){
        p=data.projects.find(x=>x.name===schedule.project);
        ep=data.episodes.find(e=>e.projectId===p?.id&&e.name===schedule.episode);
      }
      if(ep){
        p=p||data.projects.find(x=>x.id===ep.projectId);
        btn.dataset.linkedEpisode=ep.id;btn.dataset.linkedProject=p?.id||"";
        btn.classList.add("linked-schedule-chip");
      }
    });
  });
};
$s("#calendarGrid")?.addEventListener("click",e=>{
  const btn=e.target.closest(".linked-schedule-chip");if(!btn)return;
  e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();
  data.activeProjectId=btn.dataset.linkedProject;data.activeEpisodeId=btn.dataset.linkedEpisode;saveData();switchView("cuts");
},true);

/* ---------- global search ---------- */
function openGlobalSearch(){
  $s("#globalSearchModal").classList.add("open");$s("#globalSearchInput").value="";renderGlobalSearch("");
  requestAnimationFrame(()=>$s("#globalSearchInput").focus());
}
function closeGlobalSearch(){ $s("#globalSearchModal").classList.remove("open") }
$s("#globalSearchBtn")?.addEventListener("click",openGlobalSearch);
$s("#closeGlobalSearchX")?.addEventListener("click",closeGlobalSearch);
$s("#globalSearchInput")?.addEventListener("input",e=>renderGlobalSearch(e.target.value));
function searchHay(v){return String(v||"").toLowerCase()}
function renderGlobalSearch(q){
  const box=$s("#globalSearchResults");if(!box)return;q=q.trim().toLowerCase();box.innerHTML="";
  if(!q){box.innerHTML=`<div class="empty-state">검색어를 입력하세요.</div>`;return}
  const results=[];
  data.projects.forEach(p=>{if(searchHay(p.name).includes(q))results.push({kind:"작품",title:p.name,sub:"작품 대시보드",go:()=>{data.activeProjectId=p.id;saveData();closeGlobalSearch();switchView("cuts")}})});
  data.episodes.forEach(ep=>{const p=data.projects.find(x=>x.id===ep.projectId);if([ep.name,ep.memo,p?.name].some(v=>searchHay(v).includes(q)))results.push({kind:"회차",title:`${p?.name||""} ${ep.name}`,sub:ep.memo||"회차",go:()=>{data.activeProjectId=ep.projectId;data.activeEpisodeId=ep.id;saveData();closeGlobalSearch();switchView("cuts")}})});
  data.memos.forEach(m=>{if([m.title,m.content,m.tag,m.type].some(v=>searchHay(v).includes(q)))results.push({kind:"메모",title:m.title,sub:(m.content||"").slice(0,90),go:()=>{closeGlobalSearch();switchView("memo");openMemoModal(m.id)}})});
  data.schedules.forEach(s=>{if([s.title,s.project,s.episode,s.memo,s.stage].some(v=>searchHay(v).includes(q)))results.push({kind:"일정",title:s.title,sub:`${s.date} · ${s.project||""} ${s.episode||""}`,go:()=>{closeGlobalSearch();switchView("calendar");openScheduleModal(s.id)}})});
  data.episodes.forEach(ep=>(ep.cuts||[]).forEach((c,i)=>{if([c.description,c.dialogue,c.note,c.characters,(c.characterList||[]).join(" "),c.background,c.tag].some(v=>searchHay(v).includes(q)))results.push({kind:"컷",title:`${data.projects.find(p=>p.id===ep.projectId)?.name||""} ${ep.name} · CUT ${i+1}`,sub:c.dialogue||c.description||c.note||"",go:()=>{data.activeProjectId=ep.projectId;data.activeEpisodeId=ep.id;saveData();closeGlobalSearch();switchView("cuts");setTimeout(()=>openCutModal(c.id),30)}})}));
  data.resources.forEach(r=>{
    const customText=Array.isArray(r.customFields)?r.customFields.map(f=>`${f?.label||""} ${f?.value||""}`).join(" "):"";
    if([r.name,r.notes,r.profile,r.speech,r.outfit,r.locationType,r.url,customText].some(v=>searchHay(v).includes(q)))
      results.push({kind:kindLabel(r.kind),title:r.name,sub:r.notes||r.profile||r.locationType||customText||r.url||"",go:()=>{data.activeProjectId=r.projectId;saveData();closeGlobalSearch();switchView("resources");setTimeout(()=>openResourceModal(r.kind,r.id),30)}})
  });
  if(!results.length){box.innerHTML=`<div class="empty-state">검색 결과가 없습니다.</div>`;return}
  results.slice(0,80).forEach(r=>{const el=document.createElement("div");el.className="search-result";el.innerHTML=`<strong><span class="result-kind">${suiteEsc(r.kind)}</span>${suiteEsc(r.title)}</strong><span>${suiteEsc(r.sub)}</span>`;el.onclick=r.go;box.appendChild(el)});
}

/* ---------- dashboard enrichment ---------- */
const originalRenderDashboard=renderDashboard;
renderDashboard=function(){
  originalRenderDashboard();
  renderTodayGoal();populateTimerSelects();renderTimer();renderSnapshots();
};

/* ---------- project changes sync resource/timer ---------- */
$s("#projectSelect")?.addEventListener("change",()=>{setTimeout(()=>{renderResourceProjectSelect();populateTimerSelects();updateCutSuggestionLists()},0)});
$s("#episodeSelect")?.addEventListener("change",()=>setTimeout(()=>populateTimerSelects(),0));

/* ---------- keyboard shortcuts ---------- */
window.addEventListener("keydown",e=>{
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="k"){
    e.preventDefault();openGlobalSearch();
  }
},true);


/* ---------- import compatibility ---------- */
window.addEventListener("workroom:data-imported",()=>{
  ensureSuiteData();
  safePersist();
  renderAllSuite();
});

/* ---------- final render ---------- */
function renderAllSuite(){
  renderDashboard();renderCalendar();renderMemos();renderEpisodes();renderResources();renderTodayGoal();populateTimerSelects();renderTimer();renderSnapshots();updateCutSuggestionLists();
}
renderAllSuite();
createSnapshot("v24 초기");
})();