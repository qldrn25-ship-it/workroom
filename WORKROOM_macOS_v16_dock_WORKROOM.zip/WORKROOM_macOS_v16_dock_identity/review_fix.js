(() => {
"use strict";

const q=s=>document.querySelector(s);
const esc=v=>String(v??"").replace(/[&<>"']/g,m=>({
  "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
}[m]));

let reviewIndex=0;

function resolveCurrentEpisode(){
  if(typeof data==="undefined" || !data)return null;

  // The select shown on screen is authoritative.
  const selected=q("#episodeSelect")?.value;
  if(selected){
    const ep=(data.episodes||[]).find(e=>String(e.id)===String(selected));
    if(ep)return ep;
  }

  // Then application state.
  if(data.activeEpisodeId){
    const ep=(data.episodes||[]).find(e=>String(e.id)===String(data.activeEpisodeId));
    if(ep)return ep;
  }

  // Then current project first episode.
  const pid=q("#projectSelect")?.value||data.activeProjectId;
  if(pid){
    const ep=(data.episodes||[]).find(e=>String(e.projectId)===String(pid));
    if(ep)return ep;
  }

  return (data.episodes||[])[0]||null;
}

function resolveCuts(ep){
  if(!ep)return [];
  if(Array.isArray(ep.cuts))return ep.cuts;

  // Compatibility only.
  if(typeof data!=="undefined" && Array.isArray(data.cuts)){
    return data.cuts.filter(c=>String(c.episodeId)===String(ep.id));
  }
  return [];
}

function imageFor(c){
  return c?.stageImages?.final ||
         c?.image ||
         c?.imageData ||
         c?.stageImages?.line ||
         c?.stageImages?.rough ||
         c?.stageImages?.storyboard ||
         "";
}

function renderReview(){
  const ep=resolveCurrentEpisode();
  const cuts=resolveCuts(ep);
  const modal=q("#reviewModal");
  const box=q("#reviewContent");

  if(!ep || !modal || !box || !cuts.length)return false;

  reviewIndex=Math.max(0,Math.min(reviewIndex,cuts.length-1));
  const c=cuts[reviewIndex];
  const source=imageFor(c);

  const title=q("#reviewTitle");
  if(title)title.textContent=`${ep.name||"회차"} · CUT ${reviewIndex+1} / ${cuts.length}`;

  box.innerHTML=`
    ${source
      ? `<img class="review-cut-image" src="${source}" alt="CUT ${reviewIndex+1}">`
      : `<div class="empty-state">등록된 컷 이미지 없음</div>`
    }
    <div class="review-cut-meta">
      ${c.status?`<span>${esc(c.status)}</span>`:""}
      ${c.assignee?`<span>${esc(c.assignee)}</span>`:""}
      ${c.feedbackStatus==="needs"?`<span>⚑ 수정 필요</span>`:""}
      ${c.reviewed?`<span>검수됨</span>`:""}
    </div>
    <h4>${esc(c.description||c.title||"컷 설명 없음")}</h4>
    <p>${esc(c.dialogue||"대사 없음")}</p>
    ${c.note?`<p class="soft-help">${esc(c.note)}</p>`:""}
    ${c.feedback?`<p class="soft-help">${esc(c.feedback)}</p>`:""}
  `;

  const prev=q("#reviewPrevBtn"),next=q("#reviewNextBtn");
  if(prev)prev.disabled=reviewIndex===0;
  if(next)next.disabled=reviewIndex===cuts.length-1;

  return true;
}

function openReview(){
  const ep=resolveCurrentEpisode();
  const cuts=resolveCuts(ep);
  const modal=q("#reviewModal");

  if(!modal){
    alert("검수 창을 찾을 수 없습니다.");
    return;
  }
  if(!ep){
    alert("현재 선택된 회차를 찾을 수 없습니다.");
    return;
  }
  if(!cuts.length){
    alert(`현재 선택된 '${ep.name||"회차"}'에 컷이 없습니다.`);
    return;
  }

  reviewIndex=0;
  modal.classList.add("open");
  modal.style.display="flex";
  modal.setAttribute("aria-hidden","false");
  document.body.classList.add("review-open");

  if(!renderReview()){
    modal.classList.remove("open");
    modal.style.display="";
    document.body.classList.remove("review-open");
    alert("검수 화면을 표시하지 못했습니다.");
  }
}

function closeReview(){
  const modal=q("#reviewModal");
  if(!modal)return;
  modal.classList.remove("open");
  modal.style.display="";
  modal.setAttribute("aria-hidden","true");
  document.body.classList.remove("review-open");
}

function persist(){
  try{
    if(typeof saveData==="function")saveData();
    else if(typeof STORAGE_KEY!=="undefined")localStorage.setItem(STORAGE_KEY,JSON.stringify(data));
  }catch(err){console.error(err)}
}

/* One handler only. Do not stopImmediatePropagation:
   there are no longer conflicting review handlers in interaction_fix.js. */
const reviewButton=q("#reviewModeBtn");
if(reviewButton){
  reviewButton.onclick=e=>{
    e.preventDefault();
    openReview();
  };
}

q("#closeReviewX")?.addEventListener("click",e=>{
  e.preventDefault();
  closeReview();
});

q("#reviewPrevBtn")?.addEventListener("click",e=>{
  e.preventDefault();
  reviewIndex--;
  renderReview();
});

q("#reviewNextBtn")?.addEventListener("click",e=>{
  e.preventDefault();
  reviewIndex++;
  renderReview();
});

q("#reviewFlagBtn")?.addEventListener("click",e=>{
  e.preventDefault();
  const ep=resolveCurrentEpisode(),cuts=resolveCuts(ep),c=cuts[reviewIndex];
  if(!c)return;
  c.feedbackStatus="needs";
  c.reviewed=true;
  persist();
  renderReview();
});

q("#reviewResolveBtn")?.addEventListener("click",e=>{
  e.preventDefault();
  const ep=resolveCurrentEpisode(),cuts=resolveCuts(ep),c=cuts[reviewIndex];
  if(!c)return;
  if(c.feedbackStatus==="needs")c.feedbackStatus="resolved";
  c.reviewed=true;
  persist();
  renderReview();
});

window.addEventListener("keydown",e=>{
  if(e.key==="Escape" && q("#reviewModal")?.classList.contains("open")){
    e.preventDefault();
    closeReview();
  }
},true);

console.info("WORKROOM v39 single review handler loaded");
})();