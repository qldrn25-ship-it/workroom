const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("workroomDesktop", {
  platform: process.platform,
  getActiveApp: ()=>ipcRenderer.invoke("workroom:get-active-app")
});
