(() => {
"use strict";
const q=s=>document.querySelector(s);

const DEFAULTS=["글콘티","트리트먼트","설정","대사","아이디어","자료"];
let types=[];

function load(){
  try{
    const raw=localStorage.getItem("workroomMemoTypes");
    const parsed=raw?JSON.parse(raw):null;
    types=Array.isArray(parsed)&&parsed.length?parsed.filter(x=>typeof x==="string"&&x.trim()).map(x=>x.trim()):[...DEFAULTS];
  }catch(_){types=[...DEFAULTS]}
  types=[...new Set(types)];
}
function save(){
  try{localStorage.setItem("workroomMemoTypes",JSON.stringify(types))}catch(_){}
}
function currentMemoTypes(){
  const used=(typeof data!=="undefined"&&Array.isArray(data.memos))
    ?data.memos.map(m=>m.type).filter(Boolean):[];
  return [...new Set([...types,...used])];
}
function renderSelect(preferred){
  const sel=q("#memoType"); if(!sel)return;
  const value=preferred||sel.value||types[0]||"글콘티";
  const list=currentMemoTypes();
  sel.innerHTML=list.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join("");
  if(list.includes(value))sel.value=value;
  else sel.value=list[0]||"";
}
function esc(s){
  return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function renderManager(){
  const box=q("#memoTypeList"); if(!box)return;
  box.innerHTML="";
  types.forEach((name,i)=>{
    const row=document.createElement("div");
    row.className="memo-type-item";
    row.innerHTML=`<input class="memo-type-name" value="${esc(name)}" maxlength="30">
      <button type="button" class="glass-button secondary memo-type-order" data-dir="-1" title="위로">↑</button>
      <button type="button" class="glass-button secondary memo-type-order" data-dir="1" title="아래로">↓</button>
      <button type="button" class="glass-button danger memo-type-delete" title="삭제">×</button>`;
    const input=row.querySelector(".memo-type-name");
    input.addEventListener("change",()=>{
      const next=input.value.trim();
      if(!next){input.value=types[i];return}
      if(types.some((x,j)=>j!==i&&x===next)){alert("같은 이름의 분류가 이미 있습니다.");input.value=types[i];return}
      const old=types[i];
      types[i]=next; save(); renderSelect(next);
      // Rename existing memos too, so editing a category behaves as a true rename.
      if(typeof data!=="undefined"&&Array.isArray(data.memos)){
        data.memos.forEach(m=>{if(m.type===old)m.type=next});
        try{if(typeof saveData==="function")saveData()}catch(_){}
        try{if(typeof renderMemos==="function")renderMemos()}catch(_){}
      }
    });
    row.querySelectorAll(".memo-type-order").forEach(btn=>btn.addEventListener("click",()=>{
      const j=i+Number(btn.dataset.dir);
      if(j<0||j>=types.length)return;
      [types[i],types[j]]=[types[j],types[i]];
      save();renderManager();renderSelect();
    }));
    row.querySelector(".memo-type-delete").addEventListener("click",()=>{
      if(types.length<=1){alert("분류는 최소 1개가 필요합니다.");return}
      if(!confirm(`'${types[i]}' 분류를 목록에서 삭제할까요?\n기존 메모의 분류 표시는 유지됩니다.`))return;
      types.splice(i,1);save();renderManager();renderSelect();
    });
    box.appendChild(row);
  });
}
function openManager(){
  renderManager();
  q("#memoTypeManagerModal")?.classList.add("open");
}
function closeManager(){q("#memoTypeManagerModal")?.classList.remove("open")}

q("#manageMemoTypesBtn")?.addEventListener("click",openManager);
q("#closeMemoTypeManagerX")?.addEventListener("click",closeManager);
q("#addMemoTypeBtn")?.addEventListener("click",()=>{
  const input=q("#newMemoTypeName");
  const name=input?.value.trim();
  if(!name)return;
  if(types.includes(name)){alert("같은 이름의 분류가 이미 있습니다.");return}
  types.push(name);save();input.value="";renderManager();renderSelect(name);
});
q("#newMemoTypeName")?.addEventListener("keydown",e=>{
  if(e.key==="Enter"){e.preventDefault();q("#addMemoTypeBtn")?.click()}
});

/* app.js sets memoType when opening the editor. Make sure options exist first. */
const originalOpen=window.openMemoModal;
if(typeof originalOpen==="function"){
  window.openMemoModal=function(id){
    const memo=id&&typeof data!=="undefined"?data.memos.find(x=>x.id===id):null;
    renderSelect(memo?.type||types[0]);
    return originalOpen(id);
  };
}

load();
renderSelect();

console.info("WORKROOM v88 memo category manager loaded");
})();