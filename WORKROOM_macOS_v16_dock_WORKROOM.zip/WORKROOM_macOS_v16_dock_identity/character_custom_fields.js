
(()=>{
"use strict";

const list=document.querySelector("#characterCustomFields");
const empty=document.querySelector("#characterCustomEmpty");
const addBtn=document.querySelector("#addCharacterCustomFieldBtn");

function escAttr(v){
  return String(v??"").replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}
function syncEmpty(){
  if(!list||!empty)return;
  empty.hidden=list.children.length>0;
}
function makeRow(field={}){
  if(!list)return null;
  const row=document.createElement("div");
  row.className="character-custom-row";
  row.innerHTML=`
    <span class="character-custom-drag" title="순서 이동">⋮⋮</span>
    <input class="character-custom-label" maxlength="40" placeholder="항목명 예: 혈액형" value="${escAttr(field.label||"")}">
    <input class="character-custom-value" maxlength="300" placeholder="내용을 입력하세요" value="${escAttr(field.value||"")}">
    <button type="button" class="character-custom-remove" title="항목 삭제" aria-label="항목 삭제">×</button>
  `;
  row.querySelector(".character-custom-remove")?.addEventListener("click",()=>{
    row.remove();
    syncEmpty();
  });
  list.appendChild(row);
  syncEmpty();
  return row;
}

window.setCharacterCustomFields=function(fields){
  if(!list)return;
  list.innerHTML="";
  const arr=Array.isArray(fields)?fields:[];
  arr.forEach(f=>{
    if(f && (String(f.label||"").trim() || String(f.value||"").trim())) makeRow(f);
  });
  syncEmpty();
};

window.getCharacterCustomFields=function(){
  if(!list)return [];
  return [...list.querySelectorAll(".character-custom-row")]
    .map(row=>({
      label:row.querySelector(".character-custom-label")?.value.trim()||"",
      value:row.querySelector(".character-custom-value")?.value.trim()||""
    }))
    .filter(f=>f.label||f.value);
};

addBtn?.addEventListener("click",()=>{
  const row=makeRow();
  row?.querySelector(".character-custom-label")?.focus();
});

// Reordering by drag-and-drop. Keeps implementation local and dependency-free.
let dragging=null;
list?.addEventListener("dragstart",e=>{
  const row=e.target.closest(".character-custom-row");
  if(!row)return;
  dragging=row;
  row.classList.add("dragging");
  e.dataTransfer.effectAllowed="move";
});
list?.addEventListener("dragend",()=>{
  dragging?.classList.remove("dragging");
  dragging=null;
});
list?.addEventListener("dragover",e=>{
  if(!dragging)return;
  e.preventDefault();
  const rows=[...list.querySelectorAll(".character-custom-row:not(.dragging)")];
  const next=rows.find(r=>e.clientY < r.getBoundingClientRect().top+r.offsetHeight/2);
  if(next)list.insertBefore(dragging,next);
  else list.appendChild(dragging);
});

// Let only the handle initiate HTML drag.
list?.addEventListener("pointerdown",e=>{
  const row=e.target.closest(".character-custom-row");
  if(!row)return;
  row.draggable=!!e.target.closest(".character-custom-drag");
});
list?.addEventListener("pointerup",e=>{
  const row=e.target.closest(".character-custom-row");
  if(row)row.draggable=false;
});

syncEmpty();
})();
