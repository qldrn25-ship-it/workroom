(() => {
"use strict";

const q=s=>document.querySelector(s);
const qa=s=>[...document.querySelectorAll(s)];

let movingIds=[];

function projects(){
  if(typeof data==="undefined"||!Array.isArray(data.projects))return [];
  return data.projects;
}

function selectedResourceIdsFromCards(){
  return qa("#resourceGrid .resource-card.resource-selected")
    .map(card=>String(card.dataset.id||""))
    .filter(Boolean);
}

function currentProjectId(){
  if(typeof data==="undefined")return "";
  return String(q("#resourceProjectSelect")?.value||data.activeProjectId||"");
}

function fillProjectSelect(){
  const sel=q("#resourceMoveProjectSelect");
  if(!sel)return;

  const current=currentProjectId();
  sel.innerHTML=projects()
    .filter(p=>String(p.id)!==current)
    .map(p=>`<option value="${String(p.id).replace(/"/g,"&quot;")}">${String(p.name||"작품")}</option>`)
    .join("");

  if(!sel.options.length){
    sel.innerHTML='<option value="">이동할 다른 작품이 없습니다</option>';
  }
}

function openMoveModal(ids){
  movingIds=[...new Set(ids.map(String).filter(Boolean))];
  if(!movingIds.length){
    alert("이동할 자료를 먼저 선택해주세요.");
    return;
  }

  fillProjectSelect();
  const target=q("#resourceMoveProjectSelect");

  if(!target?.value){
    alert("이동할 다른 작품이 없습니다.");
    return;
  }

  const help=q("#resourceMoveHelp");
  if(help)help.textContent=`선택한 자료 ${movingIds.length}개를 다른 작품으로 이동합니다.`;

  q("#resourceMoveModal")?.classList.add("open");
}

function closeMoveModal(){
  q("#resourceMoveModal")?.classList.remove("open");
  movingIds=[];
}

q("#moveSelectedResourcesBtn")?.addEventListener("click",e=>{
  e.preventDefault();
  e.stopPropagation();
  openMoveModal(selectedResourceIdsFromCards());
});

q("#closeResourceMoveX")?.addEventListener("click",closeMoveModal);

q("#resourceMoveForm")?.addEventListener("submit",e=>{
  e.preventDefault();

  const targetProjectId=q("#resourceMoveProjectSelect")?.value||"";
  if(!targetProjectId||!movingIds.length)return;

  const targetProject=projects().find(p=>String(p.id)===String(targetProjectId));
  if(!targetProject)return;

  const count=movingIds.length;
  if(!confirm(`선택한 자료 ${count}개를 '${targetProject.name}' 작품으로 이동할까요?`))return;

  if(!Array.isArray(data.resources))return;

  data.resources.forEach(r=>{
    if(movingIds.includes(String(r.id))){
      r.projectId=targetProjectId;
    }
  });

  try{
    if(typeof saveData==="function")saveData();
  }catch(err){
    console.error(err);
  }

  closeMoveModal();

  /* Clear selection mode state through UI button if available. */
  const clear=q("#clearResourceSelectionBtn");
  if(clear){
    clear.click();
  }

  try{
    if(typeof renderResources==="function")renderResources();
  }catch(err){
    console.error(err);
  }
});

/* Optional: move one resource directly from its edit modal.
   Adds a small button dynamically next to the delete button if present. */
function ensureSingleMoveButton(){
  const deleteBtn=q("#deleteResourceBtn");
  if(!deleteBtn||q("#moveResourceProjectBtn"))return;

  const btn=document.createElement("button");
  btn.type="button";
  btn.className="glass-button secondary";
  btn.id="moveResourceProjectBtn";
  btn.textContent="작품 이동";

  deleteBtn.parentElement?.insertBefore(btn,deleteBtn);

  btn.addEventListener("click",()=>{
    const id=q("#resourceId")?.value||"";
    if(!id)return;
    openMoveModal([id]);
  });
}

setTimeout(ensureSingleMoveButton,100);

console.info("WORKROOM v85 resource project move loaded");
})();