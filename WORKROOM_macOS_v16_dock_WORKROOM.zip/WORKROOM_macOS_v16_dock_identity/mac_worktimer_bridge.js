(()=>{
"use strict";

if(!window.workroomDesktop || window.workroomDesktop.platform!=="darwin") return;

const state={
  active:false,
  clip:false,
  appName:"",
  bundleId:"",
  idleSeconds:0,
  lastPoll:0
};

function isClipStudio(info){
  const name=String(info?.appName||"").toLowerCase();
  const bundle=String(info?.bundleId||"").toLowerCase();
  const path=String(info?.path||"").toLowerCase();

  // CELSYS currently uses CLIP STUDIO PAINT naming; bundle IDs can vary by release.
  return name.includes("clip studio paint")
    || name==="clip studio"
    || bundle.includes("clipstudiopaint")
    || bundle.includes("celsys")
    || path.includes("clip studio paint.app");
}

function timeoutSeconds(){
  // Respect an existing work-timer timeout input if the UI has one.
  const candidates=[
    "#workTimerTimeout","#worktimerTimeout","#workTimeout",
    "[data-worktimer-timeout]","input[name='worktimerTimeout']"
  ];
  for(const sel of candidates){
    const el=document.querySelector(sel);
    if(el){
      const n=Number(el.value);
      if(Number.isFinite(n)&&n>=1)return n;
    }
  }
  return 10;
}

function updateVisibleStatus(){
  const running=state.clip && state.idleSeconds < timeoutSeconds();
  const display=state.clip ? "CLIP STUDIO PAINT" : (state.appName||"감지 대기");
  const detail=state.clip
    ? (running ? `작업 중 · 입력 대기 ${Math.floor(state.idleSeconds)}초` : `유휴 상태 · ${Math.floor(state.idleSeconds)}초`)
    : `${display} 활성`;

  const possibleStatus=[
    "#workTimerDetectedApp","#worktimerDetectedApp","#detectedProgram",
    "[data-worktimer-detected-app]"
  ];
  possibleStatus.forEach(sel=>{
    document.querySelectorAll(sel).forEach(el=>{el.textContent=display});
  });

  const possibleDetail=[
    "#workTimerDetectStatus","#worktimerDetectStatus","#workTimerStatus",
    "[data-worktimer-status]"
  ];
  possibleDetail.forEach(sel=>{
    document.querySelectorAll(sel).forEach(el=>{el.textContent=detail});
  });

  // Broadcast a stable event so the existing worktimer or future versions can consume it.
  window.dispatchEvent(new CustomEvent("workroom:active-program",{
    detail:{
      platform:"macOS",
      appName:state.appName,
      bundleId:state.bundleId,
      displayName:display,
      isTarget:state.clip,
      idleSeconds:state.idleSeconds,
      shouldRun:running
    }
  }));

  // Compatibility bridge for timer implementations that expose a native detector hook.
  if(typeof window.setWorkTimerExternalDetection==="function"){
    window.setWorkTimerExternalDetection({
      program:display,
      active:state.clip,
      idleSeconds:state.idleSeconds,
      shouldRun:running
    });
  }
}

async function poll(){
  try{
    const info=await window.workroomDesktop.getActiveApp();
    if(!info?.ok)return;
    state.appName=String(info.appName||"");
    state.bundleId=String(info.bundleId||"");
    state.idleSeconds=Number(info.idleSeconds||0);
    state.clip=isClipStudio(info);
    state.lastPoll=Date.now();
    updateVisibleStatus();
  }catch(err){
    console.error("macOS 활성 앱 감지 실패",err);
  }
}

setInterval(poll,1000);
poll();

window.WORKROOM_MAC_TIMER={
  get state(){return {...state}},
  isClipStudio
};
})();
