(() => {
"use strict";
const q=s=>document.querySelector(s);

function ep(){
  try{
    if(typeof activeEpisode==="function"){
      const x=activeEpisode();
      if(x)return x;
    }
  }catch(_){}
  if(typeof data!=="undefined"){
    const id=q("#episodeSelect")?.value||data.activeEpisodeId;
    return (data.episodes||[]).find(e=>String(e.id)===String(id))||null;
  }
  return null;
}
function scenes(){
  if(typeof data==="undefined")return [];
  if(!Array.isArray(data.scenes))data.scenes=[];
  const e=ep();
  return e?data.scenes.filter(s=>String(s.episodeId)===String(e.id)):[];
}
function selectedScene(){
  const id=q("#sceneFilterSelect")?.value||"all";
  if(id==="all")return null;
  return scenes().find(s=>String(s.id)===String(id))||null;
}
function save(){
  try{if(typeof saveData==="function")saveData()}catch(err){console.error(err)}
}
function refresh(){
  try{if(typeof populateSceneUI==="function")populateSceneUI()}catch(_){}
  try{if(typeof renderCuts==="function")renderCuts()}catch(_){}
  q("#sceneFilterSelect")?.dispatchEvent(new Event("change",{bubbles:true}));
}
function closeMenu(){
  q(".scene-manager-menu")?.classList.remove("open");
}
function openSceneModal(scene=null){
  const e=ep();
  if(!e){alert("먼저 작품과 화수를 선택해주세요.");return}
  q("#sceneId").value=scene?.id||"";
  q("#sceneNameInput").value=scene?.name||"";
  q("#sceneBackgroundInput").value=scene?.background||"";
  q("#sceneNoteInput").value=scene?.note||"";
  if(q("#sceneModalTitle"))q("#sceneModalTitle").textContent=scene?"장면 수정":"장면 추가";
  q("#sceneModal")?.classList.add("open");
  setTimeout(()=>q("#sceneNameInput")?.focus(),0);
}
q("#sceneManagerBtn")?.addEventListener("click",e=>{
  e.preventDefault();
  e.stopPropagation();
  q(".scene-manager-menu")?.classList.toggle("open");
});
document.addEventListener("click",e=>{
  if(!e.target.closest?.(".scene-manager-menu"))closeMenu();
});
window.addEventListener("keydown",e=>{
  if(e.key==="Escape")closeMenu();
});

q("#newSceneBtn")?.addEventListener("click",e=>{
  e.preventDefault();
  e.stopPropagation();
  closeMenu();
  openSceneModal(null);
},true);

q("#editSceneBtn")?.addEventListener("click",e=>{
  e.preventDefault();
  e.stopPropagation();
  const s=selectedScene();
  if(!s){
    alert("먼저 '전체 장면' 메뉴에서 수정할 장면을 선택해주세요.");
    return;
  }
  closeMenu();
  openSceneModal(s);
},true);

q("#deleteSceneBtn")?.addEventListener("click",e=>{
  e.preventDefault();
  e.stopPropagation();
  const s=selectedScene();
  if(!s){
    alert("먼저 '전체 장면' 메뉴에서 삭제할 장면을 선택해주세요.");
    return;
  }
  if(!confirm(`'${s.name}' 장면을 삭제할까요?\n이 장면에 연결된 컷은 '장면 없음'으로 변경됩니다.`))return;

  data.scenes=data.scenes.filter(x=>String(x.id)!==String(s.id));
  (ep()?.cuts||[]).forEach(c=>{
    if(String(c.sceneId||"")===String(s.id))c.sceneId="";
  });
  save();
  q("#sceneFilterSelect").value="all";
  refresh();
  closeMenu();
});

/* Override scene form with create/edit behavior in capture phase */
q("#sceneForm")?.addEventListener("submit",e=>{
  e.preventDefault();
  e.stopPropagation();
  e.stopImmediatePropagation();

  const epx=ep();
  if(!epx)return;

  const name=q("#sceneNameInput").value.trim();
  if(!name){alert("장면 이름을 입력해주세요.");return}

  if(!Array.isArray(data.scenes))data.scenes=[];
  const id=q("#sceneId").value;

  if(id){
    const s=data.scenes.find(x=>String(x.id)===String(id));
    if(s){
      s.name=name;
      s.background=q("#sceneBackgroundInput").value.trim();
      s.note=q("#sceneNoteInput").value.trim();
    }
  }else{
    data.scenes.push({
      id:crypto.randomUUID?.()||String(Date.now()),
      episodeId:epx.id,
      name,
      background:q("#sceneBackgroundInput").value.trim(),
      note:q("#sceneNoteInput").value.trim()
    });
  }

  save();
  q("#sceneModal")?.classList.remove("open");
  refresh();
},true);

console.info("WORKROOM v70 scene manager loaded");
})();